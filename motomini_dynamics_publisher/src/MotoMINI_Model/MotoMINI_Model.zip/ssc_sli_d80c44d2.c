#include "pm_std.h"
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_sDHUnxPZZ9eRygcM3c_BT_(size_t
ssc_sli_wpM2BH4ZgIGett_8VFoUR_);
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_85UzFWQBhqjDw5z0Xsm3Z1(void);
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_linear_algebra(void);
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_sDHUnxPZZ9eRygcM3c_BT_(size_t
ssc_sli_wpM2BH4ZgIGett_8VFoUR_){return ssc_sli_wpM2BH4ZgIGett_8VFoUR_<7?
ssc_sli_85UzFWQBhqjDw5z0Xsm3Z1():mc_get_csparse_linear_algebra();}
