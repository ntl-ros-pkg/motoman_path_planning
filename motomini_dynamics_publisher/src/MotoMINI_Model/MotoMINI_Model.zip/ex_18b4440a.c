#include "pm_std.h"
#include "lang_std.h"
size_t ex_XgFqE_qWosDa601lsTn6b1(const real_T*x,const size_t n,const real_T t)
;void ex_58tHK_FJLrTVg5pTR2KLX0(real_T*ex__lerGssn0Ru_r3kSOzEmI_,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51);void
ex_kxquG9pkEjt4fXtMQOsqG2(real_T*x,real_T*f,const size_t n);void
ex_nC4jUddYFsKRLzFkVBm3G0(real_T*x1,real_T*x2,real_T*f,const size_t n1,const
size_t n2);void ex_p_64ouPbD9bddOkoAZOpZ1(real_T*x1,real_T*x2,real_T*x3,real_T
*f,const size_t n1,const size_t n2,const size_t n3);void
ex_5NKaAbmUyQr1tleeDl4Vc2(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*f,
const size_t n1,const size_t n2,const size_t n3,const size_t n4);size_t
ex_XgFqE_qWosDa601lsTn6b1(const real_T*x,const size_t n,const real_T t){size_t
ex_SmSSPSQfR1qEYWsVj5ELF0;for(ex_SmSSPSQfR1qEYWsVj5ELF0=0;
ex_SmSSPSQfR1qEYWsVj5ELF0<n;++ex_SmSSPSQfR1qEYWsVj5ELF0){if(t<x[
ex_SmSSPSQfR1qEYWsVj5ELF0]){return ex_SmSSPSQfR1qEYWsVj5ELF0;}}return n;}void
ex_58tHK_FJLrTVg5pTR2KLX0(real_T*ex__lerGssn0Ru_r3kSOzEmI_,const size_t n1,
const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51){size_t
ex__VPpmCt_TuqLdOtTsmwgk2,ex_947YwtWZMq1Crv_q1N3191,ex_C4pJ8EG5SHlP7E7N7_IwR0,
ex_8JNLpOzZjPYXIhD7spzP_1;size_t ex_rX2Nhyrokuq9JmnRvEAkJ1;size_t
ex_vJNTlzCToBxcUvOWkhNhd0=0,ex_EIf_lwUWE1bdKMrfR2M1P1=0,
ex_BZN0xsSW7qfuR1Yqu1zM30=0,ex_iUHWBQi_5vgen_OoXLgGS_=0,
ex_aJAttxCFc6cz5ZBCjJ4jr2=0;real_T ex_U938Ucreg_Pd41Eh8sAbX1;for(
ex_8JNLpOzZjPYXIhD7spzP_1=0;ex_8JNLpOzZjPYXIhD7spzP_1<n4;++
ex_8JNLpOzZjPYXIhD7spzP_1){ex_iUHWBQi_5vgen_OoXLgGS_=ex_fo8lU9fQuflzUTvG3MoQ51
*ex_8JNLpOzZjPYXIhD7spzP_1;for(ex_C4pJ8EG5SHlP7E7N7_IwR0=0;
ex_C4pJ8EG5SHlP7E7N7_IwR0<n3;++ex_C4pJ8EG5SHlP7E7N7_IwR0){
ex_BZN0xsSW7qfuR1Yqu1zM30=ex_x_teXoaz0hlS1RzJxhHla0*ex_C4pJ8EG5SHlP7E7N7_IwR0+
ex_iUHWBQi_5vgen_OoXLgGS_;for(ex_947YwtWZMq1Crv_q1N3191=0;
ex_947YwtWZMq1Crv_q1N3191<n2;++ex_947YwtWZMq1Crv_q1N3191){
ex_EIf_lwUWE1bdKMrfR2M1P1=ex_KTkrfjRMBsZjPvzwkIouc_*ex_947YwtWZMq1Crv_q1N3191+
ex_BZN0xsSW7qfuR1Yqu1zM30;ex_rX2Nhyrokuq9JmnRvEAkJ1=n1-1;for(
ex__VPpmCt_TuqLdOtTsmwgk2=0;ex__VPpmCt_TuqLdOtTsmwgk2<(n1/2);++
ex__VPpmCt_TuqLdOtTsmwgk2){ex_vJNTlzCToBxcUvOWkhNhd0=ex_G5C_Yq8nLf6PL2EMNiFAc1
*ex__VPpmCt_TuqLdOtTsmwgk2+ex_EIf_lwUWE1bdKMrfR2M1P1;ex_aJAttxCFc6cz5ZBCjJ4jr2
=ex_G5C_Yq8nLf6PL2EMNiFAc1*ex_rX2Nhyrokuq9JmnRvEAkJ1+ex_EIf_lwUWE1bdKMrfR2M1P1
;ex_U938Ucreg_Pd41Eh8sAbX1=ex__lerGssn0Ru_r3kSOzEmI_[ex_vJNTlzCToBxcUvOWkhNhd0
];ex__lerGssn0Ru_r3kSOzEmI_[ex_vJNTlzCToBxcUvOWkhNhd0]=
ex__lerGssn0Ru_r3kSOzEmI_[ex_aJAttxCFc6cz5ZBCjJ4jr2];ex__lerGssn0Ru_r3kSOzEmI_
[ex_aJAttxCFc6cz5ZBCjJ4jr2]=ex_U938Ucreg_Pd41Eh8sAbX1;--
ex_rX2Nhyrokuq9JmnRvEAkJ1;}}}}}void ex_kxquG9pkEjt4fXtMQOsqG2(real_T*x,real_T*
f,const size_t n){if(x[n-1]<x[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x,n,1,1,1,1,0,0,0)
;ex_58tHK_FJLrTVg5pTR2KLX0(f,n,1,1,1,1,0,0,0);}}void ex_nC4jUddYFsKRLzFkVBm3G0
(real_T*x1,real_T*x2,real_T*f,const size_t n1,const size_t n2){size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1=1;size_t ex_KTkrfjRMBsZjPvzwkIouc_=
ex_G5C_Yq8nLf6PL2EMNiFAc1*n1;if(x1[n1-1]<x1[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x1,
n1,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n1,n2,1,1,
ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,0,0);}if(x2[n2-1]<x2[0]){
ex_58tHK_FJLrTVg5pTR2KLX0(x2,n2,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n2,
n1,1,1,ex_KTkrfjRMBsZjPvzwkIouc_,ex_G5C_Yq8nLf6PL2EMNiFAc1,0,0);}}void
ex_p_64ouPbD9bddOkoAZOpZ1(real_T*x1,real_T*x2,real_T*x3,real_T*f,const size_t
n1,const size_t n2,const size_t n3){size_t ex_G5C_Yq8nLf6PL2EMNiFAc1=1;size_t
ex_KTkrfjRMBsZjPvzwkIouc_=ex_G5C_Yq8nLf6PL2EMNiFAc1*n1;size_t
ex_x_teXoaz0hlS1RzJxhHla0=ex_KTkrfjRMBsZjPvzwkIouc_*n2;if(x1[n1-1]<x1[0]){
ex_58tHK_FJLrTVg5pTR2KLX0(x1,n1,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n1,
n2,n3,1,ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,
ex_x_teXoaz0hlS1RzJxhHla0,0);}if(x2[n2-1]<x2[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x2,
n2,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n2,n3,n1,1,
ex_KTkrfjRMBsZjPvzwkIouc_,ex_x_teXoaz0hlS1RzJxhHla0,ex_G5C_Yq8nLf6PL2EMNiFAc1,
0);}if(x3[n3-1]<x3[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x3,n3,1,1,1,1,0,0,0);
ex_58tHK_FJLrTVg5pTR2KLX0(f,n3,n1,n2,1,ex_x_teXoaz0hlS1RzJxhHla0,
ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,0);}}void
ex_5NKaAbmUyQr1tleeDl4Vc2(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*f,
const size_t n1,const size_t n2,const size_t n3,const size_t n4){size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1=1;size_t ex_KTkrfjRMBsZjPvzwkIouc_=
ex_G5C_Yq8nLf6PL2EMNiFAc1*n1;size_t ex_x_teXoaz0hlS1RzJxhHla0=
ex_KTkrfjRMBsZjPvzwkIouc_*n2;size_t ex_fo8lU9fQuflzUTvG3MoQ51=
ex_x_teXoaz0hlS1RzJxhHla0*n3;if(x1[n1-1]<x1[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x1,
n1,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n1,n2,n3,n4,
ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,ex_x_teXoaz0hlS1RzJxhHla0,
ex_fo8lU9fQuflzUTvG3MoQ51);}if(x2[n2-1]<x2[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x2,n2
,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n2,n3,n4,n1,
ex_KTkrfjRMBsZjPvzwkIouc_,ex_x_teXoaz0hlS1RzJxhHla0,ex_fo8lU9fQuflzUTvG3MoQ51,
ex_G5C_Yq8nLf6PL2EMNiFAc1);}if(x3[n3-1]<x3[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x3,n3
,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n3,n4,n1,n2,
ex_x_teXoaz0hlS1RzJxhHla0,ex_fo8lU9fQuflzUTvG3MoQ51,ex_G5C_Yq8nLf6PL2EMNiFAc1,
ex_KTkrfjRMBsZjPvzwkIouc_);}if(x4[n4-1]<x4[0]){ex_58tHK_FJLrTVg5pTR2KLX0(x4,n4
,1,1,1,1,0,0,0);ex_58tHK_FJLrTVg5pTR2KLX0(f,n4,n1,n2,n3,
ex_fo8lU9fQuflzUTvG3MoQ51,ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,
ex_x_teXoaz0hlS1RzJxhHla0);}}
