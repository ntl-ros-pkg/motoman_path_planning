#include "pm_std.h"
struct ssc_sli_TveuOuuz_7rSXp2jMuHzn2{struct{char const*
ssc_sli_k5ECafHar76dqhSwg7a071;char const*ssc_sli_1DeGCS58UEqbpNGz2_CoR_;char
const*ssc_sli_e_HV04cDbHkRtAPvgF8xc0;}ssc_sli_3ZJPpHEXPqHh_yFIUe7bH2;};extern
struct ssc_sli_TveuOuuz_7rSXp2jMuHzn2 ssc_sli_pw_0VUta9kXlY8r5A6PVl0;struct
ssc_sli_TveuOuuz_7rSXp2jMuHzn2 ssc_sli_pw_0VUta9kXlY8r5A6PVl0={{
"Partitioning local solver failed to advance at time %ss. Use a different local solver or turn the local solver option off."
,
"Partitioning local solver failed to compute initial conditions. Use a different local solver or turn the local solver option off."
,
"Simscape succeeded in finding consistent states with which to start the simulation, but the states found may deviate from requested initial conditions."
,},};
