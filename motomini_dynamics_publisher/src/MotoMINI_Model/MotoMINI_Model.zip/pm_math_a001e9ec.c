#include "pm_std.h"
void pm_math_lin_alg_vectorAdd(uint32_T n,const double*
pm_math_MJ6HaMWdyRxHm3p_EZiD41,const double*pm_math_ljExW6hRw43Vg4SLQUAvT1,
double*pm_math_AnS7Y4euB5dEkvfZmgB7x_);void pm_math_lin_alg_vectorSubtract(
uint32_T n,const double*pm_math_MJ6HaMWdyRxHm3p_EZiD41,const double*
pm_math_ljExW6hRw43Vg4SLQUAvT1,double*pm_math_t4xP2dw1g2qcI2WS3WOWv2);void
pm_math_lin_alg_vectorScale(uint32_T n,double pm_math_hCXUd_x6pbKZfXtyKXEw82,
const double*pm_math_ljExW6hRw43Vg4SLQUAvT1,double*
pm_math_A0Gw49pVZ44sTgTR2FoSa0);void pm_math_lin_alg_vectorNegate(uint32_T n,
const double*pm_math_ljExW6hRw43Vg4SLQUAvT1,double*
pm_math_FjEGK4Yh1T1DadpMtzyNA2);void pm_math_lin_alg_matrixAssignStrided(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_K6hhrEhA_gu92sixyASz9_,uint32_T pm_math_TMxMXv8G8wvxO_2ArARuB2,const
double*pm_math_cO3HQ5aG_1XgD1aeQvO8f2,double*pm_math_BOXZTEAmCrs_EsW1Z7QvC0);
void pm_math_lin_alg_matrixTransposeAdd(uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,double*pm_math_cO3HQ5aG_1XgD1aeQvO8f2);void
pm_math_lin_alg_matrixTransposeSubtract(uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,double*pm_math_BOXZTEAmCrs_EsW1Z7QvC0);void
pm_math_lin_alg_matrixMultiply(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,
uint32_T pm_math_PIqWtbzrbQqv_KS_31HnE2,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_8ksqc0VFHLjSHzNxXK8mN0,
double*pm_math_CH6pya__frGySt3NjsQiR2);void
pm_math_lin_alg_matrixMultiplyStrided(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,
uint32_T pm_math_PIqWtbzrbQqv_KS_31HnE2,uint32_T n,uint32_T
pm_math_oRtU12lxPI9p86iLr20Wu1,uint32_T pm_math_Lje4oCI77ASLCC9n82IsE2,
uint32_T pm_math_D2vRJwh0s8uz3B1o7tRAi0,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_8ksqc0VFHLjSHzNxXK8mN0,
double*pm_math_CH6pya__frGySt3NjsQiR2);void pm_math_lin_alg_scaleColumns(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_hCXUd_x6pbKZfXtyKXEw82,
double*pm_math_OafkXLmtGNgUqnqTklvAg0);void pm_math_lin_alg_scaleRows(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_hCXUd_x6pbKZfXtyKXEw82,
double*pm_math_Qv4f3RDdS3UGiYP5nAnWY0);void pm_math_lin_alg_inverseScaleColumns
(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_hCXUd_x6pbKZfXtyKXEw82,
double*pm_math_OafkXLmtGNgUqnqTklvAg0);void pm_math_lin_alg_inverseScaleRows(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_hCXUd_x6pbKZfXtyKXEw82,
double*pm_math_Qv4f3RDdS3UGiYP5nAnWY0);void pm_math_lin_alg_zeroMajor(uint32_T
pm_math_DV7YBJJlUNSKUIDO6d5hs2,uint32_T pm_math_FaviyjjzftiMthrDLL7b_1,const
int32_T*pm_math_1OA72Ccil1N0vbkmvAJe61,double*pm_math__lerGssn0Ru_r3kSOzEmI_);
void pm_math_lin_alg_matrixVectorMultiply(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_gyGYov8P2mGIOhM9NpVPE1);void
pm_math_lin_alg_matrixVectorMultiplyStrided(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_gG1tYC_1A6mUTedK5sOsQ0,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,
const double*x,double*pm_math_gyGYov8P2mGIOhM9NpVPE1);void
pm_math_lin_alg_matrixTransposeVectorMultiply(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_zyXK_Uxc8J0BqXOhyd0xg0);void pm_math_lin_alg_addMatrixVectorProduct(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_ET9_5EAP116KvP5KVqsrD2);void
pm_math_lin_alg_addMatrixVectorProductStrided(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_gG1tYC_1A6mUTedK5sOsQ0,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,
const double*x,double*pm_math_ET9_5EAP116KvP5KVqsrD2);void
pm_math_lin_alg_subtractMatrixVectorProduct(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_ET9_5EAP116KvP5KVqsrD2);void
pm_math_lin_alg_subtractMatrixVectorProductStrided(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_gG1tYC_1A6mUTedK5sOsQ0,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,
const double*x,double*pm_math_ET9_5EAP116KvP5KVqsrD2);double
pm_math_lin_alg_computeQuadraticTerm(uint32_T n,const double*
pm_math_0Ku4r8_UTD6dwsQGuIlz31,const double*pm_math_MJ6HaMWdyRxHm3p_EZiD41,
const double*pm_math_ljExW6hRw43Vg4SLQUAvT1);
#include "string.h"
void pm_math_lin_alg_vectorAdd(uint32_T n,const double*
pm_math_MJ6HaMWdyRxHm3p_EZiD41,const double*pm_math_ljExW6hRw43Vg4SLQUAvT1,
double*pm_math_AnS7Y4euB5dEkvfZmgB7x_){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0
;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)*pm_math_AnS7Y4euB5dEkvfZmgB7x_++= *
pm_math_MJ6HaMWdyRxHm3p_EZiD41++ +*pm_math_ljExW6hRw43Vg4SLQUAvT1++;}void
pm_math_lin_alg_vectorSubtract(uint32_T n,const double*
pm_math_MJ6HaMWdyRxHm3p_EZiD41,const double*pm_math_ljExW6hRw43Vg4SLQUAvT1,
double*pm_math_t4xP2dw1g2qcI2WS3WOWv2){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0
;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)*pm_math_t4xP2dw1g2qcI2WS3WOWv2++= *
pm_math_MJ6HaMWdyRxHm3p_EZiD41++-*pm_math_ljExW6hRw43Vg4SLQUAvT1++;}void
pm_math_lin_alg_vectorScale(uint32_T n,double pm_math_hCXUd_x6pbKZfXtyKXEw82,
const double*pm_math_ljExW6hRw43Vg4SLQUAvT1,double*
pm_math_A0Gw49pVZ44sTgTR2FoSa0){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0;for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)*pm_math_A0Gw49pVZ44sTgTR2FoSa0++=
pm_math_hCXUd_x6pbKZfXtyKXEw82**pm_math_ljExW6hRw43Vg4SLQUAvT1++;}void
pm_math_lin_alg_vectorNegate(uint32_T n,const double*
pm_math_ljExW6hRw43Vg4SLQUAvT1,double*pm_math_FjEGK4Yh1T1DadpMtzyNA2){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;++pm_math_SmSSPSQfR1qEYWsVj5ELF0)*
pm_math_FjEGK4Yh1T1DadpMtzyNA2++= -*pm_math_ljExW6hRw43Vg4SLQUAvT1++;}void
pm_math_lin_alg_matrixAssignStrided(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,
uint32_T n,uint32_T pm_math_K6hhrEhA_gu92sixyASz9_,uint32_T
pm_math_TMxMXv8G8wvxO_2ArARuB2,const double*pm_math_cO3HQ5aG_1XgD1aeQvO8f2,
double*pm_math_BOXZTEAmCrs_EsW1Z7QvC0){const size_t
pm_math_cJEAb3fZvAIaXK02KdZaN2=pm_math_gN74BbsU5wqNjkJbC9b672*sizeof(double);
uint32_T pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++pm_math_OUB2pptsvtdGL_LyqpgOa0,
pm_math_cO3HQ5aG_1XgD1aeQvO8f2+=pm_math_K6hhrEhA_gu92sixyASz9_,
pm_math_BOXZTEAmCrs_EsW1Z7QvC0+=pm_math_TMxMXv8G8wvxO_2ArARuB2)memcpy(
pm_math_BOXZTEAmCrs_EsW1Z7QvC0,pm_math_cO3HQ5aG_1XgD1aeQvO8f2,
pm_math_cJEAb3fZvAIaXK02KdZaN2);}void pm_math_lin_alg_matrixTransposeAdd(
uint32_T n,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,double*
pm_math_cO3HQ5aG_1XgD1aeQvO8f2){uint32_T pm_math_ojAHyVHgbHhAjmJFnG_l31,
pm_math_2KXuAphrqc_TLcinUGD4E1,pm_math_BJ3jPrKWeKSl8Rb_1VIEv1,
pm_math_HvYXBptQBsL6p4alLq_Xr0;for(pm_math_ojAHyVHgbHhAjmJFnG_l31=0,
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1=0,pm_math_HvYXBptQBsL6p4alLq_Xr0=0;
pm_math_ojAHyVHgbHhAjmJFnG_l31<n;++pm_math_ojAHyVHgbHhAjmJFnG_l31,
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1+=pm_math_ojAHyVHgbHhAjmJFnG_l31,
pm_math_HvYXBptQBsL6p4alLq_Xr0=pm_math_BJ3jPrKWeKSl8Rb_1VIEv1){
pm_math_cO3HQ5aG_1XgD1aeQvO8f2[pm_math_BJ3jPrKWeKSl8Rb_1VIEv1]=2.0*
pm_math__lerGssn0Ru_r3kSOzEmI_[pm_math_BJ3jPrKWeKSl8Rb_1VIEv1];++
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1,pm_math_HvYXBptQBsL6p4alLq_Xr0+=n;for(
pm_math_2KXuAphrqc_TLcinUGD4E1=pm_math_ojAHyVHgbHhAjmJFnG_l31+1;
pm_math_2KXuAphrqc_TLcinUGD4E1<n;++pm_math_2KXuAphrqc_TLcinUGD4E1,++
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1,pm_math_HvYXBptQBsL6p4alLq_Xr0+=n)
pm_math_cO3HQ5aG_1XgD1aeQvO8f2[pm_math_BJ3jPrKWeKSl8Rb_1VIEv1]=
pm_math_cO3HQ5aG_1XgD1aeQvO8f2[pm_math_HvYXBptQBsL6p4alLq_Xr0]=
pm_math__lerGssn0Ru_r3kSOzEmI_[pm_math_BJ3jPrKWeKSl8Rb_1VIEv1]+
pm_math__lerGssn0Ru_r3kSOzEmI_[pm_math_HvYXBptQBsL6p4alLq_Xr0];}}void
pm_math_lin_alg_matrixTransposeSubtract(uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,double*pm_math_BOXZTEAmCrs_EsW1Z7QvC0){uint32_T
pm_math_ojAHyVHgbHhAjmJFnG_l31,pm_math_2KXuAphrqc_TLcinUGD4E1,
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1,pm_math_HvYXBptQBsL6p4alLq_Xr0;for(
pm_math_ojAHyVHgbHhAjmJFnG_l31=0,pm_math_BJ3jPrKWeKSl8Rb_1VIEv1=0,
pm_math_HvYXBptQBsL6p4alLq_Xr0=0;pm_math_ojAHyVHgbHhAjmJFnG_l31<n;++
pm_math_ojAHyVHgbHhAjmJFnG_l31,pm_math_BJ3jPrKWeKSl8Rb_1VIEv1+=
pm_math_ojAHyVHgbHhAjmJFnG_l31,pm_math_HvYXBptQBsL6p4alLq_Xr0=
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1){pm_math_BOXZTEAmCrs_EsW1Z7QvC0[
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1]=0.0;++pm_math_BJ3jPrKWeKSl8Rb_1VIEv1,
pm_math_HvYXBptQBsL6p4alLq_Xr0+=n;for(pm_math_2KXuAphrqc_TLcinUGD4E1=
pm_math_ojAHyVHgbHhAjmJFnG_l31+1;pm_math_2KXuAphrqc_TLcinUGD4E1<n;++
pm_math_2KXuAphrqc_TLcinUGD4E1,++pm_math_BJ3jPrKWeKSl8Rb_1VIEv1,
pm_math_HvYXBptQBsL6p4alLq_Xr0+=n){pm_math_BOXZTEAmCrs_EsW1Z7QvC0[
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1]=pm_math__lerGssn0Ru_r3kSOzEmI_[
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1]-pm_math__lerGssn0Ru_r3kSOzEmI_[
pm_math_HvYXBptQBsL6p4alLq_Xr0];pm_math_BOXZTEAmCrs_EsW1Z7QvC0[
pm_math_HvYXBptQBsL6p4alLq_Xr0]= -pm_math_BOXZTEAmCrs_EsW1Z7QvC0[
pm_math_BJ3jPrKWeKSl8Rb_1VIEv1];}}}void pm_math_lin_alg_matrixMultiply(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T pm_math_PIqWtbzrbQqv_KS_31HnE2
,uint32_T n,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,const double*
pm_math_8ksqc0VFHLjSHzNxXK8mN0,double*pm_math_CH6pya__frGySt3NjsQiR2){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0,
pm_math_hCXUd_x6pbKZfXtyKXEw82;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++pm_math_OUB2pptsvtdGL_LyqpgOa0,
pm_math_8ksqc0VFHLjSHzNxXK8mN0+=pm_math_PIqWtbzrbQqv_KS_31HnE2)for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0,++
pm_math_CH6pya__frGySt3NjsQiR2){const double*pm_MUnOgYpKkviTC4TqWArmj2=
pm_math__lerGssn0Ru_r3kSOzEmI_+pm_math_SmSSPSQfR1qEYWsVj5ELF0;*
pm_math_CH6pya__frGySt3NjsQiR2=0.0;for(pm_math_hCXUd_x6pbKZfXtyKXEw82=0;
pm_math_hCXUd_x6pbKZfXtyKXEw82<pm_math_PIqWtbzrbQqv_KS_31HnE2;++
pm_math_hCXUd_x6pbKZfXtyKXEw82,pm_MUnOgYpKkviTC4TqWArmj2+=
pm_math_gN74BbsU5wqNjkJbC9b672,++pm_math_8ksqc0VFHLjSHzNxXK8mN0)*
pm_math_CH6pya__frGySt3NjsQiR2+= *pm_MUnOgYpKkviTC4TqWArmj2**
pm_math_8ksqc0VFHLjSHzNxXK8mN0;pm_math_8ksqc0VFHLjSHzNxXK8mN0-=
pm_math_PIqWtbzrbQqv_KS_31HnE2;}}void pm_math_lin_alg_matrixMultiplyStrided(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T pm_math_PIqWtbzrbQqv_KS_31HnE2
,uint32_T n,uint32_T pm_math_oRtU12lxPI9p86iLr20Wu1,uint32_T
pm_math_Lje4oCI77ASLCC9n82IsE2,uint32_T pm_math_D2vRJwh0s8uz3B1o7tRAi0,const
double*pm_math__lerGssn0Ru_r3kSOzEmI_,const double*
pm_math_8ksqc0VFHLjSHzNxXK8mN0,double*pm_math_CH6pya__frGySt3NjsQiR2){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0,
pm_math_hCXUd_x6pbKZfXtyKXEw82;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++pm_math_OUB2pptsvtdGL_LyqpgOa0,
pm_math_8ksqc0VFHLjSHzNxXK8mN0+=pm_math_Lje4oCI77ASLCC9n82IsE2,
pm_math_CH6pya__frGySt3NjsQiR2+=(pm_math_D2vRJwh0s8uz3B1o7tRAi0-
pm_math_gN74BbsU5wqNjkJbC9b672))for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<pm_math_gN74BbsU5wqNjkJbC9b672;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0,++pm_math_CH6pya__frGySt3NjsQiR2){const double*
pm_MUnOgYpKkviTC4TqWArmj2=pm_math__lerGssn0Ru_r3kSOzEmI_+
pm_math_SmSSPSQfR1qEYWsVj5ELF0;*pm_math_CH6pya__frGySt3NjsQiR2=0.0;for(
pm_math_hCXUd_x6pbKZfXtyKXEw82=0;pm_math_hCXUd_x6pbKZfXtyKXEw82<
pm_math_PIqWtbzrbQqv_KS_31HnE2;++pm_math_hCXUd_x6pbKZfXtyKXEw82,
pm_MUnOgYpKkviTC4TqWArmj2+=pm_math_oRtU12lxPI9p86iLr20Wu1,++
pm_math_8ksqc0VFHLjSHzNxXK8mN0)*pm_math_CH6pya__frGySt3NjsQiR2+= *
pm_MUnOgYpKkviTC4TqWArmj2**pm_math_8ksqc0VFHLjSHzNxXK8mN0;
pm_math_8ksqc0VFHLjSHzNxXK8mN0-=pm_math_PIqWtbzrbQqv_KS_31HnE2;}}void
pm_math_lin_alg_scaleColumns(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n
,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,const double*
pm_math_hCXUd_x6pbKZfXtyKXEw82,double*pm_math_OafkXLmtGNgUqnqTklvAg0){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,++pm_math_hCXUd_x6pbKZfXtyKXEw82)for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0)*
pm_math_OafkXLmtGNgUqnqTklvAg0++= *pm_math__lerGssn0Ru_r3kSOzEmI_++**
pm_math_hCXUd_x6pbKZfXtyKXEw82;}void pm_math_lin_alg_scaleRows(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_hCXUd_x6pbKZfXtyKXEw82,
double*pm_math_Qv4f3RDdS3UGiYP5nAnWY0){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0
,pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++pm_math_OUB2pptsvtdGL_LyqpgOa0){for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0)*
pm_math_Qv4f3RDdS3UGiYP5nAnWY0++= *pm_math__lerGssn0Ru_r3kSOzEmI_++**
pm_math_hCXUd_x6pbKZfXtyKXEw82++;pm_math_hCXUd_x6pbKZfXtyKXEw82-=
pm_math_gN74BbsU5wqNjkJbC9b672;}}void pm_math_lin_alg_inverseScaleColumns(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*pm_math_hCXUd_x6pbKZfXtyKXEw82,
double*pm_math_OafkXLmtGNgUqnqTklvAg0){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0
,pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++pm_math_OUB2pptsvtdGL_LyqpgOa0,++
pm_math_hCXUd_x6pbKZfXtyKXEw82)for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<pm_math_gN74BbsU5wqNjkJbC9b672;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)*pm_math_OafkXLmtGNgUqnqTklvAg0++= *
pm_math__lerGssn0Ru_r3kSOzEmI_++/ *pm_math_hCXUd_x6pbKZfXtyKXEw82;}void
pm_math_lin_alg_inverseScaleRows(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,
uint32_T n,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,const double*
pm_math_hCXUd_x6pbKZfXtyKXEw82,double*pm_math_Qv4f3RDdS3UGiYP5nAnWY0){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0){for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<pm_math_gN74BbsU5wqNjkJbC9b672;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)*pm_math_Qv4f3RDdS3UGiYP5nAnWY0++= *
pm_math__lerGssn0Ru_r3kSOzEmI_++/ *pm_math_hCXUd_x6pbKZfXtyKXEw82++;
pm_math_hCXUd_x6pbKZfXtyKXEw82-=pm_math_gN74BbsU5wqNjkJbC9b672;}}void
pm_math_lin_alg_zeroMajor(uint32_T pm_math_DV7YBJJlUNSKUIDO6d5hs2,uint32_T
pm_math_FaviyjjzftiMthrDLL7b_1,const int32_T*pm_math_1OA72Ccil1N0vbkmvAJe61,
double*pm_math__lerGssn0Ru_r3kSOzEmI_){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0
,pm_math_OUB2pptsvtdGL_LyqpgOa0;if(pm_math_FaviyjjzftiMthrDLL7b_1==0)return;
for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_DV7YBJJlUNSKUIDO6d5hs2;++pm_math_SmSSPSQfR1qEYWsVj5ELF0){if(*
pm_math_1OA72Ccil1N0vbkmvAJe61++==0){for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<pm_math_FaviyjjzftiMthrDLL7b_1;++
pm_math_OUB2pptsvtdGL_LyqpgOa0)*pm_math__lerGssn0Ru_r3kSOzEmI_++=0.0;}else
pm_math__lerGssn0Ru_r3kSOzEmI_+=pm_math_FaviyjjzftiMthrDLL7b_1;}}void
pm_math_lin_alg_matrixVectorMultiply(uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,
uint32_T n,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,
pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<pm_math_gN74BbsU5wqNjkJbC9b672;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0,++pm_math_ET9_5EAP116KvP5KVqsrD2){const double*
pm_MUnOgYpKkviTC4TqWArmj2=pm_math__lerGssn0Ru_r3kSOzEmI_+
pm_math_SmSSPSQfR1qEYWsVj5ELF0;*pm_math_ET9_5EAP116KvP5KVqsrD2=0.0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,pm_MUnOgYpKkviTC4TqWArmj2+=
pm_math_gN74BbsU5wqNjkJbC9b672,++x)*pm_math_ET9_5EAP116KvP5KVqsrD2+= *
pm_MUnOgYpKkviTC4TqWArmj2**x;x-=n;}}void
pm_math_lin_alg_matrixVectorMultiplyStrided(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_gG1tYC_1A6mUTedK5sOsQ0,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,
const double*x,double*pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0,++
pm_math_ET9_5EAP116KvP5KVqsrD2){const double*pm_MUnOgYpKkviTC4TqWArmj2=
pm_math__lerGssn0Ru_r3kSOzEmI_+pm_math_SmSSPSQfR1qEYWsVj5ELF0;*
pm_math_ET9_5EAP116KvP5KVqsrD2=0.0;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++pm_math_OUB2pptsvtdGL_LyqpgOa0,
pm_MUnOgYpKkviTC4TqWArmj2+=pm_math_gG1tYC_1A6mUTedK5sOsQ0,++x)*
pm_math_ET9_5EAP116KvP5KVqsrD2+= *pm_MUnOgYpKkviTC4TqWArmj2**x;x-=n;}}void
pm_math_lin_alg_matrixTransposeVectorMultiply(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,
pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;++pm_math_SmSSPSQfR1qEYWsVj5ELF0,++
pm_math_ET9_5EAP116KvP5KVqsrD2){*pm_math_ET9_5EAP116KvP5KVqsrD2=0.0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_OUB2pptsvtdGL_LyqpgOa0)*
pm_math_ET9_5EAP116KvP5KVqsrD2+= *pm_math__lerGssn0Ru_r3kSOzEmI_++**x++;x-=
pm_math_gN74BbsU5wqNjkJbC9b672;}}void pm_math_lin_alg_addMatrixVectorProduct(
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,
pm_math_OUB2pptsvtdGL_LyqpgOa0;if(n==0)return;for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0){const double*
pm_MUnOgYpKkviTC4TqWArmj2=pm_math__lerGssn0Ru_r3kSOzEmI_+
pm_math_SmSSPSQfR1qEYWsVj5ELF0;double pm_math_oDBv6WlDl08lZHtMr3eHu_=0.0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,pm_MUnOgYpKkviTC4TqWArmj2+=
pm_math_gN74BbsU5wqNjkJbC9b672,++x)pm_math_oDBv6WlDl08lZHtMr3eHu_+= *
pm_MUnOgYpKkviTC4TqWArmj2**x;x-=n;*pm_math_ET9_5EAP116KvP5KVqsrD2++ +=
pm_math_oDBv6WlDl08lZHtMr3eHu_;}}void
pm_math_lin_alg_addMatrixVectorProductStrided(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_gG1tYC_1A6mUTedK5sOsQ0,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,
const double*x,double*pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;if(n==0)return;
for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0){const double*
pm_MUnOgYpKkviTC4TqWArmj2=pm_math__lerGssn0Ru_r3kSOzEmI_+
pm_math_SmSSPSQfR1qEYWsVj5ELF0;double pm_math_oDBv6WlDl08lZHtMr3eHu_=0.0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,pm_MUnOgYpKkviTC4TqWArmj2+=
pm_math_gG1tYC_1A6mUTedK5sOsQ0,++x)pm_math_oDBv6WlDl08lZHtMr3eHu_+= *
pm_MUnOgYpKkviTC4TqWArmj2**x;x-=n;*pm_math_ET9_5EAP116KvP5KVqsrD2++ +=
pm_math_oDBv6WlDl08lZHtMr3eHu_;}}void
pm_math_lin_alg_subtractMatrixVectorProduct(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,const double*
pm_math__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,
pm_math_OUB2pptsvtdGL_LyqpgOa0;if(n==0)return;for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0){const double*
pm_MUnOgYpKkviTC4TqWArmj2=pm_math__lerGssn0Ru_r3kSOzEmI_+
pm_math_SmSSPSQfR1qEYWsVj5ELF0;double pm_math_oDBv6WlDl08lZHtMr3eHu_=0.0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,pm_MUnOgYpKkviTC4TqWArmj2+=
pm_math_gN74BbsU5wqNjkJbC9b672,++x)pm_math_oDBv6WlDl08lZHtMr3eHu_+= *
pm_MUnOgYpKkviTC4TqWArmj2**x;x-=n;*pm_math_ET9_5EAP116KvP5KVqsrD2++-=
pm_math_oDBv6WlDl08lZHtMr3eHu_;}}void
pm_math_lin_alg_subtractMatrixVectorProductStrided(uint32_T
pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n,uint32_T
pm_math_gG1tYC_1A6mUTedK5sOsQ0,const double*pm_math__lerGssn0Ru_r3kSOzEmI_,
const double*x,double*pm_math_ET9_5EAP116KvP5KVqsrD2){uint32_T
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;if(n==0)return;
for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<
pm_math_gN74BbsU5wqNjkJbC9b672;++pm_math_SmSSPSQfR1qEYWsVj5ELF0){const double*
pm_MUnOgYpKkviTC4TqWArmj2=pm_math__lerGssn0Ru_r3kSOzEmI_+
pm_math_SmSSPSQfR1qEYWsVj5ELF0;double pm_math_oDBv6WlDl08lZHtMr3eHu_=0.0;for(
pm_math_OUB2pptsvtdGL_LyqpgOa0=0;pm_math_OUB2pptsvtdGL_LyqpgOa0<n;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,pm_MUnOgYpKkviTC4TqWArmj2+=
pm_math_gG1tYC_1A6mUTedK5sOsQ0,++x)pm_math_oDBv6WlDl08lZHtMr3eHu_+= *
pm_MUnOgYpKkviTC4TqWArmj2**x;x-=n;*pm_math_ET9_5EAP116KvP5KVqsrD2++-=
pm_math_oDBv6WlDl08lZHtMr3eHu_;}}double pm_math_lin_alg_computeQuadraticTerm(
uint32_T n,const double*pm_math_0Ku4r8_UTD6dwsQGuIlz31,const double*
pm_math_MJ6HaMWdyRxHm3p_EZiD41,const double*pm_math_ljExW6hRw43Vg4SLQUAvT1){
uint32_T pm_math_2KXuAphrqc_TLcinUGD4E1,pm_math_ojAHyVHgbHhAjmJFnG_l31;double x
=0.0;for(pm_math_ojAHyVHgbHhAjmJFnG_l31=0;pm_math_ojAHyVHgbHhAjmJFnG_l31<n;++
pm_math_ojAHyVHgbHhAjmJFnG_l31){double pm_math_ET9_5EAP116KvP5KVqsrD2=0.0;for(
pm_math_2KXuAphrqc_TLcinUGD4E1=0;pm_math_2KXuAphrqc_TLcinUGD4E1<n;++
pm_math_2KXuAphrqc_TLcinUGD4E1)pm_math_ET9_5EAP116KvP5KVqsrD2+= *
pm_math_0Ku4r8_UTD6dwsQGuIlz31++**pm_math_MJ6HaMWdyRxHm3p_EZiD41++;
pm_math_MJ6HaMWdyRxHm3p_EZiD41-=n;x+=pm_math_ET9_5EAP116KvP5KVqsrD2**
pm_math_ljExW6hRw43Vg4SLQUAvT1++;}return x;}
