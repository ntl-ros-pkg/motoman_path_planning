#include "pm_std.h"
#include "string.h"
#include "pm_std.h"
struct sm_NzvvUKK0hMzD7r4JwDuGM2{unsigned int sm_gd0O0pXJpcT0Jt_NlyJMv2;size_t
sm_Igdr4Y_cPmRaM2PLPRasV0;size_t sm_jwDZsse5x6bDFuuHWkiJ0_;boolean_T
sm_Q8_LxeXa_g84Su_s9RpPz_;int sm_zDV13l8tMIL84YD8H31hC0;unsigned int
sm_N0PI2TSttNMIAAgHw49fM1;char*sm_cwz1BSpSBWnmCTQIY0Qai1;boolean_T
sm_OZdNFvBSa6OPmy8JVKp0r1;boolean_T sm_UvCUTAN0IRwlrQ17HbAGN2;real_T
sm_5GprM10kc3KAFSaXqddGY2;boolean_T sm_w4m3TJlhbnRYCj33GZ8u22;size_t
sm_oye3COwGt0OcUE2FiS4un2;real_T sm_9k3t9MF_cDMi3uAvvnmOo1[4];real_T
sm_0QK4DNzVIFGJ4co71RDJ32[1];};typedef struct sm_NzvvUKK0hMzD7r4JwDuGM2
sm_CVo3J_yjos4G6qFktBg1w1;void sm_compiler_CTarget_create(
sm_CVo3J_yjos4G6qFktBg1w1*sm_o0CzD7LRNgbJzr_O_yQxZ2);void
sm_compiler_CTarget_copy(const sm_CVo3J_yjos4G6qFktBg1w1*orig,
sm_CVo3J_yjos4G6qFktBg1w1*sm_qZ_cQkm1rd_H40WuqsAhi1);void
sm_compiler_CTarget_destroy(sm_CVo3J_yjos4G6qFktBg1w1*
sm_o0CzD7LRNgbJzr_O_yQxZ2);void sm_compiler_CTarget_setSpecifiedUnit(const char
*sm_oZw69STiPFtHvoIlOazbs_,sm_CVo3J_yjos4G6qFktBg1w1*sm_o0CzD7LRNgbJzr_O_yQxZ2
);void sm_compiler_CTarget_create(sm_CVo3J_yjos4G6qFktBg1w1*
sm_o0CzD7LRNgbJzr_O_yQxZ2){int sm_SmSSPSQfR1qEYWsVj5ELF0;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_gd0O0pXJpcT0Jt_NlyJMv2=(unsigned int)-1;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_Igdr4Y_cPmRaM2PLPRasV0=(size_t)-1;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_jwDZsse5x6bDFuuHWkiJ0_=(size_t)-1;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_Q8_LxeXa_g84Su_s9RpPz_=false;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_zDV13l8tMIL84YD8H31hC0=0;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_N0PI2TSttNMIAAgHw49fM1=(unsigned int)-1;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_cwz1BSpSBWnmCTQIY0Qai1=NULL;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_OZdNFvBSa6OPmy8JVKp0r1=false;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_UvCUTAN0IRwlrQ17HbAGN2=false;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_5GprM10kc3KAFSaXqddGY2=1.0;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_w4m3TJlhbnRYCj33GZ8u22=false;
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_oye3COwGt0OcUE2FiS4un2=0;for(
sm_SmSSPSQfR1qEYWsVj5ELF0=0;sm_SmSSPSQfR1qEYWsVj5ELF0<4;++
sm_SmSSPSQfR1qEYWsVj5ELF0)sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_9k3t9MF_cDMi3uAvvnmOo1
[sm_SmSSPSQfR1qEYWsVj5ELF0]=0.0;sm_o0CzD7LRNgbJzr_O_yQxZ2->
sm_0QK4DNzVIFGJ4co71RDJ32[0]=0.0;}static void sm_Yqn58CIxNDn4lMuldFYDs1(char**
dst,const char*src){pmf_free(*dst);if(src==NULL)*dst=NULL;else{const size_t
sm_BLtgaCJHPSc5R72eJ5uex0=(strlen(src)+1)*sizeof(char);*dst=pmf_malloc(
sm_BLtgaCJHPSc5R72eJ5uex0);memcpy(*dst,src,sm_BLtgaCJHPSc5R72eJ5uex0);}}void
sm_compiler_CTarget_copy(const sm_CVo3J_yjos4G6qFktBg1w1*orig,
sm_CVo3J_yjos4G6qFktBg1w1*sm_qZ_cQkm1rd_H40WuqsAhi1){sm_qZ_cQkm1rd_H40WuqsAhi1
->sm_gd0O0pXJpcT0Jt_NlyJMv2=orig->sm_gd0O0pXJpcT0Jt_NlyJMv2;
sm_qZ_cQkm1rd_H40WuqsAhi1->sm_Igdr4Y_cPmRaM2PLPRasV0=orig->
sm_Igdr4Y_cPmRaM2PLPRasV0;sm_qZ_cQkm1rd_H40WuqsAhi1->sm_jwDZsse5x6bDFuuHWkiJ0_
=orig->sm_jwDZsse5x6bDFuuHWkiJ0_;sm_qZ_cQkm1rd_H40WuqsAhi1->
sm_Q8_LxeXa_g84Su_s9RpPz_=orig->sm_Q8_LxeXa_g84Su_s9RpPz_;
sm_qZ_cQkm1rd_H40WuqsAhi1->sm_zDV13l8tMIL84YD8H31hC0=orig->
sm_zDV13l8tMIL84YD8H31hC0;sm_qZ_cQkm1rd_H40WuqsAhi1->sm_N0PI2TSttNMIAAgHw49fM1
=orig->sm_N0PI2TSttNMIAAgHw49fM1;sm_qZ_cQkm1rd_H40WuqsAhi1->
sm_cwz1BSpSBWnmCTQIY0Qai1=NULL;sm_Yqn58CIxNDn4lMuldFYDs1(&
sm_qZ_cQkm1rd_H40WuqsAhi1->sm_cwz1BSpSBWnmCTQIY0Qai1,orig->
sm_cwz1BSpSBWnmCTQIY0Qai1);sm_qZ_cQkm1rd_H40WuqsAhi1->
sm_OZdNFvBSa6OPmy8JVKp0r1=orig->sm_OZdNFvBSa6OPmy8JVKp0r1;
sm_qZ_cQkm1rd_H40WuqsAhi1->sm_UvCUTAN0IRwlrQ17HbAGN2=orig->
sm_UvCUTAN0IRwlrQ17HbAGN2;sm_qZ_cQkm1rd_H40WuqsAhi1->sm_5GprM10kc3KAFSaXqddGY2
=orig->sm_5GprM10kc3KAFSaXqddGY2;sm_qZ_cQkm1rd_H40WuqsAhi1->
sm_w4m3TJlhbnRYCj33GZ8u22=orig->sm_w4m3TJlhbnRYCj33GZ8u22;
sm_qZ_cQkm1rd_H40WuqsAhi1->sm_oye3COwGt0OcUE2FiS4un2=orig->
sm_oye3COwGt0OcUE2FiS4un2;memcpy(sm_qZ_cQkm1rd_H40WuqsAhi1->
sm_9k3t9MF_cDMi3uAvvnmOo1,orig->sm_9k3t9MF_cDMi3uAvvnmOo1,4*sizeof(double));
memcpy(sm_qZ_cQkm1rd_H40WuqsAhi1->sm_0QK4DNzVIFGJ4co71RDJ32,orig->
sm_0QK4DNzVIFGJ4co71RDJ32,1*sizeof(double));}void sm_compiler_CTarget_destroy(
sm_CVo3J_yjos4G6qFktBg1w1*sm_o0CzD7LRNgbJzr_O_yQxZ2){pmf_free(
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_cwz1BSpSBWnmCTQIY0Qai1);}void
sm_compiler_CTarget_setSpecifiedUnit(const char*sm_oZw69STiPFtHvoIlOazbs_,
sm_CVo3J_yjos4G6qFktBg1w1*sm_o0CzD7LRNgbJzr_O_yQxZ2){pmf_free(
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_cwz1BSpSBWnmCTQIY0Qai1);if(
sm_oZw69STiPFtHvoIlOazbs_==NULL)sm_o0CzD7LRNgbJzr_O_yQxZ2->
sm_cwz1BSpSBWnmCTQIY0Qai1=NULL;else{const size_t sm_BLtgaCJHPSc5R72eJ5uex0=(
strlen(sm_oZw69STiPFtHvoIlOazbs_)+1)*sizeof(char);sm_o0CzD7LRNgbJzr_O_yQxZ2->
sm_cwz1BSpSBWnmCTQIY0Qai1=pmf_malloc(sm_BLtgaCJHPSc5R72eJ5uex0);memcpy(
sm_o0CzD7LRNgbJzr_O_yQxZ2->sm_cwz1BSpSBWnmCTQIY0Qai1,sm_oZw69STiPFtHvoIlOazbs_
,sm_BLtgaCJHPSc5R72eJ5uex0);}}
