#include "pm_std.h"
#include "pm_std.h"
int_T pm_FBD_ZCGRyF9Zix4mvl6Ip0(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
size_t pm_JhTijL0ZlABf2EhQiFVX71,size_t pm_qYV3thKugwWwSrIbTfcS10,size_t
pm_8oezoIPNG9LZPP18xVIrw_,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_JhTijL0ZlABf2EhQiFVX71,
size_t pm_qYV3thKugwWwSrIbTfcS10,size_t pm_8oezoIPNG9LZPP18xVIrw_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_3YYVuJb7mmfC_9_znq5yH2(PmSparsityPattern*
pm_xhS7ip83N1al9vsl9z_jP2,const PmSparsityPattern*pm_7CpwkWeWUw6deoCGAHlcg0);
boolean_T pm_F9dzGbF9bw2QlZyj3V1Gf_(const PmSparsityPattern*
pm_xhS7ip83N1al9vsl9z_jP2,const PmSparsityPattern*pm_7CpwkWeWUw6deoCGAHlcg0);
PmSparsityPattern*pm_9oMk0xBPD28NQC6egedGY2(const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_s_tA_vyom56bxaGbqlGcb0(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);void pm_06dTzOwkhN7oGBM_7J2hK1(
PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*pm_OLpBo6MxIVPIjv0_z_qCc2(size_t
pm_WkDzWdo3HJglufgddrvj_1,size_t pm_Y_WQkyfqLWq4_EV8mXQjt_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*pm_8BokEnlj2bsehUZ6VBVqc0(size_t
pm_WkDzWdo3HJglufgddrvj_1,size_t pm_Y_WQkyfqLWq4_EV8mXQjt_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*pm_LPeaDYoYWpCMrX0FHDZrj2(size_t
pm_KYlcoOk9rSSGYswizhYqZ2,size_t n,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmSparsityPattern*pm_Fd_reSzeOBuDPZtoIWlnj0(size_t n,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_rv_equals_rv(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_TnPSeUZeYw5Wc8bvD8sl80(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);void pm_fKS8kuV7G_WhlO7CcdVnc1(const PmCharVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm___43lXp90F4bzSkAXqYfT1(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);int_T
pm_create_real_vector_fields(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_create_real_vector(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(const PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_real_vector(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_int_vector_fields(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_create_int_vector(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*
pm_pLia5sG_NxTeQbxzYtpXx_(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_Rdk2CZ3CCj5T0d2uDHUZ20(
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_destroy_int_vector(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_SK8Vck8jU45BIyJDK11DV_(
PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_Or6MViYTj4_1rM_3pn1UZ0(
const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_cn_kUNHZ0hjihWokUKapj_(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_nUREx2_I6_H8Z9q4fW3LX2(
PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);
#include "pm_std.h"
#include "string.h"
int_T pm_FBD_ZCGRyF9Zix4mvl6Ip0(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
size_t pm_JhTijL0ZlABf2EhQiFVX71,size_t pm_qYV3thKugwWwSrIbTfcS10,size_t
pm_8oezoIPNG9LZPP18xVIrw_,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2){int_T
pm_G9Ug5Uhj979D3_dBSwlTW0=0;pm_Pc8_RQ7nsOlzNUh7aYI680->mNumRow=
pm_qYV3thKugwWwSrIbTfcS10;pm_Pc8_RQ7nsOlzNUh7aYI680->mNumCol=
pm_8oezoIPNG9LZPP18xVIrw_;if(!(pm_Pc8_RQ7nsOlzNUh7aYI680->mJc=(int32_T*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
int32_T)),(pm_Pc8_RQ7nsOlzNUh7aYI680->mNumCol+1))))){pm_G9Ug5Uhj979D3_dBSwlTW0
+=1;}else if(pm_JhTijL0ZlABf2EhQiFVX71==0){pm_Pc8_RQ7nsOlzNUh7aYI680->mIr=NULL
;}else if(!(pm_Pc8_RQ7nsOlzNUh7aYI680->mIr=(int32_T*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
int32_T)),(pm_JhTijL0ZlABf2EhQiFVX71))))){pm_G9Ug5Uhj979D3_dBSwlTW0+=1;}((
pm_Pc8_RQ7nsOlzNUh7aYI680)->mJc[(pm_Pc8_RQ7nsOlzNUh7aYI680)->mNumCol]=(int32_T
)(pm_JhTijL0ZlABf2EhQiFVX71));return pm_G9Ug5Uhj979D3_dBSwlTW0;}
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_JhTijL0ZlABf2EhQiFVX71,
size_t pm_qYV3thKugwWwSrIbTfcS10,size_t pm_8oezoIPNG9LZPP18xVIrw_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680=(
PmSparsityPattern*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->mCallocFcn((
pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(PmSparsityPattern)),(1)));if(
pm_Pc8_RQ7nsOlzNUh7aYI680){if(pm_FBD_ZCGRyF9Zix4mvl6Ip0(
pm_Pc8_RQ7nsOlzNUh7aYI680,pm_JhTijL0ZlABf2EhQiFVX71,pm_qYV3thKugwWwSrIbTfcS10,
pm_8oezoIPNG9LZPP18xVIrw_,pm_WFHqm0fOpgfhKZFbY5NWh2)){{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_Pc8_RQ7nsOlzNUh7aYI680);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};
pm_Pc8_RQ7nsOlzNUh7aYI680=NULL;}}return pm_Pc8_RQ7nsOlzNUh7aYI680;}void
pm_3YYVuJb7mmfC_9_znq5yH2(PmSparsityPattern*pm_xhS7ip83N1al9vsl9z_jP2,const
PmSparsityPattern*pm_7CpwkWeWUw6deoCGAHlcg0){;;;memcpy(
pm_xhS7ip83N1al9vsl9z_jP2->mJc,pm_7CpwkWeWUw6deoCGAHlcg0->mJc,sizeof(int32_T)*
(pm_xhS7ip83N1al9vsl9z_jP2->mNumCol+1));memcpy(pm_xhS7ip83N1al9vsl9z_jP2->mIr,
pm_7CpwkWeWUw6deoCGAHlcg0->mIr,sizeof(int32_T)*((size_t)(
pm_xhS7ip83N1al9vsl9z_jP2)->mJc[(pm_xhS7ip83N1al9vsl9z_jP2)->mNumCol]));}
boolean_T pm_F9dzGbF9bw2QlZyj3V1Gf_(const PmSparsityPattern*
pm_xhS7ip83N1al9vsl9z_jP2,const PmSparsityPattern*pm_7CpwkWeWUw6deoCGAHlcg0){;
;;return(memcmp(pm_xhS7ip83N1al9vsl9z_jP2->mJc,pm_7CpwkWeWUw6deoCGAHlcg0->mJc,
sizeof(int32_T)*(pm_xhS7ip83N1al9vsl9z_jP2->mNumCol+1))==0)&&(memcmp(
pm_xhS7ip83N1al9vsl9z_jP2->mIr,pm_7CpwkWeWUw6deoCGAHlcg0->mIr,sizeof(int32_T)*
((size_t)(pm_xhS7ip83N1al9vsl9z_jP2)->mJc[(pm_xhS7ip83N1al9vsl9z_jP2)->mNumCol
]))==0);}PmSparsityPattern*pm_9oMk0xBPD28NQC6egedGY2(const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){
PmSparsityPattern*pm_QyVbO3pTvGiccU8Tn2eK2_=pm_create_sparsity_pattern(((
size_t)(pm_PJaAk_OAdWPbuizgCm_rK1)->mJc[(pm_PJaAk_OAdWPbuizgCm_rK1)->mNumCol])
,pm_PJaAk_OAdWPbuizgCm_rK1->mNumRow,pm_PJaAk_OAdWPbuizgCm_rK1->mNumCol,
pm_WFHqm0fOpgfhKZFbY5NWh2);pm_3YYVuJb7mmfC_9_znq5yH2(pm_QyVbO3pTvGiccU8Tn2eK2_
,pm_PJaAk_OAdWPbuizgCm_rK1);return pm_QyVbO3pTvGiccU8Tn2eK2_;}void
pm_s_tA_vyom56bxaGbqlGcb0(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2){;{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(
pm_Pc8_RQ7nsOlzNUh7aYI680->mJc);if(pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
pm_GAbHnJspJ6sMhe_Yzxehb_);}};if(pm_Pc8_RQ7nsOlzNUh7aYI680->mIr!=NULL){{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_Pc8_RQ7nsOlzNUh7aYI680->mIr);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(
pm_an0wiQTjdlKE72zC6FJ0a2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}}void
pm_06dTzOwkhN7oGBM_7J2hK1(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){;pm_s_tA_vyom56bxaGbqlGcb0(
pm_Pc8_RQ7nsOlzNUh7aYI680,pm_WFHqm0fOpgfhKZFbY5NWh2);{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_Pc8_RQ7nsOlzNUh7aYI680);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}PmSparsityPattern*
pm_OLpBo6MxIVPIjv0_z_qCc2(size_t pm_WkDzWdo3HJglufgddrvj_1,size_t
pm_Y_WQkyfqLWq4_EV8mXQjt_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){
PmSparsityPattern*pm_MmLrrwwhsBMHVLmxSqDhQ0=pm_create_sparsity_pattern(
pm_Y_WQkyfqLWq4_EV8mXQjt_*pm_WkDzWdo3HJglufgddrvj_1,pm_WkDzWdo3HJglufgddrvj_1,
pm_Y_WQkyfqLWq4_EV8mXQjt_,pm_WFHqm0fOpgfhKZFbY5NWh2);size_t
pm_SmSSPSQfR1qEYWsVj5ELF0,pm_OUB2pptsvtdGL_LyqpgOa0;int32_T*
pm_rX2Nhyrokuq9JmnRvEAkJ1=pm_MmLrrwwhsBMHVLmxSqDhQ0->mIr;int32_T*
pm_S51jjFL079S8kdC86krPC0=pm_MmLrrwwhsBMHVLmxSqDhQ0->mJc;for(
pm_SmSSPSQfR1qEYWsVj5ELF0=0;pm_SmSSPSQfR1qEYWsVj5ELF0<=
pm_Y_WQkyfqLWq4_EV8mXQjt_;pm_SmSSPSQfR1qEYWsVj5ELF0++){
pm_S51jjFL079S8kdC86krPC0[pm_SmSSPSQfR1qEYWsVj5ELF0]=((int32_T)(
pm_SmSSPSQfR1qEYWsVj5ELF0*pm_WkDzWdo3HJglufgddrvj_1));}if(
pm_WkDzWdo3HJglufgddrvj_1*pm_Y_WQkyfqLWq4_EV8mXQjt_>0){for(
pm_OUB2pptsvtdGL_LyqpgOa0=0;pm_OUB2pptsvtdGL_LyqpgOa0<
pm_WkDzWdo3HJglufgddrvj_1;pm_OUB2pptsvtdGL_LyqpgOa0++){
pm_rX2Nhyrokuq9JmnRvEAkJ1[pm_OUB2pptsvtdGL_LyqpgOa0]=((int32_T)(
pm_OUB2pptsvtdGL_LyqpgOa0));}for(pm_SmSSPSQfR1qEYWsVj5ELF0=1;
pm_SmSSPSQfR1qEYWsVj5ELF0<pm_Y_WQkyfqLWq4_EV8mXQjt_;pm_SmSSPSQfR1qEYWsVj5ELF0
++){memcpy(&pm_rX2Nhyrokuq9JmnRvEAkJ1[pm_SmSSPSQfR1qEYWsVj5ELF0*
pm_WkDzWdo3HJglufgddrvj_1],pm_rX2Nhyrokuq9JmnRvEAkJ1,pm_WkDzWdo3HJglufgddrvj_1
*sizeof(int32_T));}};return pm_MmLrrwwhsBMHVLmxSqDhQ0;}PmSparsityPattern*
pm_8BokEnlj2bsehUZ6VBVqc0(size_t pm_N_wD7K9nVNKe6C2bzkNt12,size_t
pm_XuLbKfBryh9bMqt9IZ9t_2,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2){
PmSparsityPattern*pm_3fmwBoA2gfKGlaDfp8GCd1=pm_create_sparsity_pattern(0,
pm_N_wD7K9nVNKe6C2bzkNt12,pm_XuLbKfBryh9bMqt9IZ9t_2,pm_an0wiQTjdlKE72zC6FJ0a2)
;memset(pm_3fmwBoA2gfKGlaDfp8GCd1->mJc,0,(pm_XuLbKfBryh9bMqt9IZ9t_2+1)*sizeof(
int32_T));;;return pm_3fmwBoA2gfKGlaDfp8GCd1;}PmSparsityPattern*
pm_LPeaDYoYWpCMrX0FHDZrj2(size_t pm_KYlcoOk9rSSGYswizhYqZ2,size_t n,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmSparsityPattern*
pm_QyVbO3pTvGiccU8Tn2eK2_=pm_create_sparsity_pattern(pm_KYlcoOk9rSSGYswizhYqZ2
,n,n,pm_WFHqm0fOpgfhKZFbY5NWh2);int32_T*pm_pNMIRhfguzhMVFu2H9bJJ_=
pm_QyVbO3pTvGiccU8Tn2eK2_->mJc;int32_T*pm_LqLb_As8E_5HhW5pWJzYs_=
pm_QyVbO3pTvGiccU8Tn2eK2_->mIr;size_t pm_SmSSPSQfR1qEYWsVj5ELF0=0;;for(
pm_SmSSPSQfR1qEYWsVj5ELF0=0;pm_SmSSPSQfR1qEYWsVj5ELF0<
pm_KYlcoOk9rSSGYswizhYqZ2;pm_SmSSPSQfR1qEYWsVj5ELF0++){
pm_LqLb_As8E_5HhW5pWJzYs_[pm_SmSSPSQfR1qEYWsVj5ELF0]=pm_pNMIRhfguzhMVFu2H9bJJ_
[pm_SmSSPSQfR1qEYWsVj5ELF0]=((int32_T)(pm_SmSSPSQfR1qEYWsVj5ELF0));}for(
pm_SmSSPSQfR1qEYWsVj5ELF0=pm_KYlcoOk9rSSGYswizhYqZ2;pm_SmSSPSQfR1qEYWsVj5ELF0
<=n;pm_SmSSPSQfR1qEYWsVj5ELF0++){pm_pNMIRhfguzhMVFu2H9bJJ_[
pm_SmSSPSQfR1qEYWsVj5ELF0]=((int32_T)(pm_KYlcoOk9rSSGYswizhYqZ2));}return
pm_QyVbO3pTvGiccU8Tn2eK2_;}PmSparsityPattern*pm_Fd_reSzeOBuDPZtoIWlnj0(size_t n
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){return pm_LPeaDYoYWpCMrX0FHDZrj2(n,n,
pm_WFHqm0fOpgfhKZFbY5NWh2);}
