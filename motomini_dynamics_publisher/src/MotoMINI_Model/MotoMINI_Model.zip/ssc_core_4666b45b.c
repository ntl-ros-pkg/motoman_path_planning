#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "pm_std.h"
typedef struct ssc_core_04lJVV8RZhe3jygfue5A1_ ssc_core_5zxEagrsF7Wap5juktdFc0
;typedef struct ssc_core_iGaJLE_NC_PxrHqCLfO_C0 ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02
;struct ssc_core_iGaJLE_NC_PxrHqCLfO_C0{PmfMessageId(*
mc_pUffb7sEscFTTREED1TgL0)(const ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*
ssc_core_c_eEG2hLgM5g0tIChdlGB1,const NeSystemInput*mc_w2sbHOBWMTHvn1ViunNc91)
;PmfMessageId(*ssc_core_zV6Z2HwJAw62xLg0_4KC90)(const
ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*ssc_core_c_eEG2hLgM5g0tIChdlGB1,const
NeSystemInput*mc_w2sbHOBWMTHvn1ViunNc91);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*);ssc_core_5zxEagrsF7Wap5juktdFc0*
mc_0TyJOxmrCFOwXODumYaSw2;};ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*
ssc_core_QASum97EN_NK90eDhNPce2(PmAllocator*mc_J3BYejxvpAX9ghSFCe0tN1);
#include "pm_std.h"
struct ssc_core_04lJVV8RZhe3jygfue5A1_{PmAllocator*
ssc_core_EJyLFJLNS54LEp1_ia1250;};static PmfMessageId
ssc_core_rAkCMmvREyNGY_QiC7ZbB0(const ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*
ssc_core_c_eEG2hLgM5g0tIChdlGB1,const NeSystemInput*mc_w2sbHOBWMTHvn1ViunNc91)
{(void)ssc_core_c_eEG2hLgM5g0tIChdlGB1;(void)mc_w2sbHOBWMTHvn1ViunNc91;return
NULL;}static PmfMessageId ssc_core_hJ2awXaeud63OlD6qHpzs1(const
ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*ssc_core_c_eEG2hLgM5g0tIChdlGB1,const
NeSystemInput*mc_w2sbHOBWMTHvn1ViunNc91){(void)ssc_core_c_eEG2hLgM5g0tIChdlGB1
;(void)mc_w2sbHOBWMTHvn1ViunNc91;return NULL;}static void
ssc_core_GvOkOwWc6qAOBOY14fuPD2(ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*
ssc_core_c_eEG2hLgM5g0tIChdlGB1){PmAllocator*mc_J3BYejxvpAX9ghSFCe0tN1=
ssc_core_c_eEG2hLgM5g0tIChdlGB1->mc_0TyJOxmrCFOwXODumYaSw2->
ssc_core_EJyLFJLNS54LEp1_ia1250;{void*ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(
ssc_core_c_eEG2hLgM5g0tIChdlGB1->mc_0TyJOxmrCFOwXODumYaSw2);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_J3BYejxvpAX9ghSFCe0tN1)->mFreeFcn(
mc_J3BYejxvpAX9ghSFCe0tN1,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};{void*
ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(ssc_core_c_eEG2hLgM5g0tIChdlGB1);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_J3BYejxvpAX9ghSFCe0tN1)->mFreeFcn(
mc_J3BYejxvpAX9ghSFCe0tN1,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};}
ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*ssc_core_QASum97EN_NK90eDhNPce2(PmAllocator*
mc_J3BYejxvpAX9ghSFCe0tN1){ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*
ssc_core_P9dPVvlqCKCFiKaxNQkV00=(ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02*)((
mc_J3BYejxvpAX9ghSFCe0tN1)->mCallocFcn((mc_J3BYejxvpAX9ghSFCe0tN1),(sizeof(
ssc_core_M0WFrgMwAEfQ3Vo_Q_kd02)),(1)));ssc_core_5zxEagrsF7Wap5juktdFc0*
mc_6peHhhgu8wo0Kp3HDh_aI0=(ssc_core_5zxEagrsF7Wap5juktdFc0*)((
mc_J3BYejxvpAX9ghSFCe0tN1)->mCallocFcn((mc_J3BYejxvpAX9ghSFCe0tN1),(sizeof(
ssc_core_5zxEagrsF7Wap5juktdFc0)),(1)));mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core_EJyLFJLNS54LEp1_ia1250=mc_J3BYejxvpAX9ghSFCe0tN1;
ssc_core_P9dPVvlqCKCFiKaxNQkV00->mc_pUffb7sEscFTTREED1TgL0=
ssc_core_rAkCMmvREyNGY_QiC7ZbB0;ssc_core_P9dPVvlqCKCFiKaxNQkV00->
ssc_core_zV6Z2HwJAw62xLg0_4KC90=ssc_core_hJ2awXaeud63OlD6qHpzs1;
ssc_core_P9dPVvlqCKCFiKaxNQkV00->mc_YCFci8IAJkK9w_xpRtHta2=
ssc_core_GvOkOwWc6qAOBOY14fuPD2;ssc_core_P9dPVvlqCKCFiKaxNQkV00->
mc_0TyJOxmrCFOwXODumYaSw2=mc_6peHhhgu8wo0Kp3HDh_aI0;return
ssc_core_P9dPVvlqCKCFiKaxNQkV00;}
