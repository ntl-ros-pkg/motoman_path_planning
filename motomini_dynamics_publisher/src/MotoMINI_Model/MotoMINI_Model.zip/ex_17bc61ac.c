#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_8GXoVYNB7xMB70dsCbAyA0(const real_T*a,const size_t n);real_T
ex_N_clXqffVCzi68eTuA7Z92(const real_T x);void ex_hvjqVE7WfEAt6jcTNsW1u1(
real_T*fx1,real_T*ex_qqj_9pClxpUaveq616vWX_,real_T*ex_ODvhPeUiIMv_N9a0J2IIb_,
real_T*ex_LoObIqjlDGtLzUnGZVFIh_,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51,const size_t
ex_VkP8sW5ujEbh_RG29El9R_,const size_t ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t
ex_2Y91_CRjyUMrCFE4844Jf2,const size_t ex_Ea66QGACnnAzBr5cQEISd_,const size_t
ex_Lyxgt0ApsOxYV7SxIdPws0,const size_t ex_FWzS4LG9JH3q_zkgeM_bR_,const size_t
ex_B6u9Yh3NFQBXCHXd_cy3L1,const size_t ex_2VFGnsOS8QAJGmX42jhDs2,const real_T
ex_9R2ICyFZrMWnnqVz69LS_0);void ex_8Lr4A0sHb9kykh8D_nd4y1(real_T*
ex_fIUN8VRWYW_vvrJBW8lXr0,real_T*ex_CC2nBop_AzM8GWVhi5l_y_,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51,const size_t ex_VkP8sW5ujEbh_RG29El9R_,const size_t
ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t ex_2Y91_CRjyUMrCFE4844Jf2,const size_t
ex_Ea66QGACnnAzBr5cQEISd_,const size_t ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t
ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t ex_tgAG8_0Nazq7r3JqH9poq_,const size_t
ex_DZjm31wkoWuZA_gQ2ngh90,const size_t ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t
ex_Crw725fjFuk9WoyqNW5D90,const size_t ex_216LSH5aKi96he3yzgTIY2,const size_t
ex_5mllB3D9zrHViNrvMthgP_,const real_T ex_9R2ICyFZrMWnnqVz69LS_0,const real_T
ex_Cx97aITo5DLOpdlBjw0Ev2);void ex_c908i9DZYVP8NLFJeVsnP_(real_T*
ex_dWVCFoCXPoLwscxjXxh7F0,real_T*ex_t0DOW86Hne7Cet0k6nxk50,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const real_T*ex_spvq_BLax0ZY7BWNVJdV3_,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51,const size_t
ex_VkP8sW5ujEbh_RG29El9R_,const size_t ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t
ex_2Y91_CRjyUMrCFE4844Jf2,const size_t ex_Ea66QGACnnAzBr5cQEISd_,const size_t
ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t
ex_tgAG8_0Nazq7r3JqH9poq_,const size_t ex_DZjm31wkoWuZA_gQ2ngh90,const size_t
ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t ex_Crw725fjFuk9WoyqNW5D90,const size_t
ex_216LSH5aKi96he3yzgTIY2,const size_t ex_5mllB3D9zrHViNrvMthgP_,const size_t
ex_dfsGKZ4SOnBWg0_LthaSE1,const size_t ex_f_G4CiEEGpLNC_d__6Otr_,const size_t
ex_sPax9bjJmVREGHAn0mqfe1,const size_t ex_V_jgHYQ6HxaicixaD4B4m_,const real_T
ex_9R2ICyFZrMWnnqVz69LS_0,const real_T ex_Cx97aITo5DLOpdlBjw0Ev2,const real_T
ex_wtdXVMGIS6xhoVmY9M2nE0);void ex_g6tFmYqTirCa3ZPS1u16h0(real_T*
ex_X3vLkYlbdpuLDjBGk57vo_,real_T*ex_WV0gRaOXjiFGQaR18XBfo_,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const real_T*ex_spvq_BLax0ZY7BWNVJdV3_,const real_T*
ex_YZ_rgSdzO2vZDxo7EhthC1,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51,const size_t ex_VkP8sW5ujEbh_RG29El9R_,const size_t
ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t ex_2Y91_CRjyUMrCFE4844Jf2,const size_t
ex_Ea66QGACnnAzBr5cQEISd_,const size_t ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t
ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t ex_tgAG8_0Nazq7r3JqH9poq_,const size_t
ex_DZjm31wkoWuZA_gQ2ngh90,const size_t ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t
ex_Crw725fjFuk9WoyqNW5D90,const size_t ex_216LSH5aKi96he3yzgTIY2,const size_t
ex_5mllB3D9zrHViNrvMthgP_,const size_t ex_dfsGKZ4SOnBWg0_LthaSE1,const size_t
ex_f_G4CiEEGpLNC_d__6Otr_,const size_t ex_sPax9bjJmVREGHAn0mqfe1,const size_t
ex_V_jgHYQ6HxaicixaD4B4m_,const size_t ex_U9lWWqx0jFokA4xwwiPb71,const size_t
ex_2rLQUCwyQWFWspPbF4UpE2,const size_t ex_BL4aaq_PAxk1Nxu_rJOWw0,const size_t
ex_y90_D_qMktK1Fkn1BdLpK2,const real_T ex_9R2ICyFZrMWnnqVz69LS_0,const real_T
ex_Cx97aITo5DLOpdlBjw0Ev2,const real_T ex_wtdXVMGIS6xhoVmY9M2nE0,const real_T
ex_Wu5vsdT_Yw4IM6TngEpjz1);size_t ex_EPCusphBPNYsP9i21jsva0(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_XPTig2EtwH6R7_NgNRUTK0,const boolean_T
ex_Qmu676yE9oxL758xSv1lO1);size_t ex_ia6STLGqo9aFeiYN0gcmB_(real_T*H,real_T*G,
size_t*numEdges,const real_T*x,const size_t n,const real_T t,const boolean_T*
mode,const boolean_T ex_1YXwEl8_6cUeYGB_i0l0p2);
#include "lang_std.h"
void tlu2_linear_linear_prelookup(real_T*H,real_T*G,size_t*numEdges,size_t*bin
,const real_T*x,const real_T*t,const boolean_T*mode,const size_t*n){*bin=
ex_ia6STLGqo9aFeiYN0gcmB_(H,G,numEdges,x,*n,*t,mode,true);}void
tlu2_linear_linear_prelookup_custom_function_(void*out,const void*in){const
real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(const real_T
*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T*)((const
void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*)in)[3];
real_T*H=(real_T*)((void**)out)[0];real_T*G=(real_T*)((void**)out)[1];size_t*
numEdges=(size_t*)((void**)out)[2];size_t*bin=(size_t*)((void**)out)[3];
tlu2_linear_linear_prelookup(H,G,numEdges,bin,x,t,mode,n);}void
tlu2_linear_nearest_prelookup(real_T*H,real_T*G,size_t*numEdges,size_t*bin,
const real_T*x,const real_T*t,const boolean_T*mode,const size_t*n){*bin=
ex_ia6STLGqo9aFeiYN0gcmB_(H,G,numEdges,x,*n,*t,mode,false);}void
tlu2_linear_nearest_prelookup_custom_function_(void*out,const void*in){const
real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(const real_T
*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T*)((const
void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*)in)[3];
real_T*H=(real_T*)((void**)out)[0];real_T*G=(real_T*)((void**)out)[1];size_t*
numEdges=(size_t*)((void**)out)[2];size_t*bin=(size_t*)((void**)out)[3];
tlu2_linear_nearest_prelookup(H,G,numEdges,bin,x,t,mode,n);}void
tlu2_akima_linear_prelookup(real_T*H,real_T*Hx,real_T*G,real_T*Gx,size_t*
numEdges,size_t*bin,const real_T*x,const real_T*t,const boolean_T*mode,const
size_t*n){*bin=ex_EPCusphBPNYsP9i21jsva0(H,Hx,G,Gx,numEdges,x,*n,*t,mode,1.0,
true);}void tlu2_akima_linear_prelookup_custom_function_(void*out,const void*
in){const real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(
const real_T*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T
*)((const void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*
)in)[3];real_T*H=(real_T*)((void**)out)[0];real_T*Hx=(real_T*)((void**)out)[1]
;real_T*G=(real_T*)((void**)out)[2];real_T*Gx=(real_T*)((void**)out)[3];size_t
*numEdges=(size_t*)((void**)out)[4];size_t*bin=(size_t*)((void**)out)[5];
tlu2_akima_linear_prelookup(H,Hx,G,Gx,numEdges,bin,x,t,mode,n);}void
tlu2_akima_nearest_prelookup(real_T*H,real_T*Hx,real_T*G,real_T*Gx,size_t*
numEdges,size_t*bin,const real_T*x,const real_T*t,const boolean_T*mode,const
size_t*n){*bin=ex_EPCusphBPNYsP9i21jsva0(H,Hx,G,Gx,numEdges,x,*n,*t,mode,0.0,
true);}void tlu2_akima_nearest_prelookup_custom_function_(void*out,const void*
in){const real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(
const real_T*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T
*)((const void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*
)in)[3];real_T*H=(real_T*)((void**)out)[0];real_T*Hx=(real_T*)((void**)out)[1]
;real_T*G=(real_T*)((void**)out)[2];real_T*Gx=(real_T*)((void**)out)[3];size_t
*numEdges=(size_t*)((void**)out)[4];size_t*bin=(size_t*)((void**)out)[5];
tlu2_akima_nearest_prelookup(H,Hx,G,Gx,numEdges,bin,x,t,mode,n);}
