#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "pm_std.h"
#include "mc_std.h"
typedef enum{mc_KhnGFEmutK29G1pFMV7eY2= -1,mc_DKQ2NLbquneq0lUPeY6980,
mc_pZ2gSv1PwNXkkpsIRojds1,mc_s3f6TbPTFsg3OoFmSAmw9_,mc_UVVwEZg9VhYkMacmned87_,
mc_We99sVwuHRSx58iJnCFWJ1,mc_l850kaw5_IoBVNaRVt13c0,mc_PlLsh29Os6JPlaG9RqaLj1}
mc_v0sTqkEWafl9TPgVRJyQ40;typedef struct mc_WhDlDj1zmiQx043biolb81
mc_GlmRlYa6s_WkfFpBYMHnW_;struct McRealFunctionTag{mc_GlmRlYa6s_WkfFpBYMHnW_*
mc_2s9vB1TeGePozpYvhr_nm_;mc_v0sTqkEWafl9TPgVRJyQ40(*mc_AkTbmaeNiVf6F7eo9cqvi0
)(const void*mc_w2sbHOBWMTHvn1ViunNc91,const PmRealVector*
mc_ZFjwwXR9oOYOpGudG7a2f1,mc_GlmRlYa6s_WkfFpBYMHnW_*mc_6peHhhgu8wo0Kp3HDh_aI0)
;const void*(*mc_wlcTuDm2p66ascvFToGzq1)(const McRealFunction*
mc_Egr13MRE9IVP5BUwy4rIY1);void(*mc_YCFci8IAJkK9w_xpRtHta2)(McRealFunction*
mc_Egr13MRE9IVP5BUwy4rIY1);};typedef struct mc_Owe6_gHWIwVgeopMGSBKl0
mc_aVw842GhQvd__vlWfLkt11;struct McIntFunctionTag{mc_aVw842GhQvd__vlWfLkt11*
mc_2s9vB1TeGePozpYvhr_nm_;void(*mc_AkTbmaeNiVf6F7eo9cqvi0)(const void*
mc_w2sbHOBWMTHvn1ViunNc91,const PmIntVector*mc_ZFjwwXR9oOYOpGudG7a2f1,
mc_aVw842GhQvd__vlWfLkt11*mc_6peHhhgu8wo0Kp3HDh_aI0);const void*(*
mc_wlcTuDm2p66ascvFToGzq1)(const McIntFunction*mc_Egr13MRE9IVP5BUwy4rIY1);void
(*mc_YCFci8IAJkK9w_xpRtHta2)(McIntFunction*mc_Egr13MRE9IVP5BUwy4rIY1);};
typedef struct mc_yoIGOXVZU4sR6Ok75JMwh0 mc__mq5AHOLTsZs8aGf7Q6ee0;struct
McMatrixFunctionTag{mc__mq5AHOLTsZs8aGf7Q6ee0*mc_2s9vB1TeGePozpYvhr_nm_;const
PmSparsityPattern*mc__iixD59voIPp_QZe1Ziof_;void(*mc_AkTbmaeNiVf6F7eo9cqvi0)(
const void*mc_w2sbHOBWMTHvn1ViunNc91,const PmRealVector*
mc_ZFjwwXR9oOYOpGudG7a2f1,mc__mq5AHOLTsZs8aGf7Q6ee0*mc_6peHhhgu8wo0Kp3HDh_aI0)
;const void*(*mc_wlcTuDm2p66ascvFToGzq1)(const McMatrixFunction*
mc_Egr13MRE9IVP5BUwy4rIY1);void(*mc_YCFci8IAJkK9w_xpRtHta2)(McMatrixFunction*
mc_Egr13MRE9IVP5BUwy4rIY1);};typedef struct mc_eHE7stIyZoHCwzx6_E_ly_
mc_H0Bk7D_oz3N7oWgSjiReu_;typedef struct mc_329HrTFt7TQQT4Mt2CFdE_
mc_AO5JW8mLUBdiYweiHzH_0_;struct mc_329HrTFt7TQQT4Mt2CFdE_{
mc_H0Bk7D_oz3N7oWgSjiReu_*mc_0TyJOxmrCFOwXODumYaSw2;void(*
mc_S8IgzFZ5xYUDYvaq_F3eY1)(const mc_AO5JW8mLUBdiYweiHzH_0_*
mc__WbKiFtr3y_24_2xwlGxv0,const void*mc_w2sbHOBWMTHvn1ViunNc91);
McMatrixFunction*(*mc_TaiRgNRVp_xjrcnpUe8lA1)(const mc_AO5JW8mLUBdiYweiHzH_0_*
mc__WbKiFtr3y_24_2xwlGxv0);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
mc_AO5JW8mLUBdiYweiHzH_0_*mc__WbKiFtr3y_24_2xwlGxv0);};
mc_AO5JW8mLUBdiYweiHzH_0_*mc_cQv_ZCNfIS6i2SMCSWGyn1(McMatrixFunction*
mc_K__VwF1fOaiI5mgPPJMb62,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);void
pm_rv_equals_rv(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector
*pm__UmJPtGaW9C9junx1RpnH_);void pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_TnPSeUZeYw5Wc8bvD8sl80(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_fKS8kuV7G_WhlO7CcdVnc1(const
PmCharVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm___43lXp90F4bzSkAXqYfT1(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);int_T pm_create_real_vector_fields(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_create_real_vector(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(
const PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_destroy_real_vector(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_int_vector_fields(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmIntVector*pm_create_int_vector(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_pLia5sG_NxTeQbxzYtpXx_(const
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_Rdk2CZ3CCj5T0d2uDHUZ20(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_int_vector(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_
(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_SK8Vck8jU45BIyJDK11DV_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*
pm_Or6MViYTj4_1rM_3pn1UZ0(const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_cn_kUNHZ0hjihWokUKapj_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_nUREx2_I6_H8Z9q4fW3LX2(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);McMatrixFunction*mc_aMPI1g4IJzx_se88DNXxp_(const
PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,const PmRealVector*
mc_jJ78FsEfvlTthTdupUhHD2,const void*mc_5ntU4ids4xVuRQ0c6mPAf1,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2);McMatrixFunction*mc_ojEKe9_35QoXUYpthE8Iy2(
PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,PmRealVector*
mc_jJ78FsEfvlTthTdupUhHD2,const void*mc_5ntU4ids4xVuRQ0c6mPAf1,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2);struct mc_eHE7stIyZoHCwzx6_E_ly_{McMatrixFunction*
mc_yYkmrDjsELQdT00_wHiJ_2;PmAllocator*mc_EJyLFJLNS54LEp1_ia1250;PmRealVector*
mc_bSRXX7qJUaN0DIHWaaYhc2;};static void mc_H4fntDEhuJiFFiTmMzN7r0(const
mc_AO5JW8mLUBdiYweiHzH_0_*mc__WbKiFtr3y_24_2xwlGxv0,const void*
mc_w2sbHOBWMTHvn1ViunNc91){(*((mc__WbKiFtr3y_24_2xwlGxv0->
mc_0TyJOxmrCFOwXODumYaSw2->mc_yYkmrDjsELQdT00_wHiJ_2)->
mc_AkTbmaeNiVf6F7eo9cqvi0))((mc_w2sbHOBWMTHvn1ViunNc91),(
mc__WbKiFtr3y_24_2xwlGxv0->mc_0TyJOxmrCFOwXODumYaSw2->
mc_bSRXX7qJUaN0DIHWaaYhc2),((mc__WbKiFtr3y_24_2xwlGxv0->
mc_0TyJOxmrCFOwXODumYaSw2->mc_yYkmrDjsELQdT00_wHiJ_2)->
mc_2s9vB1TeGePozpYvhr_nm_));}static McMatrixFunction*mc_5goa3fTbCxBiqyTiqDcsE1
(const mc_AO5JW8mLUBdiYweiHzH_0_*mc__WbKiFtr3y_24_2xwlGxv0){
mc_H0Bk7D_oz3N7oWgSjiReu_*mc_6peHhhgu8wo0Kp3HDh_aI0=mc__WbKiFtr3y_24_2xwlGxv0
->mc_0TyJOxmrCFOwXODumYaSw2;McMatrixFunction*src=mc_6peHhhgu8wo0Kp3HDh_aI0->
mc_yYkmrDjsELQdT00_wHiJ_2;return mc_aMPI1g4IJzx_se88DNXxp_(src->
mc__iixD59voIPp_QZe1Ziof_,mc_6peHhhgu8wo0Kp3HDh_aI0->mc_bSRXX7qJUaN0DIHWaaYhc2
,(src)->mc_wlcTuDm2p66ascvFToGzq1((src)),mc_6peHhhgu8wo0Kp3HDh_aI0->
mc_EJyLFJLNS54LEp1_ia1250);}static void mc_4iUJN4wTlHPgtG_vkUF052(
mc_AO5JW8mLUBdiYweiHzH_0_*mc__WbKiFtr3y_24_2xwlGxv0){mc_H0Bk7D_oz3N7oWgSjiReu_
*mc_6peHhhgu8wo0Kp3HDh_aI0=mc__WbKiFtr3y_24_2xwlGxv0->
mc_0TyJOxmrCFOwXODumYaSw2;PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2=
mc_6peHhhgu8wo0Kp3HDh_aI0->mc_EJyLFJLNS54LEp1_ia1250;(
mc_6peHhhgu8wo0Kp3HDh_aI0->mc_yYkmrDjsELQdT00_wHiJ_2)->
mc_YCFci8IAJkK9w_xpRtHta2(mc_6peHhhgu8wo0Kp3HDh_aI0->mc_yYkmrDjsELQdT00_wHiJ_2
);pm_destroy_real_vector(mc_6peHhhgu8wo0Kp3HDh_aI0->mc_bSRXX7qJUaN0DIHWaaYhc2,
pm_an0wiQTjdlKE72zC6FJ0a2);{void*mc_GAbHnJspJ6sMhe_Yzxehb_=(
mc_6peHhhgu8wo0Kp3HDh_aI0);if(mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
mc_GAbHnJspJ6sMhe_Yzxehb_);}};{void*mc_GAbHnJspJ6sMhe_Yzxehb_=(
mc__WbKiFtr3y_24_2xwlGxv0);if(mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
mc_GAbHnJspJ6sMhe_Yzxehb_);}};}mc_AO5JW8mLUBdiYweiHzH_0_*
mc_cQv_ZCNfIS6i2SMCSWGyn1(McMatrixFunction*mc__WbKiFtr3y_24_2xwlGxv0,
PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2){mc_AO5JW8mLUBdiYweiHzH_0_*
mc_Egr13MRE9IVP5BUwy4rIY1=(mc_AO5JW8mLUBdiYweiHzH_0_*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
mc_AO5JW8mLUBdiYweiHzH_0_)),(1)));mc_H0Bk7D_oz3N7oWgSjiReu_*
mc_6peHhhgu8wo0Kp3HDh_aI0=(mc_H0Bk7D_oz3N7oWgSjiReu_*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
mc_H0Bk7D_oz3N7oWgSjiReu_)),(1)));mc_6peHhhgu8wo0Kp3HDh_aI0->
mc_yYkmrDjsELQdT00_wHiJ_2=mc__WbKiFtr3y_24_2xwlGxv0;mc_6peHhhgu8wo0Kp3HDh_aI0
->mc_EJyLFJLNS54LEp1_ia1250=pm_an0wiQTjdlKE72zC6FJ0a2;
mc_6peHhhgu8wo0Kp3HDh_aI0->mc_bSRXX7qJUaN0DIHWaaYhc2=pm_create_real_vector(((
size_t)(mc__WbKiFtr3y_24_2xwlGxv0->mc__iixD59voIPp_QZe1Ziof_)->mJc[(
mc__WbKiFtr3y_24_2xwlGxv0->mc__iixD59voIPp_QZe1Ziof_)->mNumCol]),
pm_an0wiQTjdlKE72zC6FJ0a2);(*((mc__WbKiFtr3y_24_2xwlGxv0)->
mc_AkTbmaeNiVf6F7eo9cqvi0))(((mc__WbKiFtr3y_24_2xwlGxv0)->
mc_wlcTuDm2p66ascvFToGzq1((mc__WbKiFtr3y_24_2xwlGxv0))),(
mc_6peHhhgu8wo0Kp3HDh_aI0->mc_bSRXX7qJUaN0DIHWaaYhc2),((
mc__WbKiFtr3y_24_2xwlGxv0)->mc_2s9vB1TeGePozpYvhr_nm_));
mc_Egr13MRE9IVP5BUwy4rIY1->mc_0TyJOxmrCFOwXODumYaSw2=mc_6peHhhgu8wo0Kp3HDh_aI0
;mc_Egr13MRE9IVP5BUwy4rIY1->mc_S8IgzFZ5xYUDYvaq_F3eY1= &
mc_H4fntDEhuJiFFiTmMzN7r0;mc_Egr13MRE9IVP5BUwy4rIY1->mc_TaiRgNRVp_xjrcnpUe8lA1
= &mc_5goa3fTbCxBiqyTiqDcsE1;mc_Egr13MRE9IVP5BUwy4rIY1->
mc_YCFci8IAJkK9w_xpRtHta2= &mc_4iUJN4wTlHPgtG_vkUF052;return
mc_Egr13MRE9IVP5BUwy4rIY1;}
