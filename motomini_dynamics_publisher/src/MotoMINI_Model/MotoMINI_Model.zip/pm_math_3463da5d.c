#include "pm_std.h"
#include "stddef.h"
#include "pm_std.h"
extern real_T pm_math_v3oy6jtkvT9ihFrvNTMGD1;extern real_T
pm_math_8oCi7phP7xoqxLeutXzpb1;extern real_T pm_math_tq2jfAWxy_Dyza9BpMyit2;
extern real32_T pm_math_iLhf9wMwW1Pq_EMd2OqGf1;extern real32_T
pm_math_rNwvXkjb99E4ZpYAnsmT4_;extern real32_T pm_math_Ano4XctA_SYU9zS8fziQ60;
extern void pm_math_oPOG_P5RhcoYvwpARu89z1(size_t
pm_math_LdLrc7UAQbUijcSfFMVqs2);extern boolean_T pm_math_V6T8b7FmoDVCm1FHylDnu1
(real_T pm_math_RGllRMvIRPGkpbvuetJlO2);extern boolean_T
pm_math_JQg0NRHCeLj6DXmPZ5R_N2(real32_T pm_math_RGllRMvIRPGkpbvuetJlO2);extern
boolean_T pm_math_Y_zcWC2yaJfvV5XSRZZ4__(real_T pm_math_RGllRMvIRPGkpbvuetJlO2
);extern boolean_T pm_math_xYSIY4s3oiNM3T3j4YjAO1(real32_T
pm_math_RGllRMvIRPGkpbvuetJlO2);typedef struct{struct{uint32_T
pm_math_hEC82VvI3ClwWovyMiZht_;uint32_T pm_math_178r7HengVaiUoAxwBRry_;}
pm_math_M3l9YQ9o_j6oAzdXU4IrF0;}pm_math_bKm7nf86TKrq4ilf8tIMA1;typedef struct{
struct{uint32_T pm_math_178r7HengVaiUoAxwBRry_;uint32_T
pm_math_hEC82VvI3ClwWovyMiZht_;}pm_math_M3l9YQ9o_j6oAzdXU4IrF0;}
pm_math_yhQtL_s6VM33rO12a6O1N_;typedef struct{union{real32_T
pm_math_SzN8hhhrB16XdmJRGX_y31;uint32_T pm_math_XXD_GT7ttX6ghG7WKgVWr2;}
pm_math_178r7HengVaiUoAxwBRry_;}pm_math_dO8A5_FCJfRec6pkUmMx01;extern real_T
pm_math_3P07HKytYTQSOa8oqtubN_(void);extern real32_T
pm_math_E8wb39eCUP_mfip73y1yd1(void);extern real_T
pm_math_asI3ly8FWWr5L_SHma956_(void);extern real32_T
pm_math_CKAxpMjvJZkFlZ1OPNVIZ0(void);extern real_T
pm_math_TdYJoiPwRwhfv3ZmTSv922(void);extern real32_T
pm_math_bByD1WZxx4j53kCqQRVIN1(void);real_T pm_math_v3oy6jtkvT9ihFrvNTMGD1;
real_T pm_math_8oCi7phP7xoqxLeutXzpb1;real_T pm_math_tq2jfAWxy_Dyza9BpMyit2;
real32_T pm_math_iLhf9wMwW1Pq_EMd2OqGf1;real32_T pm_math_rNwvXkjb99E4ZpYAnsmT4_
;real32_T pm_math_Ano4XctA_SYU9zS8fziQ60;void pm_math_oPOG_P5RhcoYvwpARu89z1(
size_t pm_math_LdLrc7UAQbUijcSfFMVqs2){(void)(pm_math_LdLrc7UAQbUijcSfFMVqs2);
pm_math_tq2jfAWxy_Dyza9BpMyit2=pm_math_3P07HKytYTQSOa8oqtubN_();
pm_math_Ano4XctA_SYU9zS8fziQ60=pm_math_E8wb39eCUP_mfip73y1yd1();
pm_math_v3oy6jtkvT9ihFrvNTMGD1=pm_math_asI3ly8FWWr5L_SHma956_();
pm_math_iLhf9wMwW1Pq_EMd2OqGf1=pm_math_CKAxpMjvJZkFlZ1OPNVIZ0();
pm_math_8oCi7phP7xoqxLeutXzpb1=pm_math_TdYJoiPwRwhfv3ZmTSv922();
pm_math_rNwvXkjb99E4ZpYAnsmT4_=pm_math_bByD1WZxx4j53kCqQRVIN1();}boolean_T
pm_math_V6T8b7FmoDVCm1FHylDnu1(real_T pm_math_RGllRMvIRPGkpbvuetJlO2){return((
pm_math_RGllRMvIRPGkpbvuetJlO2==pm_math_v3oy6jtkvT9ihFrvNTMGD1||
pm_math_RGllRMvIRPGkpbvuetJlO2==pm_math_8oCi7phP7xoqxLeutXzpb1)?1U:0U);}
boolean_T pm_math_JQg0NRHCeLj6DXmPZ5R_N2(real32_T
pm_math_RGllRMvIRPGkpbvuetJlO2){return(((pm_math_RGllRMvIRPGkpbvuetJlO2)==
pm_math_iLhf9wMwW1Pq_EMd2OqGf1||(pm_math_RGllRMvIRPGkpbvuetJlO2)==
pm_math_rNwvXkjb99E4ZpYAnsmT4_)?1U:0U);}boolean_T
pm_math_Y_zcWC2yaJfvV5XSRZZ4__(real_T pm_math_RGllRMvIRPGkpbvuetJlO2){return(
pm_math_RGllRMvIRPGkpbvuetJlO2!=pm_math_RGllRMvIRPGkpbvuetJlO2)?1U:0U;}
boolean_T pm_math_xYSIY4s3oiNM3T3j4YjAO1(real32_T
pm_math_RGllRMvIRPGkpbvuetJlO2){return(pm_math_RGllRMvIRPGkpbvuetJlO2!=
pm_math_RGllRMvIRPGkpbvuetJlO2)?1U:0U;}
