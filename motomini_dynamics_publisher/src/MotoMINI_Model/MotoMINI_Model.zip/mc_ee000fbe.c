#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
struct mc_TveuOuuz_7rSXp2jMuHzn2{struct{char const*mc_cU06ncCice2RCrcvrncKT1;}
mc_UuCh2_Js6ioFSOqws_9lJ_;struct{char const*mc_lFl_lGln7jtwbTjKMmnDC0;}
mc_zmYkg_zQb7L_kRd1QvEwN1;};extern struct mc_TveuOuuz_7rSXp2jMuHzn2
mc_5YpKWqv65FwV7t0cG26tq2;struct mc_TveuOuuz_7rSXp2jMuHzn2
mc_5YpKWqv65FwV7t0cG26tq2={{"Failure in depcols (out of memory).",},{
"Sparse matrix inverse failed.",},};
