#include "pm_std.h"
real_T pm_math__uBIz_L3oXPDeDY_8Osa00(const real_T*
pm_math_ljExW6hRw43Vg4SLQUAvT1,uint32_T n);real_T
pm_math_glUjFuEbnyTmECK_mCxdu1(const real_T*pm_math__lerGssn0Ru_r3kSOzEmI_,
uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,uint32_T n);real_T
pm_math_piIX7YLiok3TLwEaXGohj_(const real_T*pm_math__lerGssn0Ru_r3kSOzEmI_,
uint32_T n);
#include "math.h"
real_T pm_math__uBIz_L3oXPDeDY_8Osa00(const real_T*
pm_math_ljExW6hRw43Vg4SLQUAvT1,uint32_T n){real_T
pm_math_AnS7Y4euB5dEkvfZmgB7x_=0.0;const real_T*pm_math_jcOSsrULtHDGKqSRz3gAT0
=pm_math_ljExW6hRw43Vg4SLQUAvT1+n;while(pm_math_ljExW6hRw43Vg4SLQUAvT1<
pm_math_jcOSsrULtHDGKqSRz3gAT0)pm_math_AnS7Y4euB5dEkvfZmgB7x_+=fabs(*
pm_math_ljExW6hRw43Vg4SLQUAvT1++);return pm_math_AnS7Y4euB5dEkvfZmgB7x_;}
real_T pm_math_glUjFuEbnyTmECK_mCxdu1(const real_T*
pm_math__lerGssn0Ru_r3kSOzEmI_,uint32_T pm_math_gN74BbsU5wqNjkJbC9b672,
uint32_T n){real_T pm_math_560Sm93DVNGot7jw0_VFH2=0.0;real_T
pm_math_45ZKtJySfktzmr6lD7TyX0;uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,
pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;pm_math_OUB2pptsvtdGL_LyqpgOa0++){
pm_math_45ZKtJySfktzmr6lD7TyX0=0.0;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<pm_math_gN74BbsU5wqNjkJbC9b672;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)pm_math_45ZKtJySfktzmr6lD7TyX0+=fabs(*
pm_math__lerGssn0Ru_r3kSOzEmI_++);if(pm_math_45ZKtJySfktzmr6lD7TyX0>
pm_math_560Sm93DVNGot7jw0_VFH2)pm_math_560Sm93DVNGot7jw0_VFH2=
pm_math_45ZKtJySfktzmr6lD7TyX0;}return pm_math_560Sm93DVNGot7jw0_VFH2;}real_T
pm_math_piIX7YLiok3TLwEaXGohj_(const real_T*pm_math__lerGssn0Ru_r3kSOzEmI_,
uint32_T n){real_T pm_math_560Sm93DVNGot7jw0_VFH2=0.0;real_T
pm_math_45ZKtJySfktzmr6lD7TyX0;uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,
pm_math_OUB2pptsvtdGL_LyqpgOa0;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<n;pm_math_OUB2pptsvtdGL_LyqpgOa0++,
pm_math__lerGssn0Ru_r3kSOzEmI_+=n-pm_math_OUB2pptsvtdGL_LyqpgOa0){
pm_math_45ZKtJySfktzmr6lD7TyX0=0.0;for(pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_math_SmSSPSQfR1qEYWsVj5ELF0<=pm_math_OUB2pptsvtdGL_LyqpgOa0;++
pm_math_SmSSPSQfR1qEYWsVj5ELF0)pm_math_45ZKtJySfktzmr6lD7TyX0+=fabs(*
pm_math__lerGssn0Ru_r3kSOzEmI_++);if(pm_math_45ZKtJySfktzmr6lD7TyX0>
pm_math_560Sm93DVNGot7jw0_VFH2)pm_math_560Sm93DVNGot7jw0_VFH2=
pm_math_45ZKtJySfktzmr6lD7TyX0;}return pm_math_560Sm93DVNGot7jw0_VFH2;}
