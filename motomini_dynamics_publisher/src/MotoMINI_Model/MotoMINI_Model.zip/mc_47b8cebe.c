#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_linear_algebra(void);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);void pm_rv_equals_rv(const PmRealVector
*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_TnPSeUZeYw5Wc8bvD8sl80(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);void pm_fKS8kuV7G_WhlO7CcdVnc1(const PmCharVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm___43lXp90F4bzSkAXqYfT1(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);int_T
pm_create_real_vector_fields(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_create_real_vector(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(const PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_real_vector(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_int_vector_fields(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_create_int_vector(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*
pm_pLia5sG_NxTeQbxzYtpXx_(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_Rdk2CZ3CCj5T0d2uDHUZ20(
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_destroy_int_vector(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_SK8Vck8jU45BIyJDK11DV_(
PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_Or6MViYTj4_1rM_3pn1UZ0(
const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_cn_kUNHZ0hjihWokUKapj_(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_nUREx2_I6_H8Z9q4fW3LX2(
PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);
#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "limits.h"
#include "math.h"
#include "stdio.h"
typedef struct mc_kI_HkaTCnLZ_RlyY_sUHN2{int32_T mc_ljdetJMOCfBq2uHQ_Xw_v0;
int32_T mc_gN74BbsU5wqNjkJbC9b672;int32_T n;int32_T*pm_KYlcoOk9rSSGYswizhYqZ2;
int32_T*mc_SmSSPSQfR1qEYWsVj5ELF0;double*x;int32_T mc_OHoqm6pCNFp_0jat5JWFV2;}
mc_6Y_awzn17rlf_oaSmGr222;mc_6Y_awzn17rlf_oaSmGr222*mc_GO6x_Rqz9PsT5rw6AHrHt_(
const mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const
mc_6Y_awzn17rlf_oaSmGr222*mc_8ksqc0VFHLjSHzNxXK8mN0,double
mc_8IKoYx3qsjeiwHerWlCOS1,double mc_ORaLij6SptbAKkelBLoEL0);int32_T
mc_mbG7Q2rYQZdk0UJ0hW6Sg2(int32_T mc_NNBxjpq2ck5isunOL_3RU_,const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,double*b);
mc_6Y_awzn17rlf_oaSmGr222*mc_gDNQYj48Ex31AsLE0yqXO2(const
mc_6Y_awzn17rlf_oaSmGr222*mc_1rg5Osg1YqZjr7xO6cmlv0);int32_T
mc_2SMqPK8sz8_ilSwUZ7OSM0(mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_)
;int32_T mc_nqBKtO4P9RbuPYKRGwHjn_(mc_6Y_awzn17rlf_oaSmGr222*
mc_1rg5Osg1YqZjr7xO6cmlv0,int32_T mc_SmSSPSQfR1qEYWsVj5ELF0,int32_T
mc_OUB2pptsvtdGL_LyqpgOa0,double x);int32_T mc_0nEzV6fYbBq4OZlfjQgI7_(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const double*x,double*
mc_ET9_5EAP116KvP5KVqsrD2);mc_6Y_awzn17rlf_oaSmGr222*mc_vPTl2PxEe1ahNQtXPLyI8_
(FILE*mc_VxxeDNxb3XYZvQXh_7Mga_);int32_T mc_aFrJpGdjQIjtoakjvA1ep_(int32_T
mc_NNBxjpq2ck5isunOL_3RU_,const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_,double*b,double mc_yS7VvSIKrGg9ddzBqHtUd_);
mc_6Y_awzn17rlf_oaSmGr222*mc_MnSbKBBbLve56h73H6jVJ_(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const
mc_6Y_awzn17rlf_oaSmGr222*mc_8ksqc0VFHLjSHzNxXK8mN0);double
mc_7E9BNNdaYaPN_WCf_pgeU1(const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_);int32_T mc_IW_lcaWqLycBXAOlL6vsD_(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T
mc_EiJxqWlBLG9pKnSBGFWfr_);int32_T mc_dtEJ6vpwYkwQl0nYIwh8c2(int32_T
mc_NNBxjpq2ck5isunOL_3RU_,const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_,double*b);mc_6Y_awzn17rlf_oaSmGr222*
mc_798bn9wMrS5vtrBIqDwMf0(const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_,int32_T mc_jJ78FsEfvlTthTdupUhHD2);void*
mc_y1rJRp21YhZDKCX1eSUsS1(int32_T n,size_t size);void*
mc_LxZ4GcxGp0D4_SX8kV0GM_(void*pm_KYlcoOk9rSSGYswizhYqZ2);void*
mc_Fzj5zJ9NnkLsRO10o4n_t1(void*pm_KYlcoOk9rSSGYswizhYqZ2,int32_T n,size_t size
,int32_T*mc_YBSj3VRtODEIq_zyObpWg2);mc_6Y_awzn17rlf_oaSmGr222*
mc_8lzqkdoXfarQqLfjfrEKU_(int32_T mc_gN74BbsU5wqNjkJbC9b672,int32_T n,int32_T
mc_ljdetJMOCfBq2uHQ_Xw_v0,int32_T mc_jJ78FsEfvlTthTdupUhHD2,int32_T
mc_6lT7vLkAkpT4Qw1FQPZ3t2);mc_6Y_awzn17rlf_oaSmGr222*mc_vVHvSM_NFYPGyKpyBY_yU2
(mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_);int32_T
mc_g0skBeSxVf5qP1OPh14mS0(mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,
int32_T mc_ljdetJMOCfBq2uHQ_Xw_v0);void*mc_4NUC47j4aJxHBwMhDbTZV0(int32_T n,
size_t size);int mc_g_ild7gcANactWOrqGH2P0(const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_,int mc_EiJxqWlBLG9pKnSBGFWfr_);typedef struct
mc_ez4WvZ_IHGDiy3wd9JaRZ0{int32_T*mc_EddJPU9FSjGK3NHuQHVJK0;int32_T*
mc_RAQgyWVtpyqfEVcLRZFTL_;int32_T*mc_axmmFeQpDUnM8MIeDIqfv_;int32_T*
mc_VnUvVwAuE0jKVRHKn79nS_;int32_T*mc_XyQME2R_ctE9raSmFt2pL2;int32_T
mc_Sg9yUwfvylTonwXg2fUxR0;double mc_U0BcB0OQFOxVcj5PYKAMl_;double
mc_vBa0LldwlL4zu9cQzD6cC_;}mc_RDP9AIl_Yt_Wbz0AGFR090;typedef struct
mc_k1pQfB51pJXs5QtduA6G_2{mc_6Y_awzn17rlf_oaSmGr222*mc_Ko2UL7FliD3gp_gb0mLQz1;
mc_6Y_awzn17rlf_oaSmGr222*mc_ks8rkpJYX5jHaEJjD6Z6h1;int32_T*
mc_EddJPU9FSjGK3NHuQHVJK0;double*mc_8ksqc0VFHLjSHzNxXK8mN0;}
mc_P_4WcNoisEncHhxd9iYmA1;typedef struct mc_iNnryziBRS8kLQPmfldpG_{int32_T*
pm_KYlcoOk9rSSGYswizhYqZ2;int32_T*mc_RAQgyWVtpyqfEVcLRZFTL_;int32_T*
mc_2KXuAphrqc_TLcinUGD4E1;int32_T*mc_hCXUd_x6pbKZfXtyKXEw82;int32_T
mc_j_SD_sgtshphDEvI4jhBO_;int32_T mc_3EfMcZ9uFJxwmp9cI3khy0[5];int32_T
mc_3Yj99b9_vk4hnksUig7pf1[5];}mc_I3kQY5G4_MITLTO0uPI8L1;int32_T*
mc_PEkGs_0ndRJaos_yJJtFu0(int32_T mc_NNBxjpq2ck5isunOL_3RU_,const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_);mc_P_4WcNoisEncHhxd9iYmA1
*mc_3Equrjz9_V5ET25trreNk0(const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_,const mc_RDP9AIl_Yt_Wbz0AGFR090*
mc_cO3HQ5aG_1XgD1aeQvO8f2);mc_I3kQY5G4_MITLTO0uPI8L1*mc_p9yR0_wJdHAg8SHg_58_S2
(const mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T
mc_V1223Gsg2_1bKbHdwp5PT2);int32_T mc_zG0rXXanZz0ZCp9J211F90(
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,double
mc_yS7VvSIKrGg9ddzBqHtUd_);int32_T mc_5BWDcOGPyi8iNLVx_RJUz0(
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_);int32_T
mc_d4Ubl9ylK1jaB31pG1ze82(const mc_6Y_awzn17rlf_oaSmGr222*
mc_UlTac2Z5H9S91rOURuT4m0,int32_T mc_SmSSPSQfR1qEYWsVj5ELF0,double
mc_ORaLij6SptbAKkelBLoEL0,double*x);int32_T mc_velqwEVC8fLQCaCDqKcxE1(const
int32_T*pm_KYlcoOk9rSSGYswizhYqZ2,const double*b,double*x,int32_T n);int32_T
mc_myrncps3Bp4niT9SMNSFU0(const mc_6Y_awzn17rlf_oaSmGr222*
mc_Ko2UL7FliD3gp_gb0mLQz1,double*x);int32_T mc_yxDz_mr3wO_wVzPmX8s_x2(const
mc_6Y_awzn17rlf_oaSmGr222*mc_Ko2UL7FliD3gp_gb0mLQz1,double*x);
mc_P_4WcNoisEncHhxd9iYmA1*mc_Nf5R0F6K47SZgpezuH2h50(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const
mc_RDP9AIl_Yt_Wbz0AGFR090*mc_cO3HQ5aG_1XgD1aeQvO8f2,double
mc_yS7VvSIKrGg9ddzBqHtUd_);mc_P_4WcNoisEncHhxd9iYmA1*mc_KeWpRWVqC8tjvlCRsE1DV1
(const mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const
mc_RDP9AIl_Yt_Wbz0AGFR090*mc_cO3HQ5aG_1XgD1aeQvO8f2,int32_T*
mc_J7wvUCOubReyruqv_pmIZ1);mc_6Y_awzn17rlf_oaSmGr222*mc_aXUfSyY8L22Gta0NH_3eO0
(const mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const int32_T*
pm_KYlcoOk9rSSGYswizhYqZ2,const int32_T*mc_RAQgyWVtpyqfEVcLRZFTL_,int32_T
mc_jJ78FsEfvlTthTdupUhHD2);int32_T*mc_Nf9FHKfoE2t00TmW1V1bv0(const int32_T*
pm_KYlcoOk9rSSGYswizhYqZ2,int32_T n);int32_T mc_WYgZa5_B_CFIafI_v9bt6_(const
int32_T*pm_KYlcoOk9rSSGYswizhYqZ2,const double*b,double*x,int32_T n);
mc_P_4WcNoisEncHhxd9iYmA1*mc_ZodW09u4_96V4KKCW1Qck_(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const
mc_RDP9AIl_Yt_Wbz0AGFR090*mc_cO3HQ5aG_1XgD1aeQvO8f2);mc_RDP9AIl_Yt_Wbz0AGFR090
*mc_l_STaD2VMuZHf8GGy5uvL1(int32_T mc_NNBxjpq2ck5isunOL_3RU_,const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_);mc_RDP9AIl_Yt_Wbz0AGFR090
*mc_UIJXHcO0bfWk_WsGNAlpf0(int32_T mc_NNBxjpq2ck5isunOL_3RU_,const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T
mc_2kRUucGwF8yJYVACAVBqN2);mc_6Y_awzn17rlf_oaSmGr222*mc_dcMiUxcG0j_L_6sSDI_oU2
(const mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const int32_T*
mc_EddJPU9FSjGK3NHuQHVJK0,int32_T mc_jJ78FsEfvlTthTdupUhHD2);int32_T
mc_1LDuOADHuYmJpGQpuvQpk2(mc_6Y_awzn17rlf_oaSmGr222*mc_Ko2UL7FliD3gp_gb0mLQz1,
int32_T mc_XInbm4EkzZr2yor6lhu2T2,const mc_6Y_awzn17rlf_oaSmGr222*
mc_CH6pya__frGySt3NjsQiR2,const int32_T*mc_axmmFeQpDUnM8MIeDIqfv_);int32_T
mc_7TIwraGWa7_N5cUNFCHh5_(const mc_6Y_awzn17rlf_oaSmGr222*
mc_ks8rkpJYX5jHaEJjD6Z6h1,double*x);int32_T mc_k6VzcXQ_pXvFB4tJyZp1T_(const
mc_6Y_awzn17rlf_oaSmGr222*mc_ks8rkpJYX5jHaEJjD6Z6h1,double*x);
mc_RDP9AIl_Yt_Wbz0AGFR090*mc_tw08gA1Pc97CibZ9SYzgn1(mc_RDP9AIl_Yt_Wbz0AGFR090*
mc_cO3HQ5aG_1XgD1aeQvO8f2);mc_P_4WcNoisEncHhxd9iYmA1*mc_ibXoOPiOM7SU6MRFBjZnr2
(mc_P_4WcNoisEncHhxd9iYmA1*mc_fRcLIL8_e1U5rpzJCf0eA2);
mc_I3kQY5G4_MITLTO0uPI8L1*mc_ASIqSNhgYIFDl8A_OZ3Nj_(mc_I3kQY5G4_MITLTO0uPI8L1*
mc_BOXZTEAmCrs_EsW1Z7QvC0);int32_T*mc_7nG9lUdK3T_me5heU563C0(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,const int32_T*
mc_axmmFeQpDUnM8MIeDIqfv_,const int32_T*mc_MCx7NWDohl5CBE2LnPeJF2,int32_T
mc_AqDxKN9pU4KpStbVVI5hY_);double mc_IlEmqSHDAWyAGgiaxQzF72(int32_T*
pm_KYlcoOk9rSSGYswizhYqZ2,int32_T*mc_ojAHyVHgbHhAjmJFnG_l31,int32_T n);int32_T
mc_2VhAsaQm8j1BqRig7Y94l1(int32_T mc_OUB2pptsvtdGL_LyqpgOa0,
mc_6Y_awzn17rlf_oaSmGr222*mc_5LnJCGYiDv_7y1GYvBMv60,int32_T
mc_XU3rlF2PH5_zulJtZhFUc2,int32_T*mc__ujxrncktQZilZzTUuVF32,int32_T*
mc_tuniCIru1RfaJEd0teDon_,const int32_T*mc_EddJPU9FSjGK3NHuQHVJK0);int32_T
mc_Jj9VH0eMA5XP9U_ziAyG81(const mc_6Y_awzn17rlf_oaSmGr222*
mc__lerGssn0Ru_r3kSOzEmI_,int32_T mc_PIqWtbzrbQqv_KS_31HnE2,const int32_T*
mc_axmmFeQpDUnM8MIeDIqfv_,int32_T*mc_hCXUd_x6pbKZfXtyKXEw82,int32_T*
mc_NnCmJnsXc51VOXM7s0_HH0);int32_T*mc_ukUJI5gik_YiLRv4PQY4_2(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T
mc_AqDxKN9pU4KpStbVVI5hY_);int32_T mc_oO4saFSDxaOgIQQDolzdI2(
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T(*
mc_qGO3TkzJ_kUdk2iKehT3o0)(int32_T,int32_T,double,void*),void*
pm_B0LNpsKPbGgqFDFZWKsdG_);double mc_U8bmJm4UTtHMfbaQ5q6PH_(double*x,double*
mc_ORaLij6SptbAKkelBLoEL0,int32_T n);int32_T mc_6wzDapiXh25sZAQnDu37x_(int32_T
mc_SmSSPSQfR1qEYWsVj5ELF0,int32_T mc_OUB2pptsvtdGL_LyqpgOa0,const int32_T*
mc_h1vZqT9IJUzLd__Jm11v10,int32_T*mc_Qrxe_SjFJfkov4iGWDIyE2,int32_T*
mc_Si_vGZgXrCkhGJaIgpGoS1,int32_T*mc_52rlbFzjp6bwtZeLKb5CQ0,int32_T*
mc_kfoMnfnQeTFpUd4Mmj8Xh_);int32_T*mc_vmpaGT7kkAc2RZ6S8TNEt_(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T
mc_V1223Gsg2_1bKbHdwp5PT2);int32_T*mc_44AOPmPSJ1MEAK8AmzgpZ2(const int32_T*
mc_axmmFeQpDUnM8MIeDIqfv_,int32_T n);int32_T*mc_yb_CQrFC01qLXxF_6xmXJ_(int32_T
n,int32_T mc_V1223Gsg2_1bKbHdwp5PT2);int32_T mc_5CcrZ2CLOZnOOkryH5CHr0(
mc_6Y_awzn17rlf_oaSmGr222*mc_5LnJCGYiDv_7y1GYvBMv60,const
mc_6Y_awzn17rlf_oaSmGr222*mc_8ksqc0VFHLjSHzNxXK8mN0,int32_T
mc_PIqWtbzrbQqv_KS_31HnE2,int32_T*mc__ujxrncktQZilZzTUuVF32,const int32_T*
mc_EddJPU9FSjGK3NHuQHVJK0);int32_T mc_K6uvj2uJ5v60jMJkGDezJ1(const
mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_,int32_T
mc_OUB2pptsvtdGL_LyqpgOa0,double mc_ORaLij6SptbAKkelBLoEL0,int32_T*
mc_NnCmJnsXc51VOXM7s0_HH0,double*x,int32_T mc_LiBp76O114vl0YPUSUJP00,
mc_6Y_awzn17rlf_oaSmGr222*mc_CH6pya__frGySt3NjsQiR2,int32_T
mc_OHoqm6pCNFp_0jat5JWFV2);mc_I3kQY5G4_MITLTO0uPI8L1*mc_e5chq1FdjbLJXlwp9SsuW1
(mc_6Y_awzn17rlf_oaSmGr222*mc__lerGssn0Ru_r3kSOzEmI_);int32_T
mc_f2vwQIrcxUZfF8toz63Ia0(mc_6Y_awzn17rlf_oaSmGr222*mc_5LnJCGYiDv_7y1GYvBMv60,
const mc_6Y_awzn17rlf_oaSmGr222*mc_8ksqc0VFHLjSHzNxXK8mN0,int32_T
mc_PIqWtbzrbQqv_KS_31HnE2,int32_T*mc__ujxrncktQZilZzTUuVF32,double*x,const
int32_T*mc_EddJPU9FSjGK3NHuQHVJK0,int32_T mc_KHc8r6Sy_YS3xj9YUAdZ3_);int32_T
mc_fLYGXm9ZEhPX6ig3Hkb8n0(int32_T mc_OUB2pptsvtdGL_LyqpgOa0,int32_T
mc_PIqWtbzrbQqv_KS_31HnE2,int32_T*mc_cWzv_D9_DRQ5JggMwBCm91,const int32_T*
mc_JdbKP7eu7wdo_dMApA5OR1,int32_T*mc_MCx7NWDohl5CBE2LnPeJF2,int32_T*
mc_L5ucAGHzCB63TnhA2m9So2);mc_I3kQY5G4_MITLTO0uPI8L1*mc_TzEOuE_RsXz1qLP8uheSb0
(int32_T mc_gN74BbsU5wqNjkJbC9b672,int32_T n);mc_I3kQY5G4_MITLTO0uPI8L1*
mc_kFBpe3_gj77EZFb8qaqZK0(mc_I3kQY5G4_MITLTO0uPI8L1*mc_BOXZTEAmCrs_EsW1Z7QvC0,
mc_6Y_awzn17rlf_oaSmGr222*mc_CH6pya__frGySt3NjsQiR2,void*
mc_NnCmJnsXc51VOXM7s0_HH0,int32_T mc_YBSj3VRtODEIq_zyObpWg2);
mc_6Y_awzn17rlf_oaSmGr222*mc_JlRaY_nJltp8q1aLN7_Y62(mc_6Y_awzn17rlf_oaSmGr222*
mc_CH6pya__frGySt3NjsQiR2,void*mc_NnCmJnsXc51VOXM7s0_HH0,void*x,int32_T
mc_YBSj3VRtODEIq_zyObpWg2);int32_T*mc_G1TRn4rFaVBuNHVKT5lyb_(int32_T*
pm_KYlcoOk9rSSGYswizhYqZ2,mc_6Y_awzn17rlf_oaSmGr222*mc_CH6pya__frGySt3NjsQiR2,
void*mc_NnCmJnsXc51VOXM7s0_HH0,int32_T mc_YBSj3VRtODEIq_zyObpWg2);
mc_P_4WcNoisEncHhxd9iYmA1*mc_Blbk0IcpagUPtYc6xH_OV0(mc_P_4WcNoisEncHhxd9iYmA1*
mc_fRcLIL8_e1U5rpzJCf0eA2,mc_6Y_awzn17rlf_oaSmGr222*mc_CH6pya__frGySt3NjsQiR2,
void*mc_NnCmJnsXc51VOXM7s0_HH0,void*x,int32_T mc_YBSj3VRtODEIq_zyObpWg2);
#include "string.h"
struct McLinearAlgebraDataTag{mc_6Y_awzn17rlf_oaSmGr222*
mc_tC_lhrVr7sh_ia6yMUjV21;mc_RDP9AIl_Yt_Wbz0AGFR090*mc_yexQ7PGNxKybgqoevZ_Qn0;
mc_P_4WcNoisEncHhxd9iYmA1*mc_CidkhIpoznJNHlW_9nU022;PmRealVector*
mc_H5689kwuO84gcntlA8oHf0;};static McLinearAlgebraData*
mc_Jl_GarlRcCaE6gKc0GQAQ2(PmAllocator*mc_YMfc_eB3rHMVJUig1uu500,const
PmSparsityPattern*mc__lerGssn0Ru_r3kSOzEmI_){McLinearAlgebraData*
mc_v4k0LG4l9Qk9hEXlOIKML_=(McLinearAlgebraData*)((mc_YMfc_eB3rHMVJUig1uu500)->
mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(McLinearAlgebraData)),(1)));
mc_v4k0LG4l9Qk9hEXlOIKML_->mc_tC_lhrVr7sh_ia6yMUjV21=mc_8lzqkdoXfarQqLfjfrEKU_
(((int32_T)(mc__lerGssn0Ru_r3kSOzEmI_->mNumCol)),((int32_T)(
mc__lerGssn0Ru_r3kSOzEmI_->mNumRow)),((int32_T)(((size_t)(
mc__lerGssn0Ru_r3kSOzEmI_)->mJc[(mc__lerGssn0Ru_r3kSOzEmI_)->mNumCol]))),0,0);
;mc_v4k0LG4l9Qk9hEXlOIKML_->mc_H5689kwuO84gcntlA8oHf0=pm_create_real_vector(
mc__lerGssn0Ru_r3kSOzEmI_->mNumRow,mc_YMfc_eB3rHMVJUig1uu500);memcpy(
mc_v4k0LG4l9Qk9hEXlOIKML_->mc_tC_lhrVr7sh_ia6yMUjV21->
pm_KYlcoOk9rSSGYswizhYqZ2,mc__lerGssn0Ru_r3kSOzEmI_->mJc,(
mc__lerGssn0Ru_r3kSOzEmI_->mNumCol+1)*sizeof(int32_T));memcpy(
mc_v4k0LG4l9Qk9hEXlOIKML_->mc_tC_lhrVr7sh_ia6yMUjV21->
mc_SmSSPSQfR1qEYWsVj5ELF0,mc__lerGssn0Ru_r3kSOzEmI_->mIr,((size_t)(
mc__lerGssn0Ru_r3kSOzEmI_)->mJc[(mc__lerGssn0Ru_r3kSOzEmI_)->mNumCol])*sizeof(
int32_T));mc_v4k0LG4l9Qk9hEXlOIKML_->mc_yexQ7PGNxKybgqoevZ_Qn0=NULL;
mc_v4k0LG4l9Qk9hEXlOIKML_->mc_CidkhIpoznJNHlW_9nU022=NULL;return
mc_v4k0LG4l9Qk9hEXlOIKML_;}static McLinearAlgebraStatus
mc_YaF5Fp1Plk4pNI6fTGlvy2(McLinearAlgebra*mc_hWAHcsuAg4VvIe1q1qkLx0){
McLinearAlgebraData*mc_7wCuuwh6QrrYMzdJC_T2d2=mc_hWAHcsuAg4VvIe1q1qkLx0->
mPrivateData;if(mc_7wCuuwh6QrrYMzdJC_T2d2->mc_tC_lhrVr7sh_ia6yMUjV21->
mc_gN74BbsU5wqNjkJbC9b672!=0){mc_7wCuuwh6QrrYMzdJC_T2d2->
mc_yexQ7PGNxKybgqoevZ_Qn0=mc_UIJXHcO0bfWk_WsGNAlpf0(2,
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_tC_lhrVr7sh_ia6yMUjV21,0);return(
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_yexQ7PGNxKybgqoevZ_Qn0)?MC_LA_OK:MC_LA_ERROR;}
else{mc_7wCuuwh6QrrYMzdJC_T2d2->mc_yexQ7PGNxKybgqoevZ_Qn0=NULL;return MC_LA_OK
;}}static void mc_WuORYVkHY43SpvhXq66_G_(McLinearAlgebraData*
mc_7wCuuwh6QrrYMzdJC_T2d2){mc_ibXoOPiOM7SU6MRFBjZnr2(mc_7wCuuwh6QrrYMzdJC_T2d2
->mc_CidkhIpoznJNHlW_9nU022);mc_7wCuuwh6QrrYMzdJC_T2d2->
mc_CidkhIpoznJNHlW_9nU022=NULL;}static McLinearAlgebraStatus
mc_AQWe12LvZYrYn_1eWrYRS1(McLinearAlgebra*mc_hWAHcsuAg4VvIe1q1qkLx0,const
real_T*mc_gyGYov8P2mGIOhM9NpVPE1){McLinearAlgebraData*
mc_7wCuuwh6QrrYMzdJC_T2d2=mc_hWAHcsuAg4VvIe1q1qkLx0->mPrivateData;
mc_WuORYVkHY43SpvhXq66_G_(mc_7wCuuwh6QrrYMzdJC_T2d2);if(
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_tC_lhrVr7sh_ia6yMUjV21->
mc_gN74BbsU5wqNjkJbC9b672!=0){memcpy(&(mc_7wCuuwh6QrrYMzdJC_T2d2->
mc_tC_lhrVr7sh_ia6yMUjV21->x),&mc_gyGYov8P2mGIOhM9NpVPE1,sizeof(real_T*));
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_CidkhIpoznJNHlW_9nU022=mc_Nf5R0F6K47SZgpezuH2h50
(mc_7wCuuwh6QrrYMzdJC_T2d2->mc_tC_lhrVr7sh_ia6yMUjV21,
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_yexQ7PGNxKybgqoevZ_Qn0,1.0);
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_tC_lhrVr7sh_ia6yMUjV21->x=NULL;return(
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_CidkhIpoznJNHlW_9nU022!=NULL)?MC_LA_OK:
MC_LA_ERROR;}else{mc_7wCuuwh6QrrYMzdJC_T2d2->mc_CidkhIpoznJNHlW_9nU022=NULL;
return MC_LA_OK;}}static McLinearAlgebraStatus mc_ibcB2b1zbJTJmB6B3a2JG_(
McLinearAlgebra*mc_hWAHcsuAg4VvIe1q1qkLx0,const real_T*
mc_gyGYov8P2mGIOhM9NpVPE1,real_T*mc_weJJEbZC68zl9cO9Vc0TF2,const real_T*
mc_8ksqc0VFHLjSHzNxXK8mN0){McLinearAlgebraData*mc_7wCuuwh6QrrYMzdJC_T2d2=
mc_hWAHcsuAg4VvIe1q1qkLx0->mPrivateData;int32_T n=mc_7wCuuwh6QrrYMzdJC_T2d2->
mc_tC_lhrVr7sh_ia6yMUjV21->n;int32_T mc_5I3cMmT4MjMq2vMNweuQ_1=0;(void)
mc_gyGYov8P2mGIOhM9NpVPE1;;;;if(n>0){mc_5I3cMmT4MjMq2vMNweuQ_1=
mc_velqwEVC8fLQCaCDqKcxE1(mc_7wCuuwh6QrrYMzdJC_T2d2->mc_CidkhIpoznJNHlW_9nU022
->mc_EddJPU9FSjGK3NHuQHVJK0,mc_8ksqc0VFHLjSHzNxXK8mN0,
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_H5689kwuO84gcntlA8oHf0->mX,n);;
mc_5I3cMmT4MjMq2vMNweuQ_1=mc_myrncps3Bp4niT9SMNSFU0(mc_7wCuuwh6QrrYMzdJC_T2d2
->mc_CidkhIpoznJNHlW_9nU022->mc_Ko2UL7FliD3gp_gb0mLQz1,
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_H5689kwuO84gcntlA8oHf0->mX);;
mc_5I3cMmT4MjMq2vMNweuQ_1=mc_7TIwraGWa7_N5cUNFCHh5_(mc_7wCuuwh6QrrYMzdJC_T2d2
->mc_CidkhIpoznJNHlW_9nU022->mc_ks8rkpJYX5jHaEJjD6Z6h1,
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_H5689kwuO84gcntlA8oHf0->mX);;
mc_5I3cMmT4MjMq2vMNweuQ_1=mc_velqwEVC8fLQCaCDqKcxE1(mc_7wCuuwh6QrrYMzdJC_T2d2
->mc_yexQ7PGNxKybgqoevZ_Qn0->mc_RAQgyWVtpyqfEVcLRZFTL_,
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_H5689kwuO84gcntlA8oHf0->mX,
mc_weJJEbZC68zl9cO9Vc0TF2,n);;}return MC_LA_OK;}static real_T
mc_evgLf3R3PSSdjbGnhXq5_0(const McLinearAlgebra*mc_hWAHcsuAg4VvIe1q1qkLx0){
McLinearAlgebraData*mc_7wCuuwh6QrrYMzdJC_T2d2=mc_hWAHcsuAg4VvIe1q1qkLx0->
mPrivateData;if(mc_7wCuuwh6QrrYMzdJC_T2d2->mc_CidkhIpoznJNHlW_9nU022==NULL){
return pmf_get_inf();}{mc_6Y_awzn17rlf_oaSmGr222*mc_ks8rkpJYX5jHaEJjD6Z6h1=
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_CidkhIpoznJNHlW_9nU022->
mc_ks8rkpJYX5jHaEJjD6Z6h1;real_T mc_gh1jWiZ41qnzVFTvXD4Fr1=0.0;real_T
mc_uoPrpY0QxbhLeamrOkpJu1= -1.0;int32_T mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_7wCuuwh6QrrYMzdJC_T2d2->mc_tC_lhrVr7sh_ia6yMUjV21->n;++
mc_SmSSPSQfR1qEYWsVj5ELF0){real_T mc_IL4GBPwutZWtu_8EOdYr72=fabs(
mc_ks8rkpJYX5jHaEJjD6Z6h1->x[mc_ks8rkpJYX5jHaEJjD6Z6h1->
pm_KYlcoOk9rSSGYswizhYqZ2[mc_SmSSPSQfR1qEYWsVj5ELF0+1]-1]);if(
mc_IL4GBPwutZWtu_8EOdYr72>mc_gh1jWiZ41qnzVFTvXD4Fr1){mc_gh1jWiZ41qnzVFTvXD4Fr1
=mc_IL4GBPwutZWtu_8EOdYr72;}if((mc_uoPrpY0QxbhLeamrOkpJu1<0.0)||(
mc_IL4GBPwutZWtu_8EOdYr72<mc_uoPrpY0QxbhLeamrOkpJu1)){
mc_uoPrpY0QxbhLeamrOkpJu1=mc_IL4GBPwutZWtu_8EOdYr72;}}return(
mc_gh1jWiZ41qnzVFTvXD4Fr1/mc_uoPrpY0QxbhLeamrOkpJu1);}return 0.0;}static size_t
mc_6X6SPtTaBSaXrZdKVnZiu1(const mc_6Y_awzn17rlf_oaSmGr222*a){return sizeof(*a)
+(a->n+1)*sizeof(int32_T)+a->mc_ljdetJMOCfBq2uHQ_Xw_v0*sizeof(int32_T)+a->
mc_ljdetJMOCfBq2uHQ_Xw_v0*sizeof(double);}static size_t
mc_sbhb4kap36m8H1axAa_ZM1(const McLinearAlgebra*mc_hWAHcsuAg4VvIe1q1qkLx0){
const McLinearAlgebraData*mc_SKHbY6rGfe_c5uusXTSRI1=mc_hWAHcsuAg4VvIe1q1qkLx0
->mPrivateData;;return sizeof(*mc_hWAHcsuAg4VvIe1q1qkLx0)+sizeof(*
mc_SKHbY6rGfe_c5uusXTSRI1)+mc_6X6SPtTaBSaXrZdKVnZiu1(mc_SKHbY6rGfe_c5uusXTSRI1
->mc_tC_lhrVr7sh_ia6yMUjV21)+(mc_SKHbY6rGfe_c5uusXTSRI1->
mc_yexQ7PGNxKybgqoevZ_Qn0==NULL?0:((sizeof(*mc_SKHbY6rGfe_c5uusXTSRI1->
mc_yexQ7PGNxKybgqoevZ_Qn0)+mc_SKHbY6rGfe_c5uusXTSRI1->
mc_tC_lhrVr7sh_ia6yMUjV21->n*sizeof(int32_T))))+(mc_SKHbY6rGfe_c5uusXTSRI1->
mc_CidkhIpoznJNHlW_9nU022==NULL?0:(sizeof(*mc_SKHbY6rGfe_c5uusXTSRI1->
mc_CidkhIpoznJNHlW_9nU022)+mc_6X6SPtTaBSaXrZdKVnZiu1(mc_SKHbY6rGfe_c5uusXTSRI1
->mc_CidkhIpoznJNHlW_9nU022->mc_Ko2UL7FliD3gp_gb0mLQz1)+
mc_6X6SPtTaBSaXrZdKVnZiu1(mc_SKHbY6rGfe_c5uusXTSRI1->mc_CidkhIpoznJNHlW_9nU022
->mc_ks8rkpJYX5jHaEJjD6Z6h1)+mc_SKHbY6rGfe_c5uusXTSRI1->
mc_CidkhIpoznJNHlW_9nU022->mc_ks8rkpJYX5jHaEJjD6Z6h1->n*sizeof(int32_T)))+
sizeof(*mc_SKHbY6rGfe_c5uusXTSRI1->mc_H5689kwuO84gcntlA8oHf0)+
mc_SKHbY6rGfe_c5uusXTSRI1->mc_H5689kwuO84gcntlA8oHf0->mN*sizeof(double);}
static void mc_sqirQilUIkV1gbrpqe2T21(McLinearAlgebra*
mc_hWAHcsuAg4VvIe1q1qkLx0){McLinearAlgebraData*mc_7wCuuwh6QrrYMzdJC_T2d2=
mc_hWAHcsuAg4VvIe1q1qkLx0->mPrivateData;PmAllocator*mc_YMfc_eB3rHMVJUig1uu500=
pm_default_allocator();mc_WuORYVkHY43SpvhXq66_G_(mc_7wCuuwh6QrrYMzdJC_T2d2);
mc_tw08gA1Pc97CibZ9SYzgn1(mc_7wCuuwh6QrrYMzdJC_T2d2->mc_yexQ7PGNxKybgqoevZ_Qn0
);mc_vVHvSM_NFYPGyKpyBY_yU2(mc_7wCuuwh6QrrYMzdJC_T2d2->
mc_tC_lhrVr7sh_ia6yMUjV21);pm_destroy_real_vector(mc_7wCuuwh6QrrYMzdJC_T2d2->
mc_H5689kwuO84gcntlA8oHf0,mc_YMfc_eB3rHMVJUig1uu500);{void*
mc_GAbHnJspJ6sMhe_Yzxehb_=(mc_7wCuuwh6QrrYMzdJC_T2d2);if(
mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,mc_GAbHnJspJ6sMhe_Yzxehb_);}};{void*
mc_GAbHnJspJ6sMhe_Yzxehb_=(mc_hWAHcsuAg4VvIe1q1qkLx0);if(
mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,mc_GAbHnJspJ6sMhe_Yzxehb_);}};}static
McLinearAlgebraStatus mc_rwm4kTAkKsVETqjBwRy5o_(const McLinearAlgebraFactory*
mc___8zuxSRixcOGs7OSRauz0,McLinearAlgebra**mc_bhvtgLLFE6OQKvLokt6b82,const
PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1){PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500=pm_default_allocator();McLinearAlgebra*
mc_hWAHcsuAg4VvIe1q1qkLx0=(McLinearAlgebra*)((mc_YMfc_eB3rHMVJUig1uu500)->
mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(McLinearAlgebra)),(1)));
McLinearAlgebraStatus mc_v4k0LG4l9Qk9hEXlOIKML_;mc_hWAHcsuAg4VvIe1q1qkLx0->
mPrivateData=mc_Jl_GarlRcCaE6gKc0GQAQ2(mc_YMfc_eB3rHMVJUig1uu500,
mc_3fmwBoA2gfKGlaDfp8GCd1);mc_hWAHcsuAg4VvIe1q1qkLx0->mFactor= &
mc_AQWe12LvZYrYn_1eWrYRS1;mc_hWAHcsuAg4VvIe1q1qkLx0->mSolve= &
mc_ibcB2b1zbJTJmB6B3a2JG_;mc_hWAHcsuAg4VvIe1q1qkLx0->mCondest= &
mc_evgLf3R3PSSdjbGnhXq5_0;mc_hWAHcsuAg4VvIe1q1qkLx0->mMemusage= &
mc_sbhb4kap36m8H1axAa_ZM1;mc_hWAHcsuAg4VvIe1q1qkLx0->mDestructor= &
mc_sqirQilUIkV1gbrpqe2T21;mc_v4k0LG4l9Qk9hEXlOIKML_=mc_YaF5Fp1Plk4pNI6fTGlvy2(
mc_hWAHcsuAg4VvIe1q1qkLx0);if(mc_v4k0LG4l9Qk9hEXlOIKML_!=MC_LA_OK){return
mc_v4k0LG4l9Qk9hEXlOIKML_;}*mc_bhvtgLLFE6OQKvLokt6b82=
mc_hWAHcsuAg4VvIe1q1qkLx0;return MC_LA_OK;}const McLinearAlgebraFactory*
mc_get_csparse_linear_algebra(void){static McLinearAlgebraFactory
mc___8zuxSRixcOGs7OSRauz0;mc___8zuxSRixcOGs7OSRauz0 .mCreateLinearAlgebra= &
mc_rwm4kTAkKsVETqjBwRy5o_;return&mc___8zuxSRixcOGs7OSRauz0;}
