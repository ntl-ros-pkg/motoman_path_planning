#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
typedef enum{mc_KhnGFEmutK29G1pFMV7eY2= -1,mc_DKQ2NLbquneq0lUPeY6980,
mc_pZ2gSv1PwNXkkpsIRojds1,mc_s3f6TbPTFsg3OoFmSAmw9_,mc_UVVwEZg9VhYkMacmned87_,
mc_We99sVwuHRSx58iJnCFWJ1,mc_l850kaw5_IoBVNaRVt13c0,mc_PlLsh29Os6JPlaG9RqaLj1}
mc_v0sTqkEWafl9TPgVRJyQ40;typedef struct mc_19bbUnNHdpuZoJJqSICSW_
mc_6t7LXLIebfQbjqPLIcpqO0;typedef struct mc_FdDI_eCUecGeW1Q2_mqs_0
mc_1riz_dm55_hfBJXB4DyNB_;struct mc_19bbUnNHdpuZoJJqSICSW_{
mc_1riz_dm55_hfBJXB4DyNB_*mPrivateData;const PmSparsityPattern*
mc_t_6NUyOFwEImo4lDjZDMu0;void(*mc_AyOh1J4sMcEZ5O593pmQ51)(const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2,const PmRealVector*
mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_);void(*
mc__LRHwDZi5HADTASL9uO6a1)(const mc_6t7LXLIebfQbjqPLIcpqO0*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,
PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_);void(*mc_O7RdgDn1T_nH7US6HHVQG_)(const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2,const PmRealVector*
mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2
);};typedef struct mc_sksUtXCKsyfRzoAy_EJCt1 mc_CQR1HxE8a2eRqXwjXW9oa0;typedef
struct mc_XlL7_Zn4s883WRfEfstSW2 mc_LXMEbVulC3bx7mbvvKMn_2;typedef struct
mc_xvIvkmrpPTIGtKIauOUfW2 mc_vgDUFvn3w7_KCXUA_v_HD2;struct
mc_xvIvkmrpPTIGtKIauOUfW2{int32_T mc_sF0SDf2WsaxglnxAqCGtS_[5];};
PMF_DEPLOY_STATIC mc_vgDUFvn3w7_KCXUA_v_HD2 mc_qG_uWrr8MCsaW7uNtXw040(void){
int32_T mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_vgDUFvn3w7_KCXUA_v_HD2
mc_v4k0LG4l9Qk9hEXlOIKML_;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<5;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_v4k0LG4l9Qk9hEXlOIKML_.mc_sF0SDf2WsaxglnxAqCGtS_[mc_SmSSPSQfR1qEYWsVj5ELF0]
= -1;}return mc_v4k0LG4l9Qk9hEXlOIKML_;}struct mc_sksUtXCKsyfRzoAy_EJCt1{
mc_LXMEbVulC3bx7mbvvKMn_2*mPrivateData;mc_vgDUFvn3w7_KCXUA_v_HD2(*
mc_eYEHzsIN8nqYyqsuP8dFP_)(const mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_Y5DXpzShiOG2GaQUq2FSB1);mc_v0sTqkEWafl9TPgVRJyQ40(*mSolve)(const
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_Y5DXpzShiOG2GaQUq2FSB1,PmRealVector*
mc_HXCZ2st6GBkQ5VIT30wkn_);void(*mc_e4AXYFnkWU5C0XgM4b44f0)(const
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_Y5DXpzShiOG2GaQUq2FSB1,real_T
mc_o2MuMRRx_29b4Ojph5IVQ_);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_Y5DXpzShiOG2GaQUq2FSB1);};typedef struct
mc_MFsFuyvyFir36DykM2Ker0 mc_PLlF_m_QtaI7_tt0PCGyf1;typedef struct
mc_M4H_dJw2RQo92yFcMCUCM0 mc_htIw_3pJsSdIb219YsmvC2;struct
mc_MFsFuyvyFir36DykM2Ker0{mc_htIw_3pJsSdIb219YsmvC2*mPrivateData;
mc_CQR1HxE8a2eRqXwjXW9oa0*(*mc_kGZn4ZI8B8YZuZHR8f_Ge_)(const
mc_PLlF_m_QtaI7_tt0PCGyf1*mc_ahuEoDnPIcdVuf6ta8G74_,const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_PLlF_m_QtaI7_tt0PCGyf1*mc_ahuEoDnPIcdVuf6ta8G74_
);};typedef struct mc_37QfPjqHoJGWt2i1d6jwp1 mc_Kw4XXn2D_WU8CYQ3oKYko_;typedef
struct mc_6U9ZUYhvXluz_V10mJfq__ mc_VS09sPO3TGPMJ6D_dWUHz0;struct
mc_37QfPjqHoJGWt2i1d6jwp1{mc_VS09sPO3TGPMJ6D_dWUHz0*mPrivateData;const
PmSparsityPattern*mc_t_6NUyOFwEImo4lDjZDMu0;size_t mc_kn66IxdrCw_XrKK95TGqP0;
void(*mc_AyOh1J4sMcEZ5O593pmQ51)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_)
;void(*mc__LRHwDZi5HADTASL9uO6a1)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_)
;void(*mc_O7RdgDn1T_nH7US6HHVQG_)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_)
;void(*mc_imq97x4PVhYPNA5whBmrb1)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmIntVector*mc_cPpFNNxfnE9grx4hesF5K_);
void(*mc_YCFci8IAJkK9w_xpRtHta2)(mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2);};typedef struct mc_XIveXXmyy6ZcWCK72B3Pv_
mc_fl9iBeRv9MXedftZs5Hng1;typedef struct mc_4j8KoTStz8dpeewDPSSli1
mc_p92uNVBVufg49GV_vD4C12;struct mc_XIveXXmyy6ZcWCK72B3Pv_{
mc_p92uNVBVufg49GV_vD4C12*mPrivateData;mc_v0sTqkEWafl9TPgVRJyQ40(*mSolve)(
const mc_fl9iBeRv9MXedftZs5Hng1*,PmIntVector*,PmRealVector*);
mc_vgDUFvn3w7_KCXUA_v_HD2(*mc_eYEHzsIN8nqYyqsuP8dFP_)(const
mc_fl9iBeRv9MXedftZs5Hng1*mc_Y5DXpzShiOG2GaQUq2FSB1);void(*
mc_e4AXYFnkWU5C0XgM4b44f0)(const mc_fl9iBeRv9MXedftZs5Hng1*
mc_Y5DXpzShiOG2GaQUq2FSB1,real_T mc_o2MuMRRx_29b4Ojph5IVQ_);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_fl9iBeRv9MXedftZs5Hng1*mc_Y5DXpzShiOG2GaQUq2FSB1
);};typedef struct mc_AfEjJUNcqSkIPzD9dRIdP_ mc_tS_co0MBelOZrF3oiC_9a_;typedef
struct mc_lGu3jZxBJ5DlayhsoZuI_0 mc_844eBfbNpGwgOIobDyTlT1;struct
mc_AfEjJUNcqSkIPzD9dRIdP_{mc_844eBfbNpGwgOIobDyTlT1*mPrivateData;
mc_fl9iBeRv9MXedftZs5Hng1*(*mc_kGZn4ZI8B8YZuZHR8f_Ge_)(const
mc_tS_co0MBelOZrF3oiC_9a_*mc_ahuEoDnPIcdVuf6ta8G74_,const
mc_Kw4XXn2D_WU8CYQ3oKYko_*mc_B3C4xlzGIoRKlgT97lKBi2);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_tS_co0MBelOZrF3oiC_9a_*mc_ahuEoDnPIcdVuf6ta8G74_
);};size_t mc_Um0_uBe2nXcaztNK3no_11(real_T mc_RGllRMvIRPGkpbvuetJlO2,real_T
mc_wddHGiXi3WSIJ_aoya9HO_,real_T mc_m5PqR93OiEd5D6cYuVcuX1,size_t
mc_ccxGCbcfPmEtYF8Qlj1Xw2);
#include "pm_std.h"
#include "math.h"
size_t mc_Um0_uBe2nXcaztNK3no_11(real_T mc_RGllRMvIRPGkpbvuetJlO2,real_T
mc_wddHGiXi3WSIJ_aoya9HO_,real_T mc_m5PqR93OiEd5D6cYuVcuX1,size_t
mc_ccxGCbcfPmEtYF8Qlj1Xw2){;;;;;{real_T mc_KeVQkE583tYly3nSa0vRD0=log(
mc_RGllRMvIRPGkpbvuetJlO2/mc_wddHGiXi3WSIJ_aoya9HO_);real_T
mc_hLU_4Ykn2BPNUPmTXy__x1=log(mc_m5PqR93OiEd5D6cYuVcuX1/
mc_wddHGiXi3WSIJ_aoya9HO_);real_T mc_RJZDaMlDxrzhBwuXDeKan2=
mc_KeVQkE583tYly3nSa0vRD0/mc_hLU_4Ykn2BPNUPmTXy__x1;size_t
mc_crwvO51ifIKrB2sPgDI5N_=(size_t)floor(mc_RJZDaMlDxrzhBwuXDeKan2*(real_T)
mc_ccxGCbcfPmEtYF8Qlj1Xw2);if(mc_crwvO51ifIKrB2sPgDI5N_>=
mc_ccxGCbcfPmEtYF8Qlj1Xw2){mc_crwvO51ifIKrB2sPgDI5N_=mc_ccxGCbcfPmEtYF8Qlj1Xw2
-1;};;;return mc_crwvO51ifIKrB2sPgDI5N_;}}
