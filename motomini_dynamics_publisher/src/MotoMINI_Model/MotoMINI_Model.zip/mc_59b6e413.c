#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
typedef enum{mc_KhnGFEmutK29G1pFMV7eY2= -1,mc_DKQ2NLbquneq0lUPeY6980,
mc_pZ2gSv1PwNXkkpsIRojds1,mc_s3f6TbPTFsg3OoFmSAmw9_,mc_UVVwEZg9VhYkMacmned87_,
mc_We99sVwuHRSx58iJnCFWJ1,mc_l850kaw5_IoBVNaRVt13c0,mc_PlLsh29Os6JPlaG9RqaLj1}
mc_v0sTqkEWafl9TPgVRJyQ40;typedef struct mc_19bbUnNHdpuZoJJqSICSW_
mc_6t7LXLIebfQbjqPLIcpqO0;typedef struct mc_FdDI_eCUecGeW1Q2_mqs_0
mc_1riz_dm55_hfBJXB4DyNB_;struct mc_19bbUnNHdpuZoJJqSICSW_{
mc_1riz_dm55_hfBJXB4DyNB_*mPrivateData;const PmSparsityPattern*
mc_t_6NUyOFwEImo4lDjZDMu0;void(*mc_AyOh1J4sMcEZ5O593pmQ51)(const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2,const PmRealVector*
mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_);void(*
mc__LRHwDZi5HADTASL9uO6a1)(const mc_6t7LXLIebfQbjqPLIcpqO0*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,
PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_);void(*mc_O7RdgDn1T_nH7US6HHVQG_)(const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2,const PmRealVector*
mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2
);};typedef struct mc_sksUtXCKsyfRzoAy_EJCt1 mc_CQR1HxE8a2eRqXwjXW9oa0;typedef
struct mc_XlL7_Zn4s883WRfEfstSW2 mc_LXMEbVulC3bx7mbvvKMn_2;typedef struct
mc_xvIvkmrpPTIGtKIauOUfW2 mc_vgDUFvn3w7_KCXUA_v_HD2;struct
mc_xvIvkmrpPTIGtKIauOUfW2{int32_T mc_sF0SDf2WsaxglnxAqCGtS_[5];};
PMF_DEPLOY_STATIC mc_vgDUFvn3w7_KCXUA_v_HD2 mc_qG_uWrr8MCsaW7uNtXw040(void){
int32_T mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_vgDUFvn3w7_KCXUA_v_HD2
mc_v4k0LG4l9Qk9hEXlOIKML_;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<5;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_v4k0LG4l9Qk9hEXlOIKML_.mc_sF0SDf2WsaxglnxAqCGtS_[mc_SmSSPSQfR1qEYWsVj5ELF0]
= -1;}return mc_v4k0LG4l9Qk9hEXlOIKML_;}struct mc_sksUtXCKsyfRzoAy_EJCt1{
mc_LXMEbVulC3bx7mbvvKMn_2*mPrivateData;mc_vgDUFvn3w7_KCXUA_v_HD2(*
mc_eYEHzsIN8nqYyqsuP8dFP_)(const mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_Y5DXpzShiOG2GaQUq2FSB1);mc_v0sTqkEWafl9TPgVRJyQ40(*mSolve)(const
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_Y5DXpzShiOG2GaQUq2FSB1,PmRealVector*
mc_HXCZ2st6GBkQ5VIT30wkn_);void(*mc_e4AXYFnkWU5C0XgM4b44f0)(const
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_Y5DXpzShiOG2GaQUq2FSB1,real_T
mc_o2MuMRRx_29b4Ojph5IVQ_);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_Y5DXpzShiOG2GaQUq2FSB1);};typedef struct
mc_MFsFuyvyFir36DykM2Ker0 mc_PLlF_m_QtaI7_tt0PCGyf1;typedef struct
mc_M4H_dJw2RQo92yFcMCUCM0 mc_htIw_3pJsSdIb219YsmvC2;struct
mc_MFsFuyvyFir36DykM2Ker0{mc_htIw_3pJsSdIb219YsmvC2*mPrivateData;
mc_CQR1HxE8a2eRqXwjXW9oa0*(*mc_kGZn4ZI8B8YZuZHR8f_Ge_)(const
mc_PLlF_m_QtaI7_tt0PCGyf1*mc_ahuEoDnPIcdVuf6ta8G74_,const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_B3C4xlzGIoRKlgT97lKBi2);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_PLlF_m_QtaI7_tt0PCGyf1*mc_ahuEoDnPIcdVuf6ta8G74_
);};typedef struct mc_37QfPjqHoJGWt2i1d6jwp1 mc_Kw4XXn2D_WU8CYQ3oKYko_;typedef
struct mc_6U9ZUYhvXluz_V10mJfq__ mc_VS09sPO3TGPMJ6D_dWUHz0;struct
mc_37QfPjqHoJGWt2i1d6jwp1{mc_VS09sPO3TGPMJ6D_dWUHz0*mPrivateData;const
PmSparsityPattern*mc_t_6NUyOFwEImo4lDjZDMu0;size_t mc_kn66IxdrCw_XrKK95TGqP0;
void(*mc_AyOh1J4sMcEZ5O593pmQ51)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_)
;void(*mc__LRHwDZi5HADTASL9uO6a1)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_)
;void(*mc_O7RdgDn1T_nH7US6HHVQG_)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmRealVector*mc_cPpFNNxfnE9grx4hesF5K_)
;void(*mc_imq97x4PVhYPNA5whBmrb1)(const mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2,const PmIntVector*mc_9B2CmXnOZxzdzFPkCQl0J_,const
PmRealVector*mc_esW17s79xh5U8ICFKPDHe1,PmIntVector*mc_cPpFNNxfnE9grx4hesF5K_);
void(*mc_YCFci8IAJkK9w_xpRtHta2)(mc_Kw4XXn2D_WU8CYQ3oKYko_*
mc_B3C4xlzGIoRKlgT97lKBi2);};typedef struct mc_XIveXXmyy6ZcWCK72B3Pv_
mc_fl9iBeRv9MXedftZs5Hng1;typedef struct mc_4j8KoTStz8dpeewDPSSli1
mc_p92uNVBVufg49GV_vD4C12;struct mc_XIveXXmyy6ZcWCK72B3Pv_{
mc_p92uNVBVufg49GV_vD4C12*mPrivateData;mc_v0sTqkEWafl9TPgVRJyQ40(*mSolve)(
const mc_fl9iBeRv9MXedftZs5Hng1*,PmIntVector*,PmRealVector*);
mc_vgDUFvn3w7_KCXUA_v_HD2(*mc_eYEHzsIN8nqYyqsuP8dFP_)(const
mc_fl9iBeRv9MXedftZs5Hng1*mc_Y5DXpzShiOG2GaQUq2FSB1);void(*
mc_e4AXYFnkWU5C0XgM4b44f0)(const mc_fl9iBeRv9MXedftZs5Hng1*
mc_Y5DXpzShiOG2GaQUq2FSB1,real_T mc_o2MuMRRx_29b4Ojph5IVQ_);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_fl9iBeRv9MXedftZs5Hng1*mc_Y5DXpzShiOG2GaQUq2FSB1
);};typedef struct mc_AfEjJUNcqSkIPzD9dRIdP_ mc_tS_co0MBelOZrF3oiC_9a_;typedef
struct mc_lGu3jZxBJ5DlayhsoZuI_0 mc_844eBfbNpGwgOIobDyTlT1;struct
mc_AfEjJUNcqSkIPzD9dRIdP_{mc_844eBfbNpGwgOIobDyTlT1*mPrivateData;
mc_fl9iBeRv9MXedftZs5Hng1*(*mc_kGZn4ZI8B8YZuZHR8f_Ge_)(const
mc_tS_co0MBelOZrF3oiC_9a_*mc_ahuEoDnPIcdVuf6ta8G74_,const
mc_Kw4XXn2D_WU8CYQ3oKYko_*mc_B3C4xlzGIoRKlgT97lKBi2);void(*
mc_YCFci8IAJkK9w_xpRtHta2)(mc_tS_co0MBelOZrF3oiC_9a_*mc_ahuEoDnPIcdVuf6ta8G74_
);};
#include "mc_std.h"
mc_PLlF_m_QtaI7_tt0PCGyf1*mc_unUcHqjWIYGRq_Mtqq_Nn2(PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2,const McLinearAlgebraFactory*
mc_fEMEImnNQqYTsF_hhnViM_,size_t mc_dcWK_oZ494lWUUSVfX49q_,size_t
mc_c4Be4xgcKkVHw4vEl4fzN_,boolean_T mc_T4nOzZJftws6FFq_tnOs21,boolean_T
mc_b0T0sQrZQjaoNty2a39Jf_);mc_PLlF_m_QtaI7_tt0PCGyf1*mc_H4E5qy2gElz_ZzQWqCBUr1
(PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2,const McLinearAlgebraFactory*
mc_fEMEImnNQqYTsF_hhnViM_,size_t mc_dcWK_oZ494lWUUSVfX49q_,size_t
mc_c4Be4xgcKkVHw4vEl4fzN_,size_t mc_tb2e_ottQVj6_QEQuXmBD_,boolean_T
mc_T4nOzZJftws6FFq_tnOs21,boolean_T mc_b0T0sQrZQjaoNty2a39Jf_);
#include "pm_std.h"
#include "mc_std.h"
typedef struct mc_fNJsRy63YTYqID27k01DO0{PmAllocator*mc_EJyLFJLNS54LEp1_ia1250
;PmRealVector*mc_ltECqhO3SRHXpOO6jz6sa1;PmSparsityPattern*
mc_v1PtjBLfQ4A_siw2pYUbk0;PmRealVector*mc_hvWaSIvLykm6py2NoXU5q1;
PmSparsityPattern*mc_dwwTM9g_8xSBiWtj9itU41;PmRealVector*
mc__GHMiXG9wSaQnjt44OApy2;PmSparsityPattern*mc_jXaNLfBb9ByJwgQkl_XYF1;
McLinearAlgebra*mc_K_h_QGfDP2hmcZVnT725C1;}mc_o5CREMPu1I_XB5p0nCI6N2;
mc_o5CREMPu1I_XB5p0nCI6N2*mc_LEkjn0HScoulloiZuU3yi_(const PmSparsityPattern*
mc_1S82_qZ30MSrHVx9_7J5A2,const McLinearAlgebraFactory*
mc_fEMEImnNQqYTsF_hhnViM_,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);void
mc_7_R4McQBwppLSGlfrN9ts1(mc_o5CREMPu1I_XB5p0nCI6N2*mc_6peHhhgu8wo0Kp3HDh_aI0)
;McLinearAlgebraStatus mc_uvUOg06hpCr7h7LKTqMWz_(PmRealVector*
mc_4HETDgQWZrSFYff_ic0xK_,PmRealVector*x,PmRealVector*
mc_VxxeDNxb3XYZvQXh_7Mga_,mc_o5CREMPu1I_XB5p0nCI6N2*mc_6peHhhgu8wo0Kp3HDh_aI0,
const PmSparsityPattern*mc_1S82_qZ30MSrHVx9_7J5A2);void pm_rv_equals_rv(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_TnPSeUZeYw5Wc8bvD8sl80(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_fKS8kuV7G_WhlO7CcdVnc1(const
PmCharVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm___43lXp90F4bzSkAXqYfT1(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);int_T pm_create_real_vector_fields(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_create_real_vector(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(
const PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_destroy_real_vector(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_int_vector_fields(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmIntVector*pm_create_int_vector(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_pLia5sG_NxTeQbxzYtpXx_(const
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_Rdk2CZ3CCj5T0d2uDHUZ20(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_int_vector(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_
(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_SK8Vck8jU45BIyJDK11DV_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*
pm_Or6MViYTj4_1rM_3pn1UZ0(const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_cn_kUNHZ0hjihWokUKapj_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_nUREx2_I6_H8Z9q4fW3LX2(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);
#include "pm_std.h"
#include "pm_std.h"
size_t mc_KpKqaZjZ2rh3lSToFa7Oa2(const PmBoolVector*mc_ljExW6hRw43Vg4SLQUAvT1)
;void mc_KLKWK_FbEAF724qPNbehq1(const PmIntVector*mc_ykDPEcD4BuT8SJa7vuxej1,
const PmRealVector*x,const PmRealVector*mc_yS7VvSIKrGg9ddzBqHtUd_);void
mc_uJ_iGAyluQ5NndhonaPXl1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const PmIntVector*
mc_kmcnrlTt6IvFH5HSoyHe21);void mc_oT_HwSgZBfR7LPqZomt0Y0(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmIntVector*mc_kmcnrlTt6IvFH5HSoyHe21);void mc_mMmDjYPdSIEEQHj__7cd71(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_);void mc_zYvj4jole4TnufsPoZWW_2(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0);void
mc_TJe2EtJyyhfHpuJYOjxfC0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,boolean_T mc_7lBL31aWjgSfMHGQtksob2);
void mc_JM1DLKwRGzo9Uyq32V72E_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*mc_MmlNWCb0Iec292kl7KbkQ1);void mc_si_irLJWyQLY_l4tqebAe_(
const PmIntVector*mc_rxT7_6KqJcx5sNYEWRALX2,int32_T mc_RGllRMvIRPGkpbvuetJlO2)
;void mc_pJmDkwzzX3Iu6_VR_MyvL_(const PmBoolVector*mc_Hf_a_gs1wyoHoosYiGonU0,
const PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_YwEOIpm092vI_BA0rQzvJ2);void mc_SKE1EUStKD_KtRTTXrxqv2(const PmBoolVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmBoolVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_OT_v_IC_x9R85Z4eHn1jA0(const PmRealVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmRealVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_J9HotRGeuZtxiip_GSZPb0(PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);size_t
mc_lp5J2bZ8EcxnhyI1PKPZd2(const PmBoolVector*mc_G15g52JPQFeDaEm_uJadW_);void
mc__xr97Mh4VU4bdE2CcyEVf_(const PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,const
PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_);size_t mc_pdD80p5I4a4oDKki08oZ50(const
PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0);size_t mc_a_dd0x8Rstf0HD74BJt9A2(const
PmRealVector*mc_ZxltZcnt1eSoyJTnrOm7z2);size_t mc_8u8_LRBN9SbcEOkeum7ag0(const
PmBoolVector*mc_ZxltZcnt1eSoyJTnrOm7z2);boolean_T mc_Ukc2BYyTIIZDpb_lFOWTt0(
const PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0);boolean_T
mc_l26oJh0UM_xwSgKIeOC5J0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,int32_T
mc_RGllRMvIRPGkpbvuetJlO2);boolean_T mc_ocDPr6f6C4_v9b5NDj8JH_(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T mc_RGllRMvIRPGkpbvuetJlO2);void
mc_fuQc8C9CyCuf_KkBLV8eb0(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_8BTcsQ6C8h5zrW1ZQRhKf1(const
PmRealVector*x,real_T mc_ljExW6hRw43Vg4SLQUAvT1);void mc_W0fX8K54ez0qAgM9tXjsi_
(const PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_fjtK_RGCYgp34_TjPN6zv1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_LlLyVwCApgTvSBfIvzOuk0(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T a,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void mc_fIL9UyKjuKeUlnGmcXq5r2(const PmRealVector*x
,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_SheEjf_3lOXDmgzkmhMGG2);void mc_v7V5uZPqLRlsEpMCWsoMJ0(const PmRealVector*x
,const real_T a,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_DnL_y_DaeSoRsDtnK0hpB1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
real_T mc_8IKoYx3qsjeiwHerWlCOS1);void mc_I_W_409sg28ysFYlBfPcr_(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const real_T mc_8IKoYx3qsjeiwHerWlCOS1)
;void mc_MI5F4RaYNQR7pPk1GRkvn_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_lkC6x3YtrvW6L16S6aM60_(
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void mc_vfuXLuRk3KtAfbvK_cTrv2(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
mc_tOKZMGNlSqK650YhjgeKv0(const PmRealVector*mc_9JsNfMLIQx0SlNuEaL4I2_,real_T
mc_8IKoYx3qsjeiwHerWlCOS1);void mc_Uy10YSjkY75ViJd9dTdYI1(const PmBoolVector*
mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_Rhhlgu4QH_WTKd_5kpe4I2(const PmRealVector*
mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_WmHTznO_Ih_dJw_MhKtIQ1(const PmIntVector*
mc_9JsNfMLIQx0SlNuEaL4I2_,int32_T mc_RGllRMvIRPGkpbvuetJlO2);void
mc_nLc17gFNFcvBlJrwxJV4w_(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void
mc_W7kR8viSTKC_By0UjXE_A1(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void
mc_AQtCbBjZ792h1_Xaj_dR92(const PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0,const
PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,boolean_T mc_8IKoYx3qsjeiwHerWlCOS1);
void mc_tLxHiRii5tbHWjrunaI2i1(const PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_,
boolean_T mc_8IKoYx3qsjeiwHerWlCOS1);void mc_AZRifAjle326aZku91XJU2(const
PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_mGD4FL6_MDLg2bdqzdpfx_(const
PmBoolVector*x,size_t mc_SmSSPSQfR1qEYWsVj5ELF0,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_x2bRmxKlHWAMEwOZuiA_62(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);void
mc_eJ9VFRIFMWxO52_BT7X_C_(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);real_T mc_WJAbbKueqClxuItYQx7b61(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);real_T mc_TuU8NakpY91qxLM4is2wV2(const
PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82);int32_T mc_dLmR9a64iWQBHX4QM5zCr2(
const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82);int32_T mc_eIjmwucqCUJT1PyCl_z5b_
(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82);void mc_loSQGFba0sjWysbLdmqzS1(
PmIntVector*mc_QyVbO3pTvGiccU8Tn2eK2_,const PmIntVector*
mc_kI6kqxnpJaUqvLfVbMkdr0);void mc_O_flPmjeFB4ZmON9Xp2iV_(PmRealVector*
mc_EBUUePJ08d2hXtTa8LU0J_,const PmRealVector*mc_23nxQONnTNHWizowC7lIt0,const
PmSparsityPattern*mc_UYX2aVqEUCl0fW5_qT4Lo1);void mc_K1ezq3TzhoNUE_SEp0Dr12(
const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void
mc_WuGlfcFda9zO01qKeAxMn_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void
mc_qEYnRq0Ff87lxOQck1Gqi_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const real_T*x);void mc_SZGAWN4U4XTzc5RKGKSk5_(const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*
mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,
const PmRealVector*mc_2cVF0Ggof80TSRmRbhE8l1,size_t mc_LMkPrnaKcsYHEp0eExPFH1)
;void mc_FoRQvfcV_dWdjx5L1lyM_0(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,
const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*mc_5LkYradW8mKeL3fLSt9By1);void mc_lBp5wbXG7AvQ3hxoerNOW_(const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*
mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void mc_z041e_QXd3uR2ef2CH37s1(
const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_0R8y9UtrLk3busEbM65xW_,const PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,
size_t mc_OUB2pptsvtdGL_LyqpgOa0,real_T mc_8IKoYx3qsjeiwHerWlCOS1);void
mc_6IsBGrycIJELSxeQVWGP02(const PmRealVector*mc_SheEjf_3lOXDmgzkmhMGG2,const
PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_fDK_uVHGu_qFAztUmYrXG0(const PmRealVector*mc_Hf_a_gs1wyoHoosYiGonU0,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_Ma839gzucrzsXwGyDhMa82);void mc_Pv5PxBp1nNTpA2nv2TKO50(const PmRealVector*
mc_Hf_a_gs1wyoHoosYiGonU0,const PmIntVector*mc_Ma839gzucrzsXwGyDhMa82,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_);void mc_57l_YQYSoo0Ro6WNuRptH_(const
PmRealVector*a,const PmIntVector*mc_SmSSPSQfR1qEYWsVj5ELF0,const PmRealVector*
b);void mc_rQYUV3yV8oYU8KnRKkDRk1(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0);void mc_Xx__kIPwzSZkrHpStVmJF_(
const PmRealVector*a,const PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0,const
PmRealVector*b);void mc__oSPLVBiXeFzzJsThp3Cn_(const PmRealVector*a,const
PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0,real_T x);void mc_BtNbeiWJf_2ScS2FihDGI0
(const PmIntVector*mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*
mc_wgw5_klFOULlYUS4qsiDG1);void mc_rxnwynr09yoIhr_7WJOnw2(const PmBoolVector*
mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);
void mc_GXd0l4NyYg6UNbaEbfuyY1(const PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,
const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);void
mc_0IN6lZI7UaPeQvvz13t6Z_(const PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,const
PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);void mc_jk3AE9w8Z153JpwqOK4cP_(
const PmBoolVector*mc_v4k0LG4l9Qk9hEXlOIKML_,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmRealVector*mc_A1lUr3Ax9HoRb_bkcLe_A1);void
mc_PUtu_CUnyMAexj3n9ThPz1(const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_);void mc_wMbxp0k7MHKEjpdy17fjt_(const PmRealVector*
mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,
const PmBoolVector*mc_ID3sxM8zmIB_ZiazgNvWq2);void mc_5PAUXWifOqPPHW3wOzFa92(
const PmRealVector*mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmBoolVector*pm_gq3kPpO4Hdv_0UBmX5sfB1);
PmRealVector mc_mnPo3YlQdExsVqjHael_W2(const PmRealVector*
mc_ljExW6hRw43Vg4SLQUAvT1,size_t mc_XteRrKcywHWBP4sFymZ6y0,size_t
mc_jcOSsrULtHDGKqSRz3gAT0);
#include "mc_std.h"
#include "math.h"
struct mc_M4H_dJw2RQo92yFcMCUCM0{PmAllocator*mc_EJyLFJLNS54LEp1_ia1250;const
McLinearAlgebraFactory*mc_szjdoJ0Befv4Eq4qdPTaZ0;size_t
mc_bD63qgCe1sC0NmhBmoIGE0;size_t mc_MgKPEs8hlne8wrqVhAVQF0;size_t
mc_Tm8Lbh5KRx56rxKejUV0t0;boolean_T mc_KSlNGVMeN18j8yZoVHslw2;boolean_T
mc_Q2lBsX1utXvk5r7nR1bqw2;};struct mc_XlL7_Zn4s883WRfEfstSW2{const
mc_6t7LXLIebfQbjqPLIcpqO0*mc_cac5Wj3dXfzkBMmMZMucC2;boolean_T
mc_RtdxLSsahYG5F7avud7u42;real_T mFactor;mc_htIw_3pJsSdIb219YsmvC2
mc_pPFugFO3_1jK8aW_ZUNa52;PmRealVector*mc_P5JplNIcqCGUUHGERc2FQ0;PmRealVector*
mc_L2pUM8dvGVPljS4VQ3PRf1;PmRealVector*mc_g7cvRldaiaL4iKDUsFp8g0;PmRealVector*
mc_aHZqUo9KM138OR7utNP0j_;PmRealVector*mc_GEq_Qcj5d_6GuUbJhYnNm_;PmRealVector*
mc_DXFvjrUImTWD8F7KKxdQi0;PmRealVector*mc_fhOsBJtnUq1szg751hoti1;
mc_o5CREMPu1I_XB5p0nCI6N2*mc_zXmRpzCdrYAmUXc0MbVog0;McLinearAlgebra*
mc_K_h_QGfDP2hmcZVnT725C1;};static boolean_T mc_wKWRlFTz6UJs_k4RJeKa__(
PmRealVector*mc_Wpcib_PQ5jUmXEJjjYC8i0,PmRealVector*mc_Fxkrel85bMLbyUcbl9eM72,
PmRealVector*mc_exQYQjCGWURkEOyPKaL_J1,PmRealVector*mc_4o5uQsgQg3R_U3bLzZ0zZ1,
const PmSparsityPattern*mc_1S82_qZ30MSrHVx9_7J5A2,const PmRealVector*
mc_yS7VvSIKrGg9ddzBqHtUd_,const size_t mc_tb2e_ottQVj6_QEQuXmBD_){size_t
mc_dyH5UX3kEmsd1J1DW7NXh0=mc_Fxkrel85bMLbyUcbl9eM72->mN;size_t
mc_UcQ91Wou1NlJm_M1J1BSo1=mc_exQYQjCGWURkEOyPKaL_J1->mN;int32_T*
mc_S51jjFL079S8kdC86krPC0=mc_1S82_qZ30MSrHVx9_7J5A2->mJc;int32_T*
mc_rX2Nhyrokuq9JmnRvEAkJ1=mc_1S82_qZ30MSrHVx9_7J5A2->mIr;real_T*
mc_A1lUr3Ax9HoRb_bkcLe_A1=mc_4o5uQsgQg3R_U3bLzZ0zZ1->mX;real_T*
mc_Z1yd2EF16p8u3_jQopd5B0=mc_Wpcib_PQ5jUmXEJjjYC8i0->mX;real_T*x=
mc_exQYQjCGWURkEOyPKaL_J1->mX;real_T*mc_VxxeDNxb3XYZvQXh_7Mga_=
mc_Fxkrel85bMLbyUcbl9eM72->mX;real_T mc_hMpAw9m5O_arUCc5GVcld0=pmf_get_eps();
size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T mc_SmSSPSQfR1qEYWsVj5ELF0=0;;;;;;
mc_Rhhlgu4QH_WTKd_5kpe4I2(mc_Wpcib_PQ5jUmXEJjjYC8i0);for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_UcQ91Wou1NlJm_M1J1BSo1;mc_OUB2pptsvtdGL_LyqpgOa0++){for(
mc_SmSSPSQfR1qEYWsVj5ELF0=mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_SmSSPSQfR1qEYWsVj5ELF0<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_Z1yd2EF16p8u3_jQopd5B0[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_SmSSPSQfR1qEYWsVj5ELF0]]+=fabs(
mc_A1lUr3Ax9HoRb_bkcLe_A1[mc_SmSSPSQfR1qEYWsVj5ELF0]*x[
mc_OUB2pptsvtdGL_LyqpgOa0]);}}for(mc_OUB2pptsvtdGL_LyqpgOa0=0;
mc_OUB2pptsvtdGL_LyqpgOa0<mc_dyH5UX3kEmsd1J1DW7NXh0-mc_tb2e_ottQVj6_QEQuXmBD_;
mc_OUB2pptsvtdGL_LyqpgOa0++){const real_T mc_RGllRMvIRPGkpbvuetJlO2=fabs(
mc_VxxeDNxb3XYZvQXh_7Mga_[mc_OUB2pptsvtdGL_LyqpgOa0]);if(!(
mc_RGllRMvIRPGkpbvuetJlO2<=2.0*mc_hMpAw9m5O_arUCc5GVcld0*
mc_Z1yd2EF16p8u3_jQopd5B0[mc_OUB2pptsvtdGL_LyqpgOa0]||
mc_RGllRMvIRPGkpbvuetJlO2<=mc_yS7VvSIKrGg9ddzBqHtUd_->mX[
mc_OUB2pptsvtdGL_LyqpgOa0])){return false;}}return true;}static
mc_vgDUFvn3w7_KCXUA_v_HD2 mc_QraAdRpxxWZtILjkrIzRT0(const
mc_CQR1HxE8a2eRqXwjXW9oa0*mc_zZ_P_KNhZgScqg_YCI2eh1){mc_vgDUFvn3w7_KCXUA_v_HD2
mc_HnGkmbPZHIEvlboSETnfh1;if(mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->
mc_RtdxLSsahYG5F7avud7u42){mc_HnGkmbPZHIEvlboSETnfh1=mc_qG_uWrr8MCsaW7uNtXw040
();}else{PmIntVector mc_sbEgK_R3mXGmJkQIr5fCP1;mc_sbEgK_R3mXGmJkQIr5fCP1 .mN=5
;mc_sbEgK_R3mXGmJkQIr5fCP1 .mX= &(mc_HnGkmbPZHIEvlboSETnfh1 .
mc_sF0SDf2WsaxglnxAqCGtS_[0]);mc_KLKWK_FbEAF724qPNbehq1(&
mc_sbEgK_R3mXGmJkQIr5fCP1,mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->
mc_L2pUM8dvGVPljS4VQ3PRf1,mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->
mc_DXFvjrUImTWD8F7KKxdQi0);}return mc_HnGkmbPZHIEvlboSETnfh1;}static void
mc_75WEQbb3UCVpGCEQ7H7IO_(const mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_zZ_P_KNhZgScqg_YCI2eh1,real_T mc_o2MuMRRx_29b4Ojph5IVQ_){
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->mFactor=mc_o2MuMRRx_29b4Ojph5IVQ_;}
static boolean_T mc_nxajhtFhM_C_oiXcMFEAY1(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
real_T mc_2KXuAphrqc_TLcinUGD4E1,const size_t mc_tb2e_ottQVj6_QEQuXmBD_){
size_t mc_SmSSPSQfR1qEYWsVj5ELF0;size_t n=pm_JMQ_js3toioP0_0hj_fm5_->mN;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n-
mc_tb2e_ottQVj6_QEQuXmBD_;++mc_SmSSPSQfR1qEYWsVj5ELF0){if(!(fabs(
pm_JMQ_js3toioP0_0hj_fm5_->mX[mc_SmSSPSQfR1qEYWsVj5ELF0])<=fabs(
pm__UmJPtGaW9C9junx1RpnH_->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]*
mc_2KXuAphrqc_TLcinUGD4E1))){return false;}}return true;}static real_T
mc_fY3RhhNmEydKPYPxYOGq8_(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,size_t
mc_tb2e_ottQVj6_QEQuXmBD_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*mc__y3ODgPUeYQZuqCAqWV3P2=
pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T mc__ujxrncktQZilZzTUuVF32,
mc_lGrwWW0ERg3PEZB3txbfw2=0.0;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n-mc_tb2e_ottQVj6_QEQuXmBD_;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc__ujxrncktQZilZzTUuVF32=
mc__y3ODgPUeYQZuqCAqWV3P2[mc_SmSSPSQfR1qEYWsVj5ELF0];mc_lGrwWW0ERg3PEZB3txbfw2
+=mc__ujxrncktQZilZzTUuVF32*mc__ujxrncktQZilZzTUuVF32;}
mc_lGrwWW0ERg3PEZB3txbfw2=sqrt(mc_lGrwWW0ERg3PEZB3txbfw2);return
mc_lGrwWW0ERg3PEZB3txbfw2;}static mc_v0sTqkEWafl9TPgVRJyQ40
mc_re5x4PyynEafZmOGEJoWq2(const mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_zZ_P_KNhZgScqg_YCI2eh1,PmRealVector*x){mc_LXMEbVulC3bx7mbvvKMn_2*
mc_bO1pGt5jXN_G54cHLt1xb0=mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData;size_t
mc_dcWK_oZ494lWUUSVfX49q_=mc_bO1pGt5jXN_G54cHLt1xb0->mc_pPFugFO3_1jK8aW_ZUNa52
.mc_bD63qgCe1sC0NmhBmoIGE0;size_t mc_c4Be4xgcKkVHw4vEl4fzN_=
mc_bO1pGt5jXN_G54cHLt1xb0->mc_pPFugFO3_1jK8aW_ZUNa52 .
mc_MgKPEs8hlne8wrqVhAVQF0;size_t mc_tb2e_ottQVj6_QEQuXmBD_=
mc_bO1pGt5jXN_G54cHLt1xb0->mc_pPFugFO3_1jK8aW_ZUNa52 .
mc_Tm8Lbh5KRx56rxKejUV0t0;boolean_T mc_T4nOzZJftws6FFq_tnOs21=
mc_bO1pGt5jXN_G54cHLt1xb0->mc_pPFugFO3_1jK8aW_ZUNa52 .
mc_KSlNGVMeN18j8yZoVHslw2;boolean_T mc_b0T0sQrZQjaoNty2a39Jf_=
mc_bO1pGt5jXN_G54cHLt1xb0->mc_pPFugFO3_1jK8aW_ZUNa52 .
mc_Q2lBsX1utXvk5r7nR1bqw2;real_T mc_hMpAw9m5O_arUCc5GVcld0=pmf_get_eps();
real_T mc_6fRD8_2G5GOCG3w2LKFWS0=0.333;real_T mc_zwFJGHmMbDZwH7UENCceM2=
mc_bO1pGt5jXN_G54cHLt1xb0->mFactor;PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2=
mc_bO1pGt5jXN_G54cHLt1xb0->mc_P5JplNIcqCGUUHGERc2FQ0;PmRealVector*
mc_VxxeDNxb3XYZvQXh_7Mga_=mc_bO1pGt5jXN_G54cHLt1xb0->mc_L2pUM8dvGVPljS4VQ3PRf1
;PmRealVector*mc_I5sCtrSzm8Dm9j06MD6kB2=mc_bO1pGt5jXN_G54cHLt1xb0->
mc_aHZqUo9KM138OR7utNP0j_;PmRealVector*mc_Nzc7nzFCV_KzFqU_qKROZ1=
mc_bO1pGt5jXN_G54cHLt1xb0->mc_GEq_Qcj5d_6GuUbJhYnNm_;PmRealVector*
mc_yS7VvSIKrGg9ddzBqHtUd_=mc_bO1pGt5jXN_G54cHLt1xb0->mc_DXFvjrUImTWD8F7KKxdQi0
;PmRealVector*mc_i0cHRLjyJzv7Gt4ms8kDp2=mc_bO1pGt5jXN_G54cHLt1xb0->
mc_fhOsBJtnUq1szg751hoti1;const mc_6t7LXLIebfQbjqPLIcpqO0*
mc_C2HSAqqbuMxnlpLoODzX50=mc_bO1pGt5jXN_G54cHLt1xb0->mc_cac5Wj3dXfzkBMmMZMucC2
;const PmSparsityPattern*mc_1S82_qZ30MSrHVx9_7J5A2=(mc_C2HSAqqbuMxnlpLoODzX50)
->mc_t_6NUyOFwEImo4lDjZDMu0;size_t mc_mp8c5bQ3LyHKve8drf4AE1=0;size_t
mc_M8Dw_233eaqtnTBOguxrO_=0;size_t mc_Y631oCRvC2OuaVbZ8Klp31=0;real_T
mc_qLvwrmBYcZU88g3YTu0Cu_=0.0;real_T mc_C96fXPl1lECpwXgJ6OzU01=0.0;real_T
mc_Cir6BOu_9GdeGCIPzqONV0=0.0;real_T mc_TpFPYqCSaJMe9WZHHwaao0=0.0;boolean_T
mc_05bls1ABnYCvzrK7_QeRO1=false;boolean_T mc_IR_uZg9xNIe688_9_FDfq1=false;
boolean_T mc_fiHfWMWTGWWo7aqfmpdky2=false;boolean_T mc_W112D6zgmy8Ic_kp1_le90=
false;size_t mc_v4k0LG4l9Qk9hEXlOIKML_=0;size_t mc_weicdJZMAai0j9RbtDP7L2=0;
mc_v0sTqkEWafl9TPgVRJyQ40 mc_G9Ug5Uhj979D3_dBSwlTW0=mc_KhnGFEmutK29G1pFMV7eY2;
boolean_T mc_6a_enE4_fuKZtNrVGpw1n_;;mc_bO1pGt5jXN_G54cHLt1xb0->
mc_RtdxLSsahYG5F7avud7u42=false;pm_rv_equals_rv(mc_ET9_5EAP116KvP5KVqsrD2,x);(
mc_C2HSAqqbuMxnlpLoODzX50)->mc_AyOh1J4sMcEZ5O593pmQ51((
mc_C2HSAqqbuMxnlpLoODzX50),mc_ET9_5EAP116KvP5KVqsrD2,mc_VxxeDNxb3XYZvQXh_7Mga_
);mc_qLvwrmBYcZU88g3YTu0Cu_=mc_fY3RhhNmEydKPYPxYOGq8_(
mc_VxxeDNxb3XYZvQXh_7Mga_,mc_weicdJZMAai0j9RbtDP7L2);(
mc_C2HSAqqbuMxnlpLoODzX50)->mc_O7RdgDn1T_nH7US6HHVQG_((
mc_C2HSAqqbuMxnlpLoODzX50),mc_ET9_5EAP116KvP5KVqsrD2,mc_yS7VvSIKrGg9ddzBqHtUd_
);mc_DnL_y_DaeSoRsDtnK0hpB1(mc_yS7VvSIKrGg9ddzBqHtUd_,
mc_zwFJGHmMbDZwH7UENCceM2);mc_mp8c5bQ3LyHKve8drf4AE1=0;
mc_M8Dw_233eaqtnTBOguxrO_=0;mc_05bls1ABnYCvzrK7_QeRO1=false;while((
mc_mp8c5bQ3LyHKve8drf4AE1<mc_dcWK_oZ494lWUUSVfX49q_)&&(
mc_T4nOzZJftws6FFq_tnOs21||!mc_nxajhtFhM_C_oiXcMFEAY1(
mc_VxxeDNxb3XYZvQXh_7Mga_,mc_yS7VvSIKrGg9ddzBqHtUd_,1.0,
mc_weicdJZMAai0j9RbtDP7L2)||mc_05bls1ABnYCvzrK7_QeRO1)){
mc_mp8c5bQ3LyHKve8drf4AE1++;if(mc_W112D6zgmy8Ic_kp1_le90){
mc_weicdJZMAai0j9RbtDP7L2=mc_tb2e_ottQVj6_QEQuXmBD_;}mc_C96fXPl1lECpwXgJ6OzU01
=mc_qLvwrmBYcZU88g3YTu0Cu_;mc_DnL_y_DaeSoRsDtnK0hpB1(mc_VxxeDNxb3XYZvQXh_7Mga_
,-1.0);(mc_C2HSAqqbuMxnlpLoODzX50)->mc__LRHwDZi5HADTASL9uO6a1((
mc_C2HSAqqbuMxnlpLoODzX50),mc_ET9_5EAP116KvP5KVqsrD2,mc_i0cHRLjyJzv7Gt4ms8kDp2
);mc_v4k0LG4l9Qk9hEXlOIKML_=((((mc_zZ_P_KNhZgScqg_YCI2eh1)->mPrivateData)->
mc_K_h_QGfDP2hmcZVnT725C1))->mFactor((((mc_zZ_P_KNhZgScqg_YCI2eh1)->
mPrivateData)->mc_K_h_QGfDP2hmcZVnT725C1),(mc_i0cHRLjyJzv7Gt4ms8kDp2)->mX);if(
mc_v4k0LG4l9Qk9hEXlOIKML_==MC_LA_OK){mc_v4k0LG4l9Qk9hEXlOIKML_=((((
mc_zZ_P_KNhZgScqg_YCI2eh1)->mPrivateData)->mc_K_h_QGfDP2hmcZVnT725C1))->mSolve
((((mc_zZ_P_KNhZgScqg_YCI2eh1)->mPrivateData)->mc_K_h_QGfDP2hmcZVnT725C1),(
mc_i0cHRLjyJzv7Gt4ms8kDp2)->mX,(mc_Nzc7nzFCV_KzFqU_qKROZ1)->mX,(
mc_VxxeDNxb3XYZvQXh_7Mga_)->mX);}else{mc_M8Dw_233eaqtnTBOguxrO_++;if(
mc_b0T0sQrZQjaoNty2a39Jf_){mc_o5CREMPu1I_XB5p0nCI6N2*mc_6peHhhgu8wo0Kp3HDh_aI0
=mc_bO1pGt5jXN_G54cHLt1xb0->mc_zXmRpzCdrYAmUXc0MbVog0;
mc_v4k0LG4l9Qk9hEXlOIKML_=mc_uvUOg06hpCr7h7LKTqMWz_(mc_i0cHRLjyJzv7Gt4ms8kDp2,
mc_Nzc7nzFCV_KzFqU_qKROZ1,mc_VxxeDNxb3XYZvQXh_7Mga_,mc_6peHhhgu8wo0Kp3HDh_aI0,
mc_1S82_qZ30MSrHVx9_7J5A2);}else{;mc_v4k0LG4l9Qk9hEXlOIKML_=MC_LA_ERROR;}}if(
mc_v4k0LG4l9Qk9hEXlOIKML_!=MC_LA_OK){return mc_s3f6TbPTFsg3OoFmSAmw9_;}
mc_6a_enE4_fuKZtNrVGpw1n_=false;mc_TpFPYqCSaJMe9WZHHwaao0=1.0;for(
mc_Y631oCRvC2OuaVbZ8Klp31=0;mc_Y631oCRvC2OuaVbZ8Klp31<
mc_c4Be4xgcKkVHw4vEl4fzN_;mc_Y631oCRvC2OuaVbZ8Klp31++){boolean_T
mc_lzvkxQtnYsimeIy3456YS0=false;pm_rv_equals_rv(mc_I5sCtrSzm8Dm9j06MD6kB2,
mc_ET9_5EAP116KvP5KVqsrD2);mc_LlLyVwCApgTvSBfIvzOuk0(mc_I5sCtrSzm8Dm9j06MD6kB2
,mc_TpFPYqCSaJMe9WZHHwaao0,mc_Nzc7nzFCV_KzFqU_qKROZ1);if(!
mc_T4nOzZJftws6FFq_tnOs21&&pm___43lXp90F4bzSkAXqYfT1(mc_I5sCtrSzm8Dm9j06MD6kB2
,mc_ET9_5EAP116KvP5KVqsrD2)){mc_LlLyVwCApgTvSBfIvzOuk0(
mc_I5sCtrSzm8Dm9j06MD6kB2,1.0,mc_Nzc7nzFCV_KzFqU_qKROZ1);
mc_lzvkxQtnYsimeIy3456YS0=true;}(mc_C2HSAqqbuMxnlpLoODzX50)->
mc_AyOh1J4sMcEZ5O593pmQ51((mc_C2HSAqqbuMxnlpLoODzX50),
mc_I5sCtrSzm8Dm9j06MD6kB2,mc_VxxeDNxb3XYZvQXh_7Mga_);mc_Cir6BOu_9GdeGCIPzqONV0
=mc_fY3RhhNmEydKPYPxYOGq8_(mc_VxxeDNxb3XYZvQXh_7Mga_,mc_weicdJZMAai0j9RbtDP7L2
);if(mc_Cir6BOu_9GdeGCIPzqONV0<mc_qLvwrmBYcZU88g3YTu0Cu_||
mc_lzvkxQtnYsimeIy3456YS0){mc_6a_enE4_fuKZtNrVGpw1n_=true;break;}
mc_TpFPYqCSaJMe9WZHHwaao0/=2.0;}if(!mc_6a_enE4_fuKZtNrVGpw1n_&&
mc_tb2e_ottQVj6_QEQuXmBD_>0){mc_W112D6zgmy8Ic_kp1_le90=true;}pm_rv_equals_rv(
mc_ET9_5EAP116KvP5KVqsrD2,mc_I5sCtrSzm8Dm9j06MD6kB2);mc_qLvwrmBYcZU88g3YTu0Cu_
=mc_Cir6BOu_9GdeGCIPzqONV0;(mc_C2HSAqqbuMxnlpLoODzX50)->
mc_O7RdgDn1T_nH7US6HHVQG_((mc_C2HSAqqbuMxnlpLoODzX50),
mc_ET9_5EAP116KvP5KVqsrD2,mc_yS7VvSIKrGg9ddzBqHtUd_);mc_DnL_y_DaeSoRsDtnK0hpB1
(mc_yS7VvSIKrGg9ddzBqHtUd_,mc_zwFJGHmMbDZwH7UENCceM2);
mc_05bls1ABnYCvzrK7_QeRO1=((mc_qLvwrmBYcZU88g3YTu0Cu_<
mc_6fRD8_2G5GOCG3w2LKFWS0*mc_C96fXPl1lECpwXgJ6OzU01)&&(!
mc_nxajhtFhM_C_oiXcMFEAY1(mc_VxxeDNxb3XYZvQXh_7Mga_,mc_yS7VvSIKrGg9ddzBqHtUd_,
mc_hMpAw9m5O_arUCc5GVcld0,mc_weicdJZMAai0j9RbtDP7L2)));}pm_rv_equals_rv(x,
mc_ET9_5EAP116KvP5KVqsrD2);if(mc_T4nOzZJftws6FFq_tnOs21){
mc_IR_uZg9xNIe688_9_FDfq1=true;}else if(mc_nxajhtFhM_C_oiXcMFEAY1(
mc_VxxeDNxb3XYZvQXh_7Mga_,mc_yS7VvSIKrGg9ddzBqHtUd_,1.0,
mc_weicdJZMAai0j9RbtDP7L2)){mc_IR_uZg9xNIe688_9_FDfq1=true;}else{
mc_IR_uZg9xNIe688_9_FDfq1=mc_wKWRlFTz6UJs_k4RJeKa__(mc_bO1pGt5jXN_G54cHLt1xb0
->mc_g7cvRldaiaL4iKDUsFp8g0,mc_VxxeDNxb3XYZvQXh_7Mga_,
mc_ET9_5EAP116KvP5KVqsrD2,mc_i0cHRLjyJzv7Gt4ms8kDp2,mc_1S82_qZ30MSrHVx9_7J5A2,
mc_yS7VvSIKrGg9ddzBqHtUd_,mc_weicdJZMAai0j9RbtDP7L2);}if(
mc_IR_uZg9xNIe688_9_FDfq1){mc_bO1pGt5jXN_G54cHLt1xb0->
mc_RtdxLSsahYG5F7avud7u42=true;return mc_DKQ2NLbquneq0lUPeY6980;}else{
mc_fiHfWMWTGWWo7aqfmpdky2=((mc_mp8c5bQ3LyHKve8drf4AE1>2)&&(
mc_M8Dw_233eaqtnTBOguxrO_*2>=mc_mp8c5bQ3LyHKve8drf4AE1));return
mc_fiHfWMWTGWWo7aqfmpdky2?mc_s3f6TbPTFsg3OoFmSAmw9_:mc_UVVwEZg9VhYkMacmned87_;
}}static void mc_SCxuXaiSH9IckDIKF5xOY1(mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_zZ_P_KNhZgScqg_YCI2eh1){PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2=
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->mc_pPFugFO3_1jK8aW_ZUNa52 .
mc_EJyLFJLNS54LEp1_ia1250;McLinearAlgebra*mc_NjoG9RyBiu99KiUq28_eO0=
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->mc_K_h_QGfDP2hmcZVnT725C1;
pm_destroy_real_vector(mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->
mc_P5JplNIcqCGUUHGERc2FQ0,pm_an0wiQTjdlKE72zC6FJ0a2);pm_destroy_real_vector(
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->mc_L2pUM8dvGVPljS4VQ3PRf1,
pm_an0wiQTjdlKE72zC6FJ0a2);pm_destroy_real_vector(mc_zZ_P_KNhZgScqg_YCI2eh1->
mPrivateData->mc_g7cvRldaiaL4iKDUsFp8g0,pm_an0wiQTjdlKE72zC6FJ0a2);
pm_destroy_real_vector(mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->
mc_aHZqUo9KM138OR7utNP0j_,pm_an0wiQTjdlKE72zC6FJ0a2);pm_destroy_real_vector(
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->mc_GEq_Qcj5d_6GuUbJhYnNm_,
pm_an0wiQTjdlKE72zC6FJ0a2);pm_destroy_real_vector(mc_zZ_P_KNhZgScqg_YCI2eh1->
mPrivateData->mc_DXFvjrUImTWD8F7KKxdQi0,pm_an0wiQTjdlKE72zC6FJ0a2);
pm_destroy_real_vector(mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->
mc_fhOsBJtnUq1szg751hoti1,pm_an0wiQTjdlKE72zC6FJ0a2);if(
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData->mc_pPFugFO3_1jK8aW_ZUNa52 .
mc_Q2lBsX1utXvk5r7nR1bqw2){mc_7_R4McQBwppLSGlfrN9ts1(mc_zZ_P_KNhZgScqg_YCI2eh1
->mPrivateData->mc_zXmRpzCdrYAmUXc0MbVog0);}else{;}mc_NjoG9RyBiu99KiUq28_eO0->
mDestructor(mc_NjoG9RyBiu99KiUq28_eO0);{void*mc_GAbHnJspJ6sMhe_Yzxehb_=(
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData);if(mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
mc_GAbHnJspJ6sMhe_Yzxehb_);}};{void*mc_GAbHnJspJ6sMhe_Yzxehb_=(
mc_zZ_P_KNhZgScqg_YCI2eh1);if(mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
mc_GAbHnJspJ6sMhe_Yzxehb_);}};}static mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_cc_9SAQfCMmIxia2T8a7x_(const mc_PLlF_m_QtaI7_tt0PCGyf1*
mc___8zuxSRixcOGs7OSRauz0,const mc_6t7LXLIebfQbjqPLIcpqO0*
mc_3ltTS3NyKrV_SajZwK4s8_){PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2=
mc___8zuxSRixcOGs7OSRauz0->mPrivateData->mc_EJyLFJLNS54LEp1_ia1250;const
McLinearAlgebraFactory*mc_oPrIRBSsQqsl2WetjeIFY0=mc___8zuxSRixcOGs7OSRauz0->
mPrivateData->mc_szjdoJ0Befv4Eq4qdPTaZ0;mc_CQR1HxE8a2eRqXwjXW9oa0*
mc_zZ_P_KNhZgScqg_YCI2eh1=(mc_CQR1HxE8a2eRqXwjXW9oa0*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
mc_CQR1HxE8a2eRqXwjXW9oa0)),(1)));mc_LXMEbVulC3bx7mbvvKMn_2*
mc_bO1pGt5jXN_G54cHLt1xb0=(mc_LXMEbVulC3bx7mbvvKMn_2*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
mc_LXMEbVulC3bx7mbvvKMn_2)),(1)));const PmSparsityPattern*
mc_1S82_qZ30MSrHVx9_7J5A2=mc_3ltTS3NyKrV_SajZwK4s8_->mc_t_6NUyOFwEImo4lDjZDMu0
;size_t mc_odQHgwHw3o3kcuFzAW3OG_=mc_1S82_qZ30MSrHVx9_7J5A2->mNumRow;size_t
mc_3mGbZP8hvaFvBVpyEQx6g0=mc_1S82_qZ30MSrHVx9_7J5A2->mNumCol;size_t
mc_uBAZerCtXYgbB6zhWK5BV1=((size_t)(mc_1S82_qZ30MSrHVx9_7J5A2)->mJc[(
mc_1S82_qZ30MSrHVx9_7J5A2)->mNumCol]);int32_T mc_v4k0LG4l9Qk9hEXlOIKML_=0;
mc_bO1pGt5jXN_G54cHLt1xb0->mc_cac5Wj3dXfzkBMmMZMucC2=mc_3ltTS3NyKrV_SajZwK4s8_
;mc_bO1pGt5jXN_G54cHLt1xb0->mc_RtdxLSsahYG5F7avud7u42=true;
mc_bO1pGt5jXN_G54cHLt1xb0->mc_pPFugFO3_1jK8aW_ZUNa52= *(
mc___8zuxSRixcOGs7OSRauz0->mPrivateData);mc_bO1pGt5jXN_G54cHLt1xb0->mFactor=
1.0;mc_bO1pGt5jXN_G54cHLt1xb0->mc_P5JplNIcqCGUUHGERc2FQ0=pm_create_real_vector
(mc_3mGbZP8hvaFvBVpyEQx6g0,pm_an0wiQTjdlKE72zC6FJ0a2);
mc_bO1pGt5jXN_G54cHLt1xb0->mc_L2pUM8dvGVPljS4VQ3PRf1=pm_create_real_vector(
mc_odQHgwHw3o3kcuFzAW3OG_,pm_an0wiQTjdlKE72zC6FJ0a2);mc_bO1pGt5jXN_G54cHLt1xb0
->mc_g7cvRldaiaL4iKDUsFp8g0=pm_create_real_vector(mc_odQHgwHw3o3kcuFzAW3OG_,
pm_an0wiQTjdlKE72zC6FJ0a2);mc_bO1pGt5jXN_G54cHLt1xb0->
mc_aHZqUo9KM138OR7utNP0j_=pm_create_real_vector(mc_3mGbZP8hvaFvBVpyEQx6g0,
pm_an0wiQTjdlKE72zC6FJ0a2);mc_bO1pGt5jXN_G54cHLt1xb0->
mc_GEq_Qcj5d_6GuUbJhYnNm_=pm_create_real_vector(mc_3mGbZP8hvaFvBVpyEQx6g0,
pm_an0wiQTjdlKE72zC6FJ0a2);mc_bO1pGt5jXN_G54cHLt1xb0->
mc_DXFvjrUImTWD8F7KKxdQi0=pm_create_real_vector(mc_odQHgwHw3o3kcuFzAW3OG_,
pm_an0wiQTjdlKE72zC6FJ0a2);mc_bO1pGt5jXN_G54cHLt1xb0->
mc_fhOsBJtnUq1szg751hoti1=pm_create_real_vector(mc_uBAZerCtXYgbB6zhWK5BV1,
pm_an0wiQTjdlKE72zC6FJ0a2);if(mc_bO1pGt5jXN_G54cHLt1xb0->
mc_pPFugFO3_1jK8aW_ZUNa52 .mc_Q2lBsX1utXvk5r7nR1bqw2){
mc_bO1pGt5jXN_G54cHLt1xb0->mc_zXmRpzCdrYAmUXc0MbVog0=mc_LEkjn0HScoulloiZuU3yi_
(mc_1S82_qZ30MSrHVx9_7J5A2,mc_oPrIRBSsQqsl2WetjeIFY0,pm_an0wiQTjdlKE72zC6FJ0a2
);}else{mc_bO1pGt5jXN_G54cHLt1xb0->mc_zXmRpzCdrYAmUXc0MbVog0=NULL;}
mc_v4k0LG4l9Qk9hEXlOIKML_=mc_oPrIRBSsQqsl2WetjeIFY0->mCreateLinearAlgebra(
mc_oPrIRBSsQqsl2WetjeIFY0,&(mc_bO1pGt5jXN_G54cHLt1xb0->
mc_K_h_QGfDP2hmcZVnT725C1),mc_1S82_qZ30MSrHVx9_7J5A2);;
mc_zZ_P_KNhZgScqg_YCI2eh1->mPrivateData=mc_bO1pGt5jXN_G54cHLt1xb0;
mc_zZ_P_KNhZgScqg_YCI2eh1->mSolve= &mc_re5x4PyynEafZmOGEJoWq2;
mc_zZ_P_KNhZgScqg_YCI2eh1->mc_eYEHzsIN8nqYyqsuP8dFP_= &
mc_QraAdRpxxWZtILjkrIzRT0;mc_zZ_P_KNhZgScqg_YCI2eh1->mc_e4AXYFnkWU5C0XgM4b44f0
= &mc_75WEQbb3UCVpGCEQ7H7IO_;mc_zZ_P_KNhZgScqg_YCI2eh1->
mc_YCFci8IAJkK9w_xpRtHta2= &mc_SCxuXaiSH9IckDIKF5xOY1;return
mc_zZ_P_KNhZgScqg_YCI2eh1;}static void mc_Yt64RZeovLHtsFCLpqdmD2(
mc_PLlF_m_QtaI7_tt0PCGyf1*mc___8zuxSRixcOGs7OSRauz0){PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2=mc___8zuxSRixcOGs7OSRauz0->mPrivateData->
mc_EJyLFJLNS54LEp1_ia1250;{void*mc_GAbHnJspJ6sMhe_Yzxehb_=(
mc___8zuxSRixcOGs7OSRauz0->mPrivateData);if(mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
mc_GAbHnJspJ6sMhe_Yzxehb_);}};{void*mc_GAbHnJspJ6sMhe_Yzxehb_=(
mc___8zuxSRixcOGs7OSRauz0);if(mc_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
mc_GAbHnJspJ6sMhe_Yzxehb_);}};}static mc_PLlF_m_QtaI7_tt0PCGyf1*
mc_AcRlRnPKeapXh5CAuxDPM0(PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2,const
McLinearAlgebraFactory*mc_fEMEImnNQqYTsF_hhnViM_,size_t
mc_dcWK_oZ494lWUUSVfX49q_,size_t mc_c4Be4xgcKkVHw4vEl4fzN_,size_t
mc_tb2e_ottQVj6_QEQuXmBD_,boolean_T mc_T4nOzZJftws6FFq_tnOs21,boolean_T
mc_b0T0sQrZQjaoNty2a39Jf_){mc_PLlF_m_QtaI7_tt0PCGyf1*mc___8zuxSRixcOGs7OSRauz0
=(mc_PLlF_m_QtaI7_tt0PCGyf1*)((pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((
pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(mc_PLlF_m_QtaI7_tt0PCGyf1)),(1)));
mc_htIw_3pJsSdIb219YsmvC2*mc_NcGhle8155Oz0fSQigUQ70=(mc_htIw_3pJsSdIb219YsmvC2
*)((pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof
(mc_htIw_3pJsSdIb219YsmvC2)),(1)));mc_NcGhle8155Oz0fSQigUQ70->
mc_EJyLFJLNS54LEp1_ia1250=pm_an0wiQTjdlKE72zC6FJ0a2;mc_NcGhle8155Oz0fSQigUQ70
->mc_szjdoJ0Befv4Eq4qdPTaZ0=mc_fEMEImnNQqYTsF_hhnViM_;
mc_NcGhle8155Oz0fSQigUQ70->mc_bD63qgCe1sC0NmhBmoIGE0=mc_dcWK_oZ494lWUUSVfX49q_
;mc_NcGhle8155Oz0fSQigUQ70->mc_MgKPEs8hlne8wrqVhAVQF0=
mc_c4Be4xgcKkVHw4vEl4fzN_;mc_NcGhle8155Oz0fSQigUQ70->mc_Tm8Lbh5KRx56rxKejUV0t0
=mc_tb2e_ottQVj6_QEQuXmBD_;mc_NcGhle8155Oz0fSQigUQ70->
mc_KSlNGVMeN18j8yZoVHslw2=mc_T4nOzZJftws6FFq_tnOs21;mc_NcGhle8155Oz0fSQigUQ70
->mc_Q2lBsX1utXvk5r7nR1bqw2=mc_b0T0sQrZQjaoNty2a39Jf_;
mc___8zuxSRixcOGs7OSRauz0->mPrivateData=mc_NcGhle8155Oz0fSQigUQ70;
mc___8zuxSRixcOGs7OSRauz0->mc_kGZn4ZI8B8YZuZHR8f_Ge_= &
mc_cc_9SAQfCMmIxia2T8a7x_;mc___8zuxSRixcOGs7OSRauz0->mc_YCFci8IAJkK9w_xpRtHta2
= &mc_Yt64RZeovLHtsFCLpqdmD2;return mc___8zuxSRixcOGs7OSRauz0;}
mc_PLlF_m_QtaI7_tt0PCGyf1*mc_unUcHqjWIYGRq_Mtqq_Nn2(PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2,const McLinearAlgebraFactory*
mc_fEMEImnNQqYTsF_hhnViM_,size_t mc_dcWK_oZ494lWUUSVfX49q_,size_t
mc_c4Be4xgcKkVHw4vEl4fzN_,boolean_T mc_T4nOzZJftws6FFq_tnOs21,boolean_T
mc_b0T0sQrZQjaoNty2a39Jf_){return mc_AcRlRnPKeapXh5CAuxDPM0(
pm_an0wiQTjdlKE72zC6FJ0a2,mc_fEMEImnNQqYTsF_hhnViM_,mc_dcWK_oZ494lWUUSVfX49q_,
mc_c4Be4xgcKkVHw4vEl4fzN_,0,mc_T4nOzZJftws6FFq_tnOs21,
mc_b0T0sQrZQjaoNty2a39Jf_);}mc_PLlF_m_QtaI7_tt0PCGyf1*
mc_H4E5qy2gElz_ZzQWqCBUr1(PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2,const
McLinearAlgebraFactory*mc_fEMEImnNQqYTsF_hhnViM_,size_t
mc_dcWK_oZ494lWUUSVfX49q_,size_t mc_c4Be4xgcKkVHw4vEl4fzN_,size_t
mc_tb2e_ottQVj6_QEQuXmBD_,boolean_T mc_T4nOzZJftws6FFq_tnOs21,boolean_T
mc_b0T0sQrZQjaoNty2a39Jf_){return mc_AcRlRnPKeapXh5CAuxDPM0(
pm_an0wiQTjdlKE72zC6FJ0a2,mc_fEMEImnNQqYTsF_hhnViM_,mc_dcWK_oZ494lWUUSVfX49q_,
mc_c4Be4xgcKkVHw4vEl4fzN_,mc_tb2e_ottQVj6_QEQuXmBD_,mc_T4nOzZJftws6FFq_tnOs21,
mc_b0T0sQrZQjaoNty2a39Jf_);}
