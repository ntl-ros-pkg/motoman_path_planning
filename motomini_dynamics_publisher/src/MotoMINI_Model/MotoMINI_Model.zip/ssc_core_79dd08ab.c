#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_core_KNcJ1jU8piEi_2g0Ydzzo2 ssc_core_L4FImzp6iu_cikM_QSiOq1
;typedef struct ssc_core_mxYVgQYwCLIPwD6arnF2g0 ssc_core_5Z1inCkB2uIKKdlyf3XlZ0
;typedef enum{ssc_core_PQvF_V2l5jTui_cnayCtx1= -1,
ssc_core_A054j0gk4AqU55YWXLdcE_,ssc_core_Pb8JUwx4ywPtUw65I_hnN2,
ssc_core_Nrc9kYdGOx7oW_IqsZeAq2}ssc_core_5lRuVpDVc6bG2IVKfGVqN_;typedef struct
ssc_core_h3W2Es5Dd5ECkBBGihhpy2 ssc_core_jEm68s33g57Of0sNBmgop_;typedef struct
ssc_core_FPoEjIXZi6eDu_NJnUUwA0 ssc_core_BNjWAgMJ0Mukk_YOIqL5n1;struct
ssc_core_h3W2Es5Dd5ECkBBGihhpy2{ssc_core_BNjWAgMJ0Mukk_YOIqL5n1*mPrivateData;
void(*mc_2FQxl16aJPaXJJesMoqWt0)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0,ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_k_j2lx8W_dda_yvKS1xp7_);ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_wsXdF7Y4tIGroeVw6EQeX2)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0);ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_p6I2CZ7dMpbzsp9WeGsko_)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0);ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_xK_kmwIp2VMJ2wdR_CPlX2)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0,size_t n);size_t(*
ssc_core_jSsiqJwfr5ffaYw4Jon_M_)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
ssc_core_jEm68s33g57Of0sNBmgop_*ssc_core_hPvEE3EAaw3i03g01xCqv0);};
ssc_core_jEm68s33g57Of0sNBmgop_*ssc_core_JslMZiKqcnP95ggOb5exk_(PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500);typedef struct ssc_core_vZn6DF0v4twzJzPoZZxAN1
ssc_core_thywJp0pHreQZmXHmPALL2;struct ssc_core_KNcJ1jU8piEi_2g0Ydzzo2{
ssc_core_thywJp0pHreQZmXHmPALL2*mPrivateData;char*
ssc_core_TpRDfFOYgAbyLf0KZnAeG0;char*ssc_core_a6tD5dlh1DmNbWq8kK6AD2;
ssc_core_5lRuVpDVc6bG2IVKfGVqN_ ssc_core_2fxBRyuKb7j22KyPfO_fh0;
ssc_core_jEm68s33g57Of0sNBmgop_*ssc_core_4aqSVtwD8PrSeUW_zGPiS0;void(*
mc_YCFci8IAJkK9w_xpRtHta2)(ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_k_j2lx8W_dda_yvKS1xp7_);};ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_Lo4EESuguNsJuDmGHU97O1(PmAllocator*mc_YMfc_eB3rHMVJUig1uu500);struct
ssc_core_vZn6DF0v4twzJzPoZZxAN1{PmAllocator*ssc_core__4I9iHUhzuzbTikLaqzp02;};
static void ssc_core_PdMRqfl3VqCY_HXRXqg_V2(ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_k_j2lx8W_dda_yvKS1xp7_){ssc_core_thywJp0pHreQZmXHmPALL2*
mc_6peHhhgu8wo0Kp3HDh_aI0=ssc_core_k_j2lx8W_dda_yvKS1xp7_->mPrivateData;
PmAllocator*mc_YMfc_eB3rHMVJUig1uu500=mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core__4I9iHUhzuzbTikLaqzp02;{void*ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(
mc_6peHhhgu8wo0Kp3HDh_aI0);if(ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(
mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(mc_YMfc_eB3rHMVJUig1uu500,
ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};{void*ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(
ssc_core_k_j2lx8W_dda_yvKS1xp7_->ssc_core_TpRDfFOYgAbyLf0KZnAeG0);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};{void*
ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_a6tD5dlh1DmNbWq8kK6AD2);if(ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(
mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(mc_YMfc_eB3rHMVJUig1uu500,
ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};if(ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_4aqSVtwD8PrSeUW_zGPiS0!=NULL){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;
size_t n=(ssc_core_k_j2lx8W_dda_yvKS1xp7_->ssc_core_4aqSVtwD8PrSeUW_zGPiS0)->
ssc_core_jSsiqJwfr5ffaYw4Jon_M_((ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_4aqSVtwD8PrSeUW_zGPiS0));for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){((
ssc_core_k_j2lx8W_dda_yvKS1xp7_->ssc_core_4aqSVtwD8PrSeUW_zGPiS0)->
ssc_core_xK_kmwIp2VMJ2wdR_CPlX2((ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_4aqSVtwD8PrSeUW_zGPiS0),(mc_SmSSPSQfR1qEYWsVj5ELF0)))->
mc_YCFci8IAJkK9w_xpRtHta2(((ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_4aqSVtwD8PrSeUW_zGPiS0)->ssc_core_xK_kmwIp2VMJ2wdR_CPlX2((
ssc_core_k_j2lx8W_dda_yvKS1xp7_->ssc_core_4aqSVtwD8PrSeUW_zGPiS0),(
mc_SmSSPSQfR1qEYWsVj5ELF0))));}(ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_4aqSVtwD8PrSeUW_zGPiS0)->mc_YCFci8IAJkK9w_xpRtHta2((
ssc_core_k_j2lx8W_dda_yvKS1xp7_->ssc_core_4aqSVtwD8PrSeUW_zGPiS0));}{void*
ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(ssc_core_k_j2lx8W_dda_yvKS1xp7_);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};}
ssc_core_L4FImzp6iu_cikM_QSiOq1*ssc_core_Lo4EESuguNsJuDmGHU97O1(PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500){ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_k_j2lx8W_dda_yvKS1xp7_=(ssc_core_L4FImzp6iu_cikM_QSiOq1*)((
mc_YMfc_eB3rHMVJUig1uu500)->mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(
ssc_core_L4FImzp6iu_cikM_QSiOq1)),(1)));ssc_core_thywJp0pHreQZmXHmPALL2*
mc_6peHhhgu8wo0Kp3HDh_aI0=(ssc_core_thywJp0pHreQZmXHmPALL2*)((
mc_YMfc_eB3rHMVJUig1uu500)->mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(
ssc_core_thywJp0pHreQZmXHmPALL2)),(1)));mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core__4I9iHUhzuzbTikLaqzp02=mc_YMfc_eB3rHMVJUig1uu500;
ssc_core_k_j2lx8W_dda_yvKS1xp7_->ssc_core_2fxBRyuKb7j22KyPfO_fh0=
ssc_core_A054j0gk4AqU55YWXLdcE_;ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_TpRDfFOYgAbyLf0KZnAeG0=NULL;ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_a6tD5dlh1DmNbWq8kK6AD2=NULL;ssc_core_k_j2lx8W_dda_yvKS1xp7_->
ssc_core_4aqSVtwD8PrSeUW_zGPiS0=ssc_core_JslMZiKqcnP95ggOb5exk_(
mc_YMfc_eB3rHMVJUig1uu500);ssc_core_k_j2lx8W_dda_yvKS1xp7_->mPrivateData=
mc_6peHhhgu8wo0Kp3HDh_aI0;ssc_core_k_j2lx8W_dda_yvKS1xp7_->
mc_YCFci8IAJkK9w_xpRtHta2= &ssc_core_PdMRqfl3VqCY_HXRXqg_V2;return
ssc_core_k_j2lx8W_dda_yvKS1xp7_;}
