#include "pm_std.h"
void pm_math_XJzegwSdpmUltXdthe53i1(const real_T*
pm_math_Ko2UL7FliD3gp_gb0mLQz1,const real_T*b,uint32_T n,boolean_T
pm_math_sVKngqkZdQ1F7IUv4STVE0,real_T*x);void pm_math_fZf7B2a2XHIWuXJVD2nsr_(
const real_T*pm_math_ks8rkpJYX5jHaEJjD6Z6h1,const real_T*b,uint32_T n,
boolean_T pm_math_sVKngqkZdQ1F7IUv4STVE0,real_T*x);void
pm_math_XJzegwSdpmUltXdthe53i1(const real_T*pm_math_Ko2UL7FliD3gp_gb0mLQz1,
const real_T*b,uint32_T n,boolean_T pm_math_sVKngqkZdQ1F7IUv4STVE0,real_T*x){
uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;x-=
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_SmSSPSQfR1qEYWsVj5ELF0++){real_T
pm_math_hCXUd_x6pbKZfXtyKXEw82=0.0;const real_T*pm_math_PMoj19AtRoOJbEKuPG4PB0
=pm_math_Ko2UL7FliD3gp_gb0mLQz1++;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=0;
pm_math_OUB2pptsvtdGL_LyqpgOa0<pm_math_SmSSPSQfR1qEYWsVj5ELF0;++
pm_math_OUB2pptsvtdGL_LyqpgOa0,pm_math_PMoj19AtRoOJbEKuPG4PB0+=n)
pm_math_hCXUd_x6pbKZfXtyKXEw82+= *pm_math_PMoj19AtRoOJbEKuPG4PB0**x++;*x=
pm_math_sVKngqkZdQ1F7IUv4STVE0?(*b++-pm_math_hCXUd_x6pbKZfXtyKXEw82):((*b++-
pm_math_hCXUd_x6pbKZfXtyKXEw82)/ *pm_math_PMoj19AtRoOJbEKuPG4PB0);}}void
pm_math_fZf7B2a2XHIWuXJVD2nsr_(const real_T*pm_math_ks8rkpJYX5jHaEJjD6Z6h1,
const real_T*b,uint32_T n,boolean_T pm_math_sVKngqkZdQ1F7IUv4STVE0,real_T*x){
uint32_T pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_OUB2pptsvtdGL_LyqpgOa0;
pm_math_ks8rkpJYX5jHaEJjD6Z6h1+=n*n;b+=n-1;x+=n-1;for(
pm_math_SmSSPSQfR1qEYWsVj5ELF0=0;pm_math_SmSSPSQfR1qEYWsVj5ELF0<n;x+=
pm_math_SmSSPSQfR1qEYWsVj5ELF0,pm_math_SmSSPSQfR1qEYWsVj5ELF0++){real_T
pm_math_hCXUd_x6pbKZfXtyKXEw82=0.0;const real_T*pm_math_PMoj19AtRoOJbEKuPG4PB0
= --pm_math_ks8rkpJYX5jHaEJjD6Z6h1;for(pm_math_OUB2pptsvtdGL_LyqpgOa0=
pm_math_SmSSPSQfR1qEYWsVj5ELF0;pm_math_OUB2pptsvtdGL_LyqpgOa0>0;
pm_math_PMoj19AtRoOJbEKuPG4PB0-=n,--pm_math_OUB2pptsvtdGL_LyqpgOa0)
pm_math_hCXUd_x6pbKZfXtyKXEw82+= *pm_math_PMoj19AtRoOJbEKuPG4PB0**x--;*x=
pm_math_sVKngqkZdQ1F7IUv4STVE0?(*b-- -pm_math_hCXUd_x6pbKZfXtyKXEw82):((*b-- -
pm_math_hCXUd_x6pbKZfXtyKXEw82)/ *pm_math_PMoj19AtRoOJbEKuPG4PB0);}}
