#include "pm_std.h"
#include "pm_std.h"
typedef struct pm_Td1oIRTmhV_BqExjdeZqh_{size_t mNumRow;size_t mNumCol;real_T*
mX;}pm_xELwgkvowKyM9polnZA8_2;pm_xELwgkvowKyM9polnZA8_2*
pm_nz2UGYq4cnG1apCgKensi1(size_t pm_VJaXi2SoIcIed2aDCbUEF2,size_t
pm_Hje8CN1dduWhywTP07JA01,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);
pm_xELwgkvowKyM9polnZA8_2*pm_kXYSn24Zby7CBHFJTWVAL_(const
pm_xELwgkvowKyM9polnZA8_2*pm_B0LNpsKPbGgqFDFZWKsdG_,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2);void pm_7qv2N86L_Nx58YfedYAKB2(
pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2);void pm_uHZzpO3dV_gBTCFm801lW0(const
pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2);size_t
pm_MGbAo0b_Pvg7QU4YyM3B02(const pm_xELwgkvowKyM9polnZA8_2*
pm_KOiiP_gqHP9q_8e9O2OJi2);PMF_DEPLOY_STATIC real_T pm_zPBzfnkV4L7Gc0z3cPC_j0(
const pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2,size_t
pm_MUnOgYpKkviTC4TqWArmj2,size_t pm_wOc1JAYSv_gXX9xk1sd2n0){return
pm_KOiiP_gqHP9q_8e9O2OJi2->mX[pm_MUnOgYpKkviTC4TqWArmj2+
pm_wOc1JAYSv_gXX9xk1sd2n0*pm_KOiiP_gqHP9q_8e9O2OJi2->mNumRow];}
PMF_DEPLOY_STATIC void pm_YLO8EeU47vBVt0OpuLKTD0(const
pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2,size_t
pm_MUnOgYpKkviTC4TqWArmj2,size_t pm_wOc1JAYSv_gXX9xk1sd2n0,real_T
pm_rtvAiaZQgzgWqstgEIdKX1){pm_KOiiP_gqHP9q_8e9O2OJi2->mX[
pm_MUnOgYpKkviTC4TqWArmj2+pm_wOc1JAYSv_gXX9xk1sd2n0*pm_KOiiP_gqHP9q_8e9O2OJi2
->mNumRow]=pm_rtvAiaZQgzgWqstgEIdKX1;}void pm_SMY9vTgq0jMJs5_4peCEb2(const
pm_xELwgkvowKyM9polnZA8_2*pm_sZbJqnvRDJHN0b0Lebp6y0,const PmRealVector*
pm_VXW2_bOrRwbT0N4pO6g580,const PmSparsityPattern*pm_EphGIaq4DHWXGRbDOrH9x_);
void pm_4Z81QuXMmjeQwuPgWZ5tk2(const pm_xELwgkvowKyM9polnZA8_2*
pm_sZbJqnvRDJHN0b0Lebp6y0,const PmBoolVector*pm_gq3kPpO4Hdv_0UBmX5sfB1);void
pm_RBkGG4mV2eXeUxWqZrZ_D0(const pm_xELwgkvowKyM9polnZA8_2*dst,const
pm_xELwgkvowKyM9polnZA8_2*src);boolean_T pm_Ct3OT7r9ARKw_pJqHPLDS2(const
pm_xELwgkvowKyM9polnZA8_2*dst,const pm_xELwgkvowKyM9polnZA8_2*src);boolean_T
pm_sYk4ZLEaO8wF7NdpQZXqg_(const pm_xELwgkvowKyM9polnZA8_2*dst,size_t
pm_zBgtBOGV5868yvaq9VmVW_,const pm_xELwgkvowKyM9polnZA8_2*src,size_t
pm_ylfAzmjIY4rqTc8S_UplF2,size_t pm___oCzuVa6AMVNXQEKlS5G1);void
pm_FcuhGEI4_hbnVFe3jdkcL2(const pm_xELwgkvowKyM9polnZA8_2*dst,size_t
pm_zBgtBOGV5868yvaq9VmVW_,const pm_xELwgkvowKyM9polnZA8_2*src,size_t
pm_ylfAzmjIY4rqTc8S_UplF2,size_t pm___oCzuVa6AMVNXQEKlS5G1);
#include "pm_std.h"
#include "string.h"
pm_xELwgkvowKyM9polnZA8_2*pm_nz2UGYq4cnG1apCgKensi1(size_t
pm_VJaXi2SoIcIed2aDCbUEF2,size_t pm_Hje8CN1dduWhywTP07JA01,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2){pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2
=(pm_xELwgkvowKyM9polnZA8_2*)((pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((
pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(pm_xELwgkvowKyM9polnZA8_2)),(1)));
pm_KOiiP_gqHP9q_8e9O2OJi2->mNumRow=pm_VJaXi2SoIcIed2aDCbUEF2;
pm_KOiiP_gqHP9q_8e9O2OJi2->mNumCol=pm_Hje8CN1dduWhywTP07JA01;
pm_KOiiP_gqHP9q_8e9O2OJi2->mX=((pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((
pm_an0wiQTjdlKE72zC6FJ0a2),(pm_VJaXi2SoIcIed2aDCbUEF2*
pm_Hje8CN1dduWhywTP07JA01),(sizeof(real_T))));return pm_KOiiP_gqHP9q_8e9O2OJi2
;}pm_xELwgkvowKyM9polnZA8_2*pm_kXYSn24Zby7CBHFJTWVAL_(const
pm_xELwgkvowKyM9polnZA8_2*pm_B0LNpsKPbGgqFDFZWKsdG_,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2){pm_xELwgkvowKyM9polnZA8_2*pm_cPpFNNxfnE9grx4hesF5K_
=pm_nz2UGYq4cnG1apCgKensi1(pm_B0LNpsKPbGgqFDFZWKsdG_->mNumRow,
pm_B0LNpsKPbGgqFDFZWKsdG_->mNumCol,pm_an0wiQTjdlKE72zC6FJ0a2);
pm_RBkGG4mV2eXeUxWqZrZ_D0(pm_cPpFNNxfnE9grx4hesF5K_,pm_B0LNpsKPbGgqFDFZWKsdG_)
;return pm_cPpFNNxfnE9grx4hesF5K_;}void pm_7qv2N86L_Nx58YfedYAKB2(
pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(
pm_KOiiP_gqHP9q_8e9O2OJi2->mX);if(pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
pm_GAbHnJspJ6sMhe_Yzxehb_);}};{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(
pm_KOiiP_gqHP9q_8e9O2OJi2);if(pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
pm_GAbHnJspJ6sMhe_Yzxehb_);}};}void pm_uHZzpO3dV_gBTCFm801lW0(const
pm_xELwgkvowKyM9polnZA8_2*pm_KOiiP_gqHP9q_8e9O2OJi2){memset(
pm_KOiiP_gqHP9q_8e9O2OJi2->mX,0,pm_KOiiP_gqHP9q_8e9O2OJi2->mNumRow*
pm_KOiiP_gqHP9q_8e9O2OJi2->mNumCol*sizeof(real_T));}size_t
pm_MGbAo0b_Pvg7QU4YyM3B02(const pm_xELwgkvowKyM9polnZA8_2*
pm_KOiiP_gqHP9q_8e9O2OJi2){size_t pm_StaWXlpOQ6SIJ4_O8yBVR2=0;size_t
pm_dtnkT1Km5ucMT0rXvotaC2=0;for(pm_dtnkT1Km5ucMT0rXvotaC2=0;
pm_dtnkT1Km5ucMT0rXvotaC2<pm_KOiiP_gqHP9q_8e9O2OJi2->mNumRow*
pm_KOiiP_gqHP9q_8e9O2OJi2->mNumCol;pm_dtnkT1Km5ucMT0rXvotaC2++){
pm_StaWXlpOQ6SIJ4_O8yBVR2+=pm_KOiiP_gqHP9q_8e9O2OJi2->mX[
pm_dtnkT1Km5ucMT0rXvotaC2]?1:0;}return pm_StaWXlpOQ6SIJ4_O8yBVR2;}void
pm_SMY9vTgq0jMJs5_4peCEb2(const pm_xELwgkvowKyM9polnZA8_2*
pm_sZbJqnvRDJHN0b0Lebp6y0,const PmRealVector*pm_VXW2_bOrRwbT0N4pO6g580,const
PmSparsityPattern*pm_EphGIaq4DHWXGRbDOrH9x_){size_t pm_gN74BbsU5wqNjkJbC9b672=
pm_EphGIaq4DHWXGRbDOrH9x_->mNumRow;size_t n=pm_EphGIaq4DHWXGRbDOrH9x_->mNumCol
;size_t pm_OUB2pptsvtdGL_LyqpgOa0=0;int32_T pm_QQvrlcFdHDI1GGuBZrW5C2=0;
int32_T*pm_S51jjFL079S8kdC86krPC0=pm_EphGIaq4DHWXGRbDOrH9x_->mJc;int32_T*
pm_rX2Nhyrokuq9JmnRvEAkJ1=pm_EphGIaq4DHWXGRbDOrH9x_->mIr;;;
pm_uHZzpO3dV_gBTCFm801lW0(pm_sZbJqnvRDJHN0b0Lebp6y0);for(
pm_OUB2pptsvtdGL_LyqpgOa0=0;pm_OUB2pptsvtdGL_LyqpgOa0<n;
pm_OUB2pptsvtdGL_LyqpgOa0++){for(pm_QQvrlcFdHDI1GGuBZrW5C2=
pm_S51jjFL079S8kdC86krPC0[pm_OUB2pptsvtdGL_LyqpgOa0];pm_QQvrlcFdHDI1GGuBZrW5C2
<pm_S51jjFL079S8kdC86krPC0[pm_OUB2pptsvtdGL_LyqpgOa0+1];
pm_QQvrlcFdHDI1GGuBZrW5C2++){pm_YLO8EeU47vBVt0OpuLKTD0(
pm_sZbJqnvRDJHN0b0Lebp6y0,pm_rX2Nhyrokuq9JmnRvEAkJ1[pm_QQvrlcFdHDI1GGuBZrW5C2]
,pm_OUB2pptsvtdGL_LyqpgOa0,pm_VXW2_bOrRwbT0N4pO6g580->mX[
pm_QQvrlcFdHDI1GGuBZrW5C2]);}}}void pm_4Z81QuXMmjeQwuPgWZ5tk2(const
pm_xELwgkvowKyM9polnZA8_2*pm_sZbJqnvRDJHN0b0Lebp6y0,const PmBoolVector*
pm_gq3kPpO4Hdv_0UBmX5sfB1){size_t pm_SmSSPSQfR1qEYWsVj5ELF0=0;size_t
pm_OUB2pptsvtdGL_LyqpgOa0=0;;for(pm_OUB2pptsvtdGL_LyqpgOa0=0;
pm_OUB2pptsvtdGL_LyqpgOa0<pm_sZbJqnvRDJHN0b0Lebp6y0->mNumCol;
pm_OUB2pptsvtdGL_LyqpgOa0++){if(pm_gq3kPpO4Hdv_0UBmX5sfB1->mX[
pm_OUB2pptsvtdGL_LyqpgOa0]){for(pm_SmSSPSQfR1qEYWsVj5ELF0=0;
pm_SmSSPSQfR1qEYWsVj5ELF0<pm_sZbJqnvRDJHN0b0Lebp6y0->mNumRow;
pm_SmSSPSQfR1qEYWsVj5ELF0++){pm_YLO8EeU47vBVt0OpuLKTD0(
pm_sZbJqnvRDJHN0b0Lebp6y0,pm_SmSSPSQfR1qEYWsVj5ELF0,pm_OUB2pptsvtdGL_LyqpgOa0,
0.0);}}}}void pm_RBkGG4mV2eXeUxWqZrZ_D0(const pm_xELwgkvowKyM9polnZA8_2*dst,
const pm_xELwgkvowKyM9polnZA8_2*src){size_t n=dst->mNumRow*dst->mNumCol;;;if(n
>0&&dst->mX!=src->mX){memcpy(dst->mX,src->mX,n*sizeof(real_T));}}boolean_T
pm_Ct3OT7r9ARKw_pJqHPLDS2(const pm_xELwgkvowKyM9polnZA8_2*dst,const
pm_xELwgkvowKyM9polnZA8_2*src){size_t n=dst->mNumRow*dst->mNumCol;;;if(n>0&&
dst->mX!=src->mX){return memcmp(dst->mX,src->mX,src->mNumRow*src->mNumCol*
sizeof(real_T))==0;}else{return true;}}boolean_T pm_sYk4ZLEaO8wF7NdpQZXqg_(
const pm_xELwgkvowKyM9polnZA8_2*dst,size_t pm_zBgtBOGV5868yvaq9VmVW_,const
pm_xELwgkvowKyM9polnZA8_2*src,size_t pm_ylfAzmjIY4rqTc8S_UplF2,size_t
pm___oCzuVa6AMVNXQEKlS5G1){size_t pm_gN74BbsU5wqNjkJbC9b672=dst->mNumRow;
size_t n=dst->mNumCol;;;;return memcmp(dst->mX+pm_zBgtBOGV5868yvaq9VmVW_*
pm_gN74BbsU5wqNjkJbC9b672,src->mX+pm_ylfAzmjIY4rqTc8S_UplF2*
pm_gN74BbsU5wqNjkJbC9b672,pm___oCzuVa6AMVNXQEKlS5G1*pm_gN74BbsU5wqNjkJbC9b672*
sizeof(real_T))==0;}void pm_FcuhGEI4_hbnVFe3jdkcL2(const
pm_xELwgkvowKyM9polnZA8_2*dst,size_t pm_zBgtBOGV5868yvaq9VmVW_,const
pm_xELwgkvowKyM9polnZA8_2*src,size_t pm_ylfAzmjIY4rqTc8S_UplF2,size_t
pm___oCzuVa6AMVNXQEKlS5G1){size_t pm_gN74BbsU5wqNjkJbC9b672=dst->mNumRow;
size_t n=dst->mNumCol;;;;memcpy(dst->mX+pm_zBgtBOGV5868yvaq9VmVW_*
pm_gN74BbsU5wqNjkJbC9b672,src->mX+pm_ylfAzmjIY4rqTc8S_UplF2*
pm_gN74BbsU5wqNjkJbC9b672,pm___oCzuVa6AMVNXQEKlS5G1*pm_gN74BbsU5wqNjkJbC9b672*
sizeof(real_T));}
