#include "pm_std.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_U1h5Sl4yTxoF_YCvN9hBa1(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_);void pm_TnPSeUZeYw5Wc8bvD8sl80(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_fKS8kuV7G_WhlO7CcdVnc1(const PmCharVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmCharVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm___43lXp90F4bzSkAXqYfT1(
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);int_T pm_create_real_vector_fields(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_create_real_vector(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(
const PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_destroy_real_vector(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_int_vector_fields(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmIntVector*pm_create_int_vector(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_pLia5sG_NxTeQbxzYtpXx_(const
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_Rdk2CZ3CCj5T0d2uDHUZ20(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_int_vector(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_
(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_SK8Vck8jU45BIyJDK11DV_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*
pm_Or6MViYTj4_1rM_3pn1UZ0(const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_cn_kUNHZ0hjihWokUKapj_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_nUREx2_I6_H8Z9q4fW3LX2(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);
#include "pm_std.h"
#include "string.h"
void pm_rv_equals_rv(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_){size_t n=pm__UmJPtGaW9C9junx1RpnH_->mN
;;if(n>0&&pm_JMQ_js3toioP0_0hj_fm5_->mX!=pm__UmJPtGaW9C9junx1RpnH_->mX){memcpy
(pm_JMQ_js3toioP0_0hj_fm5_->mX,pm__UmJPtGaW9C9junx1RpnH_->mX,n*sizeof(real_T))
;}}void pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_){size_t n=
pm__UmJPtGaW9C9junx1RpnH_->mN;;if(n>0){memcpy(pm_JMQ_js3toioP0_0hj_fm5_->mX,
pm__UmJPtGaW9C9junx1RpnH_->mX,n*sizeof(int32_T));}}void
pm_TnPSeUZeYw5Wc8bvD8sl80(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_){size_t n=pm__UmJPtGaW9C9junx1RpnH_->mN
;;if(n>0){memcpy(pm_JMQ_js3toioP0_0hj_fm5_->mX,pm__UmJPtGaW9C9junx1RpnH_->mX,n
*sizeof(boolean_T));}}void pm_fKS8kuV7G_WhlO7CcdVnc1(const PmCharVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*pm__UmJPtGaW9C9junx1RpnH_){size_t
n=pm__UmJPtGaW9C9junx1RpnH_->mN;;if(n>0){memcpy(pm_JMQ_js3toioP0_0hj_fm5_->mX,
pm__UmJPtGaW9C9junx1RpnH_->mX,n*sizeof(char));}}boolean_T
pm___43lXp90F4bzSkAXqYfT1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_){;if(pm_JMQ_js3toioP0_0hj_fm5_->mN==0){
return true;}else{return(memcmp(pm_JMQ_js3toioP0_0hj_fm5_->mX,
pm__UmJPtGaW9C9junx1RpnH_->mX,pm_JMQ_js3toioP0_0hj_fm5_->mN*sizeof(real_T))==0
);}}boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_){;if(
pm_JMQ_js3toioP0_0hj_fm5_->mN==0){return true;}else{return(memcmp(
pm_JMQ_js3toioP0_0hj_fm5_->mX,pm__UmJPtGaW9C9junx1RpnH_->mX,
pm_JMQ_js3toioP0_0hj_fm5_->mN*sizeof(int32_T))==0);}}boolean_T
pm_9IegWBFmNW3wA_0fRmj9m2(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_){;if(pm_JMQ_js3toioP0_0hj_fm5_->mN==0){
return true;}else{return(memcmp(pm_JMQ_js3toioP0_0hj_fm5_->mX,
pm__UmJPtGaW9C9junx1RpnH_->mX,pm_JMQ_js3toioP0_0hj_fm5_->mN*sizeof(boolean_T))
==0);}}int_T pm_create_real_vector_fields(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){
int_T pm_G9Ug5Uhj979D3_dBSwlTW0=0;pm_VmBquL1cTEkIgP0cS5pM82->mN=size;if(size==
0){pm_VmBquL1cTEkIgP0cS5pM82->mX=NULL;}else if(!(pm_VmBquL1cTEkIgP0cS5pM82->mX
=(real_T*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2)
,(sizeof(real_T)),(size))))){pm_G9Ug5Uhj979D3_dBSwlTW0=1;}return
pm_G9Ug5Uhj979D3_dBSwlTW0;}PmRealVector*pm_create_real_vector(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82=(PmRealVector*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->
mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(PmRealVector)),(1)));if(
pm_VmBquL1cTEkIgP0cS5pM82){if(pm_create_real_vector_fields(
pm_VmBquL1cTEkIgP0cS5pM82,pm_Z_HH1rAAmOFPWVcI_yamd_,pm_WFHqm0fOpgfhKZFbY5NWh2)
){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};
pm_VmBquL1cTEkIgP0cS5pM82=NULL;}}return pm_VmBquL1cTEkIgP0cS5pM82;}
PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(const PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmRealVector*
pm_QyVbO3pTvGiccU8Tn2eK2_=pm_create_real_vector(pm_VmBquL1cTEkIgP0cS5pM82->mN,
pm_WFHqm0fOpgfhKZFbY5NWh2);;pm_rv_equals_rv(pm_QyVbO3pTvGiccU8Tn2eK2_,
pm_VmBquL1cTEkIgP0cS5pM82);return pm_QyVbO3pTvGiccU8Tn2eK2_;}void
pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){if(pm_VmBquL1cTEkIgP0cS5pM82->mX!=NULL){{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82->mX);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}}void
pm_destroy_real_vector(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){;pm_MgDXCYHfYCiNYyF5Ik7dF2(
pm_VmBquL1cTEkIgP0cS5pM82,pm_WFHqm0fOpgfhKZFbY5NWh2);{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}int_T
pm_create_int_vector_fields(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){int_T pm_G9Ug5Uhj979D3_dBSwlTW0=0;
pm_VmBquL1cTEkIgP0cS5pM82->mN=size;if(size==0){pm_VmBquL1cTEkIgP0cS5pM82->mX=
NULL;}else if(!(pm_VmBquL1cTEkIgP0cS5pM82->mX=(int_T*)((
pm_WFHqm0fOpgfhKZFbY5NWh2)->mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(
int_T)),(size))))){pm_G9Ug5Uhj979D3_dBSwlTW0=1;}return
pm_G9Ug5Uhj979D3_dBSwlTW0;}PmIntVector*pm_create_int_vector(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82=(PmIntVector*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->
mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(PmIntVector)),(1)));if(
pm_VmBquL1cTEkIgP0cS5pM82){if(pm_create_int_vector_fields(
pm_VmBquL1cTEkIgP0cS5pM82,pm_Z_HH1rAAmOFPWVcI_yamd_,pm_WFHqm0fOpgfhKZFbY5NWh2)
){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};
pm_VmBquL1cTEkIgP0cS5pM82=NULL;}}return pm_VmBquL1cTEkIgP0cS5pM82;}PmIntVector
*pm_pLia5sG_NxTeQbxzYtpXx_(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmIntVector*pm_QyVbO3pTvGiccU8Tn2eK2_=
pm_create_int_vector(pm_VmBquL1cTEkIgP0cS5pM82->mN,pm_WFHqm0fOpgfhKZFbY5NWh2);
;pm_U1h5Sl4yTxoF_YCvN9hBa1(pm_QyVbO3pTvGiccU8Tn2eK2_,pm_VmBquL1cTEkIgP0cS5pM82
);return pm_QyVbO3pTvGiccU8Tn2eK2_;}void pm_Rdk2CZ3CCj5T0d2uDHUZ20(PmIntVector
*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){if(
pm_VmBquL1cTEkIgP0cS5pM82->mX!=NULL){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(
pm_VmBquL1cTEkIgP0cS5pM82->mX);if(pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(pm_WFHqm0fOpgfhKZFbY5NWh2,
pm_GAbHnJspJ6sMhe_Yzxehb_);}};}}void pm_destroy_int_vector(PmIntVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){;
pm_Rdk2CZ3CCj5T0d2uDHUZ20(pm_VmBquL1cTEkIgP0cS5pM82,pm_WFHqm0fOpgfhKZFbY5NWh2)
;{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}int_T
pm_create_bool_vector_fields(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){int_T pm_G9Ug5Uhj979D3_dBSwlTW0=0;
pm_VmBquL1cTEkIgP0cS5pM82->mN=size;if(size==0){pm_VmBquL1cTEkIgP0cS5pM82->mX=
NULL;}else if(!(pm_VmBquL1cTEkIgP0cS5pM82->mX=(boolean_T*)((
pm_WFHqm0fOpgfhKZFbY5NWh2)->mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(
boolean_T)),(size))))){pm_G9Ug5Uhj979D3_dBSwlTW0=1;}return
pm_G9Ug5Uhj979D3_dBSwlTW0;}PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82=(PmBoolVector*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->
mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(PmBoolVector)),(1)));if(
pm_VmBquL1cTEkIgP0cS5pM82){if(pm_create_bool_vector_fields(
pm_VmBquL1cTEkIgP0cS5pM82,pm_Z_HH1rAAmOFPWVcI_yamd_,pm_WFHqm0fOpgfhKZFbY5NWh2)
){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};
pm_VmBquL1cTEkIgP0cS5pM82=NULL;}}return pm_VmBquL1cTEkIgP0cS5pM82;}void
pm_SK8Vck8jU45BIyJDK11DV_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){if(pm_VmBquL1cTEkIgP0cS5pM82->mX!=NULL){{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82->mX);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}}void
pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){;pm_SK8Vck8jU45BIyJDK11DV_(
pm_VmBquL1cTEkIgP0cS5pM82,pm_WFHqm0fOpgfhKZFbY5NWh2);{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}PmBoolVector*
pm_Or6MViYTj4_1rM_3pn1UZ0(const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmBoolVector*pm_QyVbO3pTvGiccU8Tn2eK2_=
pm_YZQHxvtiv5rBT_iBt45HQ_(pm_VmBquL1cTEkIgP0cS5pM82->mN,
pm_WFHqm0fOpgfhKZFbY5NWh2);;pm_TnPSeUZeYw5Wc8bvD8sl80(
pm_QyVbO3pTvGiccU8Tn2eK2_,pm_VmBquL1cTEkIgP0cS5pM82);return
pm_QyVbO3pTvGiccU8Tn2eK2_;}int_T pm_create_char_vector_fields(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){
int_T pm_G9Ug5Uhj979D3_dBSwlTW0=0;pm_VmBquL1cTEkIgP0cS5pM82->mN=size;if(size==
0){pm_VmBquL1cTEkIgP0cS5pM82->mX=NULL;}else if(!(pm_VmBquL1cTEkIgP0cS5pM82->mX
=(char*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(
sizeof(char)),(size))))){pm_G9Ug5Uhj979D3_dBSwlTW0=1;}return
pm_G9Ug5Uhj979D3_dBSwlTW0;}PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82=(PmCharVector*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->
mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(PmCharVector)),(1)));if(
pm_VmBquL1cTEkIgP0cS5pM82){if(pm_create_char_vector_fields(
pm_VmBquL1cTEkIgP0cS5pM82,pm_Z_HH1rAAmOFPWVcI_yamd_,pm_WFHqm0fOpgfhKZFbY5NWh2)
){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};
pm_VmBquL1cTEkIgP0cS5pM82=NULL;}}return pm_VmBquL1cTEkIgP0cS5pM82;}void
pm_cn_kUNHZ0hjihWokUKapj_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){if(pm_VmBquL1cTEkIgP0cS5pM82->mX!=NULL){{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82->mX);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}}void
pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){;pm_cn_kUNHZ0hjihWokUKapj_(
pm_VmBquL1cTEkIgP0cS5pM82,pm_WFHqm0fOpgfhKZFbY5NWh2);{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}int_T
pm_nUREx2_I6_H8Z9q4fW3LX2(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){int_T pm_G9Ug5Uhj979D3_dBSwlTW0=0;
pm_VmBquL1cTEkIgP0cS5pM82->mN=size;if(size==0){pm_VmBquL1cTEkIgP0cS5pM82->mX=
NULL;}else if(!(pm_VmBquL1cTEkIgP0cS5pM82->mX=(size_t*)((
pm_WFHqm0fOpgfhKZFbY5NWh2)->mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(
size_t)),(size))))){pm_G9Ug5Uhj979D3_dBSwlTW0=1;}return
pm_G9Ug5Uhj979D3_dBSwlTW0;}PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2){PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82=(PmSizeVector*)((pm_WFHqm0fOpgfhKZFbY5NWh2)->
mCallocFcn((pm_WFHqm0fOpgfhKZFbY5NWh2),(sizeof(PmSizeVector)),(1)));if(
pm_VmBquL1cTEkIgP0cS5pM82){if(pm_nUREx2_I6_H8Z9q4fW3LX2(
pm_VmBquL1cTEkIgP0cS5pM82,pm_Z_HH1rAAmOFPWVcI_yamd_,pm_WFHqm0fOpgfhKZFbY5NWh2)
){{void*pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};
pm_VmBquL1cTEkIgP0cS5pM82=NULL;}}return pm_VmBquL1cTEkIgP0cS5pM82;}void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){if(pm_VmBquL1cTEkIgP0cS5pM82->mX!=NULL){{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82->mX);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}}void
pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2){;pm_5sJaU0uW397ggcDhUnm4m0(
pm_VmBquL1cTEkIgP0cS5pM82,pm_WFHqm0fOpgfhKZFbY5NWh2);{void*
pm_GAbHnJspJ6sMhe_Yzxehb_=(pm_VmBquL1cTEkIgP0cS5pM82);if(
pm_GAbHnJspJ6sMhe_Yzxehb_!=0){(pm_WFHqm0fOpgfhKZFbY5NWh2)->mFreeFcn(
pm_WFHqm0fOpgfhKZFbY5NWh2,pm_GAbHnJspJ6sMhe_Yzxehb_);}};}void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_){size_t n=pm__UmJPtGaW9C9junx1RpnH_->mN
;;if(n>0){memcpy(pm_JMQ_js3toioP0_0hj_fm5_->mX,pm__UmJPtGaW9C9junx1RpnH_->mX,n
*sizeof(size_t));}}boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(const PmSizeVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_){;if(
pm_JMQ_js3toioP0_0hj_fm5_->mN==0){return true;}else{return(memcmp(
pm_JMQ_js3toioP0_0hj_fm5_->mX,pm__UmJPtGaW9C9junx1RpnH_->mX,
pm_JMQ_js3toioP0_0hj_fm5_->mN*sizeof(size_t))==0);}}
