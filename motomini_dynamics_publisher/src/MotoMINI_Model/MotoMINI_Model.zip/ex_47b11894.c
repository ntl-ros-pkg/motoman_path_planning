#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_8GXoVYNB7xMB70dsCbAyA0(const real_T*a,const size_t n);real_T
ex_N_clXqffVCzi68eTuA7Z92(const real_T x);void ex_hvjqVE7WfEAt6jcTNsW1u1(
real_T*fx1,real_T*ex_qqj_9pClxpUaveq616vWX_,real_T*ex_ODvhPeUiIMv_N9a0J2IIb_,
real_T*ex_LoObIqjlDGtLzUnGZVFIh_,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51,const size_t
ex_VkP8sW5ujEbh_RG29El9R_,const size_t ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t
ex_2Y91_CRjyUMrCFE4844Jf2,const size_t ex_Ea66QGACnnAzBr5cQEISd_,const size_t
ex_Lyxgt0ApsOxYV7SxIdPws0,const size_t ex_FWzS4LG9JH3q_zkgeM_bR_,const size_t
ex_B6u9Yh3NFQBXCHXd_cy3L1,const size_t ex_2VFGnsOS8QAJGmX42jhDs2,const real_T
ex_9R2ICyFZrMWnnqVz69LS_0);void ex_8Lr4A0sHb9kykh8D_nd4y1(real_T*
ex_fIUN8VRWYW_vvrJBW8lXr0,real_T*ex_CC2nBop_AzM8GWVhi5l_y_,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51,const size_t ex_VkP8sW5ujEbh_RG29El9R_,const size_t
ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t ex_2Y91_CRjyUMrCFE4844Jf2,const size_t
ex_Ea66QGACnnAzBr5cQEISd_,const size_t ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t
ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t ex_tgAG8_0Nazq7r3JqH9poq_,const size_t
ex_DZjm31wkoWuZA_gQ2ngh90,const size_t ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t
ex_Crw725fjFuk9WoyqNW5D90,const size_t ex_216LSH5aKi96he3yzgTIY2,const size_t
ex_5mllB3D9zrHViNrvMthgP_,const real_T ex_9R2ICyFZrMWnnqVz69LS_0,const real_T
ex_Cx97aITo5DLOpdlBjw0Ev2);void ex_c908i9DZYVP8NLFJeVsnP_(real_T*
ex_dWVCFoCXPoLwscxjXxh7F0,real_T*ex_t0DOW86Hne7Cet0k6nxk50,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const real_T*ex_spvq_BLax0ZY7BWNVJdV3_,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51,const size_t
ex_VkP8sW5ujEbh_RG29El9R_,const size_t ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t
ex_2Y91_CRjyUMrCFE4844Jf2,const size_t ex_Ea66QGACnnAzBr5cQEISd_,const size_t
ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t
ex_tgAG8_0Nazq7r3JqH9poq_,const size_t ex_DZjm31wkoWuZA_gQ2ngh90,const size_t
ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t ex_Crw725fjFuk9WoyqNW5D90,const size_t
ex_216LSH5aKi96he3yzgTIY2,const size_t ex_5mllB3D9zrHViNrvMthgP_,const size_t
ex_dfsGKZ4SOnBWg0_LthaSE1,const size_t ex_f_G4CiEEGpLNC_d__6Otr_,const size_t
ex_sPax9bjJmVREGHAn0mqfe1,const size_t ex_V_jgHYQ6HxaicixaD4B4m_,const real_T
ex_9R2ICyFZrMWnnqVz69LS_0,const real_T ex_Cx97aITo5DLOpdlBjw0Ev2,const real_T
ex_wtdXVMGIS6xhoVmY9M2nE0);void ex_g6tFmYqTirCa3ZPS1u16h0(real_T*
ex_X3vLkYlbdpuLDjBGk57vo_,real_T*ex_WV0gRaOXjiFGQaR18XBfo_,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const real_T*ex_spvq_BLax0ZY7BWNVJdV3_,const real_T*
ex_YZ_rgSdzO2vZDxo7EhthC1,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51,const size_t ex_VkP8sW5ujEbh_RG29El9R_,const size_t
ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t ex_2Y91_CRjyUMrCFE4844Jf2,const size_t
ex_Ea66QGACnnAzBr5cQEISd_,const size_t ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t
ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t ex_tgAG8_0Nazq7r3JqH9poq_,const size_t
ex_DZjm31wkoWuZA_gQ2ngh90,const size_t ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t
ex_Crw725fjFuk9WoyqNW5D90,const size_t ex_216LSH5aKi96he3yzgTIY2,const size_t
ex_5mllB3D9zrHViNrvMthgP_,const size_t ex_dfsGKZ4SOnBWg0_LthaSE1,const size_t
ex_f_G4CiEEGpLNC_d__6Otr_,const size_t ex_sPax9bjJmVREGHAn0mqfe1,const size_t
ex_V_jgHYQ6HxaicixaD4B4m_,const size_t ex_U9lWWqx0jFokA4xwwiPb71,const size_t
ex_2rLQUCwyQWFWspPbF4UpE2,const size_t ex_BL4aaq_PAxk1Nxu_rJOWw0,const size_t
ex_y90_D_qMktK1Fkn1BdLpK2,const real_T ex_9R2ICyFZrMWnnqVz69LS_0,const real_T
ex_Cx97aITo5DLOpdlBjw0Ev2,const real_T ex_wtdXVMGIS6xhoVmY9M2nE0,const real_T
ex_Wu5vsdT_Yw4IM6TngEpjz1);size_t ex_EPCusphBPNYsP9i21jsva0(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_XPTig2EtwH6R7_NgNRUTK0,const boolean_T
ex_Qmu676yE9oxL758xSv1lO1);size_t ex_XgFqE_qWosDa601lsTn6b1(const real_T*x,
const size_t n,const real_T t);void ex_58tHK_FJLrTVg5pTR2KLX0(real_T*
ex__lerGssn0Ru_r3kSOzEmI_,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51);void ex_kxquG9pkEjt4fXtMQOsqG2(real_T*x,real_T*f,
const size_t n);void ex_nC4jUddYFsKRLzFkVBm3G0(real_T*x1,real_T*x2,real_T*f,
const size_t n1,const size_t n2);void ex_p_64ouPbD9bddOkoAZOpZ1(real_T*x1,
real_T*x2,real_T*x3,real_T*f,const size_t n1,const size_t n2,const size_t n3);
void ex_5NKaAbmUyQr1tleeDl4Vc2(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*
f,const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "pm_std.h"
#include "lang_std.h"
#include "string.h"
static void ex_jAjJZ8JuSF0wUWC8ZIPf1_(real_T*fi,const real_T*H1,const real_T*
Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*f,const real_T*fx,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2,const real_T
ex_XPTig2EtwH6R7_NgNRUTK0,const boolean_T ex_Qmu676yE9oxL758xSv1lO1);static
void ex_VzxrITerg_aFm9O5Uvc4B0(real_T*x1,real_T*x2,real_T*f,real_T*fx,real_T*
bv1,real_T*bv2,const real_T*x1s,const real_T*x2s,const real_T*fs,const size_t
n1,const size_t n2);void tlu2_2d_akima_nearest_process(real_T*x1,real_T*x2,
real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,const real_T*x1s,const real_T*x2s,
const real_T*fs,const size_t*n1,const size_t*n2){ex_VzxrITerg_aFm9O5Uvc4B0(x1,
x2,f,fx1,bv1,bv2,x1s,x2s,fs,*n1,*n2);}void
tlu2_2d_akima_nearest_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*fs=(const real_T*)((const void
*const*)in)[2];const size_t*n1=(const size_t*)((const void*const*)in)[3];const
size_t*n2=(const size_t*)((const void*const*)in)[4];real_T*x1=(real_T*)((void*
*)out)[0];real_T*x2=(real_T*)((void**)out)[1];real_T*f=(real_T*)((void**)out)[
2];real_T*fx=(real_T*)((void**)out)[3];real_T*bv1=(real_T*)((void**)out)[4];
real_T*bv2=(real_T*)((void**)out)[5];tlu2_2d_akima_nearest_process(x1,x2,f,fx,
bv1,bv2,x1s,x2s,fs,n1,n2);}void tlu2_2d_akima_linear_process(real_T*x1,real_T*
x2,real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,const real_T*x1s,const real_T*x2s
,const real_T*fs,const size_t*n1,const size_t*n2){ex_VzxrITerg_aFm9O5Uvc4B0(x1
,x2,f,fx1,bv1,bv2,x1s,x2s,fs,*n1,*n2);}void
tlu2_2d_akima_linear_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*fs=(const real_T*)((const void
*const*)in)[2];const size_t*n1=(const size_t*)((const void*const*)in)[3];const
size_t*n2=(const size_t*)((const void*const*)in)[4];real_T*x1=(real_T*)((void*
*)out)[0];real_T*x2=(real_T*)((void**)out)[1];real_T*f=(real_T*)((void**)out)[
2];real_T*fx=(real_T*)((void**)out)[3];real_T*bv1=(real_T*)((void**)out)[4];
real_T*bv2=(real_T*)((void**)out)[5];tlu2_2d_akima_linear_process(x1,x2,f,fx,
bv1,bv2,x1s,x2s,fs,n1,n2);}static void ex_VzxrITerg_aFm9O5Uvc4B0(real_T*x1,
real_T*x2,real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,const real_T*x1s,const
real_T*x2s,const real_T*fs,const size_t n1,const size_t n2){const real_T
ex_yS7VvSIKrGg9ddzBqHtUd_=1.0e-12;const size_t n=n1*n2;real_T*
ex_vbkgywIQ4eOJV3pIXML402=fx1+n;real_T*ex_fIUN8VRWYW_vvrJBW8lXr0=
ex_vbkgywIQ4eOJV3pIXML402+n;real_T*ex_ODvhPeUiIMv_N9a0J2IIb_=pmf_calloc(n1-1,
sizeof(real_T));real_T*ex_RXybOEtSS2Y_aWO6lLrWy_=pmf_calloc(n2-1,sizeof(real_T
));size_t ex_TRX2tYdjo35rpgdBFLpJR2=(n1+1)*(n2+1);real_T*
ex_LoObIqjlDGtLzUnGZVFIh_=pmf_calloc(ex_TRX2tYdjo35rpgdBFLpJR2,sizeof(real_T))
;real_T*ex_ot23j5iQO3J58M3wgLjDF_=pmf_calloc(ex_TRX2tYdjo35rpgdBFLpJR2,sizeof(
real_T));real_T*ex_CC2nBop_AzM8GWVhi5l_y_=NULL;real_T*
ex_qqj_9pClxpUaveq616vWX_=pmf_calloc((n1+2)*n2,sizeof(real_T));real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_=pmf_calloc(n1*(n2+2),sizeof(real_T));real_T
ex_48t8w2Cg33s489vomu9Kr2,ex_tDwZBqEpmfrYD5m_09xv_1,ex_ER1h_1EVPL8fiwyFSpjD92;
real_T ex_9R2ICyFZrMWnnqVz69LS_0,ex_Cx97aITo5DLOpdlBjw0Ev2;size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_;size_t
ex_VkP8sW5ujEbh_RG29El9R_,ex_w9siNcZ8q9Ps4bukNuo6T2;size_t
ex_zAvn4SDXaXE1tRMzhVx8u0,ex_dCQH4g_NXK9XSd2Vv9I7R2,ex_LX8MDhfG0H3nvIAZ7b1xv2,
ex_Crw725fjFuk9WoyqNW5D90;memcpy(x1,x1s,n1*sizeof(real_T));memcpy(x2,x2s,n2*
sizeof(real_T));memcpy(f,fs,n*sizeof(real_T));ex_nC4jUddYFsKRLzFkVBm3G0(x1,x2,
f,n1,n2);bv1[0]=x1[0];bv1[1]=x1[n1-1];bv2[0]=x2[0];bv2[1]=x2[n2-1];
ex_48t8w2Cg33s489vomu9Kr2=ex_N_clXqffVCzi68eTuA7Z92(x1[n1-1]-x1[0])+
ex_yS7VvSIKrGg9ddzBqHtUd_;ex_tDwZBqEpmfrYD5m_09xv_1=ex_N_clXqffVCzi68eTuA7Z92(
x2[n2-1]-x2[0])+ex_yS7VvSIKrGg9ddzBqHtUd_;ex_ER1h_1EVPL8fiwyFSpjD92=
ex_8GXoVYNB7xMB70dsCbAyA0(f,n)+ex_yS7VvSIKrGg9ddzBqHtUd_;
ex_9R2ICyFZrMWnnqVz69LS_0=ex_yS7VvSIKrGg9ddzBqHtUd_*ex_ER1h_1EVPL8fiwyFSpjD92/
ex_48t8w2Cg33s489vomu9Kr2;ex_Cx97aITo5DLOpdlBjw0Ev2=ex_yS7VvSIKrGg9ddzBqHtUd_*
ex_ER1h_1EVPL8fiwyFSpjD92/ex_tDwZBqEpmfrYD5m_09xv_1;ex_G5C_Yq8nLf6PL2EMNiFAc1=
1;ex_KTkrfjRMBsZjPvzwkIouc_=n1;ex_VkP8sW5ujEbh_RG29El9R_=1;
ex_w9siNcZ8q9Ps4bukNuo6T2=n1+1;ex_zAvn4SDXaXE1tRMzhVx8u0=1;
ex_dCQH4g_NXK9XSd2Vv9I7R2=n1+2;ex_LX8MDhfG0H3nvIAZ7b1xv2=1;
ex_Crw725fjFuk9WoyqNW5D90=n1;ex_hvjqVE7WfEAt6jcTNsW1u1(fx1,
ex_qqj_9pClxpUaveq616vWX_,ex_ODvhPeUiIMv_N9a0J2IIb_,ex_LoObIqjlDGtLzUnGZVFIh_,
x1,f,n1,n2,1,1,ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,0,0,
ex_VkP8sW5ujEbh_RG29El9R_,ex_w9siNcZ8q9Ps4bukNuo6T2,0,0,
ex_zAvn4SDXaXE1tRMzhVx8u0,ex_dCQH4g_NXK9XSd2Vv9I7R2,0,0,
ex_9R2ICyFZrMWnnqVz69LS_0);ex_hvjqVE7WfEAt6jcTNsW1u1(ex_vbkgywIQ4eOJV3pIXML402
,ex_bV4aNk1wGsZsv9PfSG7ML_,ex_RXybOEtSS2Y_aWO6lLrWy_,ex_ot23j5iQO3J58M3wgLjDF_
,x2,f,n2,n1,1,1,ex_KTkrfjRMBsZjPvzwkIouc_,ex_G5C_Yq8nLf6PL2EMNiFAc1,0,0,
ex_w9siNcZ8q9Ps4bukNuo6T2,ex_VkP8sW5ujEbh_RG29El9R_,0,0,
ex_Crw725fjFuk9WoyqNW5D90,ex_LX8MDhfG0H3nvIAZ7b1xv2,0,0,
ex_Cx97aITo5DLOpdlBjw0Ev2);ex_CC2nBop_AzM8GWVhi5l_y_=ex_ot23j5iQO3J58M3wgLjDF_
;ex_8Lr4A0sHb9kykh8D_nd4y1(ex_fIUN8VRWYW_vvrJBW8lXr0,ex_CC2nBop_AzM8GWVhi5l_y_
,ex_ODvhPeUiIMv_N9a0J2IIb_,ex_qqj_9pClxpUaveq616vWX_,ex_bV4aNk1wGsZsv9PfSG7ML_
,n1,n2,1,1,ex_G5C_Yq8nLf6PL2EMNiFAc1,ex_KTkrfjRMBsZjPvzwkIouc_,0,0,
ex_VkP8sW5ujEbh_RG29El9R_,ex_w9siNcZ8q9Ps4bukNuo6T2,0,0,
ex_zAvn4SDXaXE1tRMzhVx8u0,ex_dCQH4g_NXK9XSd2Vv9I7R2,0,0,
ex_LX8MDhfG0H3nvIAZ7b1xv2,ex_Crw725fjFuk9WoyqNW5D90,0,0,
ex_9R2ICyFZrMWnnqVz69LS_0,ex_Cx97aITo5DLOpdlBjw0Ev2);pmf_free(
ex_ODvhPeUiIMv_N9a0J2IIb_);pmf_free(ex_RXybOEtSS2Y_aWO6lLrWy_);pmf_free(
ex_LoObIqjlDGtLzUnGZVFIh_);pmf_free(ex_ot23j5iQO3J58M3wgLjDF_);pmf_free(
ex_qqj_9pClxpUaveq616vWX_);pmf_free(ex_bV4aNk1wGsZsv9PfSG7ML_);}void
tlu2_2d_akima_nearest_value(real_T*fi,const real_T*H1,const real_T*Hx1,const
real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,const
real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t*
numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_jAjJZ8JuSF0wUWC8ZIPf1_(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,0.0,false);}void
tlu2_2d_akima_nearest_value_custom_function_(void*out,const void*in){const
real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(const
real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((const void
*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const size_t*
bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const real_T*)
((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void*const*
)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const real_T
*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(const
size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((const
void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in)[12];
const real_T*fx=(const real_T*)((const void*const*)in)[13];const boolean_T*
mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*mode2=(
const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const size_t*)((
const void*const*)in)[16];const size_t*n2=(const size_t*)((const void*const*)
in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_nearest_value(fi,H1,Hx1,G1,Gx1,
numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2);}void
tlu2_2d_akima_linear_value(real_T*fi,const real_T*H1,const real_T*Hx1,const
real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,const
real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t*
numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_jAjJZ8JuSF0wUWC8ZIPf1_(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,1.0,false);}void
tlu2_2d_akima_linear_value_custom_function_(void*out,const void*in){const
real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(const
real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((const void
*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const size_t*
bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const real_T*)
((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void*const*
)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const real_T
*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(const
size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((const
void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in)[12];
const real_T*fx=(const real_T*)((const void*const*)in)[13];const boolean_T*
mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*mode2=(
const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const size_t*)((
const void*const*)in)[16];const size_t*n2=(const size_t*)((const void*const*)
in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_linear_value(fi,H1,Hx1,G1,Gx1,
numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2);}void
tlu2_2d_akima_nearest_derivatives(real_T*fi,const real_T*H1,const real_T*Hx1,
const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_jAjJZ8JuSF0wUWC8ZIPf1_(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,0.0,true);}void
tlu2_2d_akima_nearest_derivatives_custom_function_(void*out,const void*in){
const real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(
const real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((
const void*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)
in)[3];const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const
size_t*bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const
real_T*)((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void
*const*)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const
real_T*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(
const size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((
const void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in
)[12];const real_T*fx=(const real_T*)((const void*const*)in)[13];const
boolean_T*mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*
mode2=(const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const
size_t*)((const void*const*)in)[16];const size_t*n2=(const size_t*)((const void
*const*)in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_nearest_derivatives(fi,H1
,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2
);}void tlu2_2d_akima_linear_derivatives(real_T*fi,const real_T*H1,const real_T
*Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1
,const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_jAjJZ8JuSF0wUWC8ZIPf1_(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,1.0,true);}void
tlu2_2d_akima_linear_derivatives_custom_function_(void*out,const void*in){
const real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(
const real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((
const void*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)
in)[3];const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const
size_t*bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const
real_T*)((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void
*const*)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const
real_T*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(
const size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((
const void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in
)[12];const real_T*fx=(const real_T*)((const void*const*)in)[13];const
boolean_T*mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*
mode2=(const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const
size_t*)((const void*const*)in)[16];const size_t*n2=(const size_t*)((const void
*const*)in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_linear_derivatives(fi,H1,
Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2)
;}static void ex_jAjJZ8JuSF0wUWC8ZIPf1_(real_T*fi,const real_T*H1,const real_T
*Hx1,const real_T*G1,const real_T*Gx1,const size_t*ex_uKkFSkgeyrLLsE4_QaCHz2,
const size_t*ex_TLD86yw1_uzOWQZ_xODU41,const real_T*H2,const real_T*Hx2,const
real_T*G2,const real_T*Gx2,const size_t*ex_FxMO1PEpgiyDmHyNzql4c0,const size_t
*ex_rpLZ0PHV24Nld7ZZDKKnM1,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*ex_4oLMdqgndOv3ORJ6iGRvh1,const size_t
*ex_kDyljgJucJCk5zEUSySgd0,const real_T ex_XPTig2EtwH6R7_NgNRUTK0,const
boolean_T ex_Qmu676yE9oxL758xSv1lO1){const size_t n1= *
ex_4oLMdqgndOv3ORJ6iGRvh1;const size_t n2= *ex_kDyljgJucJCk5zEUSySgd0;const
size_t n=n1*n2;const real_T*ex_vbkgywIQ4eOJV3pIXML402=fx1+n;const real_T*
ex_fIUN8VRWYW_vvrJBW8lXr0=ex_vbkgywIQ4eOJV3pIXML402+n;size_t numEdges1= *
ex_uKkFSkgeyrLLsE4_QaCHz2;size_t numEdges2= *ex_FxMO1PEpgiyDmHyNzql4c0;size_t
bin1= *ex_TLD86yw1_uzOWQZ_xODU41;size_t bin2= *ex_rpLZ0PHV24Nld7ZZDKKnM1;
size_t bin=bin1+n1*bin2;size_t ex__VPpmCt_TuqLdOtTsmwgk2,
ex_947YwtWZMq1Crv_q1N3191;size_t ex_vJNTlzCToBxcUvOWkhNhd0,
ex_EIf_lwUWE1bdKMrfR2M1P1;fi[0]=0.0;if(ex_Qmu676yE9oxL758xSv1lO1){fi[1]=0.0;}
for(ex_947YwtWZMq1Crv_q1N3191=0;ex_947YwtWZMq1Crv_q1N3191<numEdges2;++
ex_947YwtWZMq1Crv_q1N3191){ex_EIf_lwUWE1bdKMrfR2M1P1=n1*
ex_947YwtWZMq1Crv_q1N3191+bin;for(ex__VPpmCt_TuqLdOtTsmwgk2=0;
ex__VPpmCt_TuqLdOtTsmwgk2<numEdges1;++ex__VPpmCt_TuqLdOtTsmwgk2){
ex_vJNTlzCToBxcUvOWkhNhd0=ex__VPpmCt_TuqLdOtTsmwgk2+ex_EIf_lwUWE1bdKMrfR2M1P1;
if(ex_Qmu676yE9oxL758xSv1lO1){fi[0]+=(f[ex_vJNTlzCToBxcUvOWkhNhd0]*G1[
ex__VPpmCt_TuqLdOtTsmwgk2]+fx1[ex_vJNTlzCToBxcUvOWkhNhd0]*Gx1[
ex__VPpmCt_TuqLdOtTsmwgk2])*H2[ex_947YwtWZMq1Crv_q1N3191]+(
ex_vbkgywIQ4eOJV3pIXML402[ex_vJNTlzCToBxcUvOWkhNhd0]*G1[
ex__VPpmCt_TuqLdOtTsmwgk2]+ex_fIUN8VRWYW_vvrJBW8lXr0[ex_vJNTlzCToBxcUvOWkhNhd0
]*Gx1[ex__VPpmCt_TuqLdOtTsmwgk2])*Hx2[ex_947YwtWZMq1Crv_q1N3191];fi[1]+=(f[
ex_vJNTlzCToBxcUvOWkhNhd0]*H1[ex__VPpmCt_TuqLdOtTsmwgk2]+fx1[
ex_vJNTlzCToBxcUvOWkhNhd0]*Hx1[ex__VPpmCt_TuqLdOtTsmwgk2])*G2[
ex_947YwtWZMq1Crv_q1N3191]+(ex_vbkgywIQ4eOJV3pIXML402[
ex_vJNTlzCToBxcUvOWkhNhd0]*H1[ex__VPpmCt_TuqLdOtTsmwgk2]+
ex_fIUN8VRWYW_vvrJBW8lXr0[ex_vJNTlzCToBxcUvOWkhNhd0]*Hx1[
ex__VPpmCt_TuqLdOtTsmwgk2])*Gx2[ex_947YwtWZMq1Crv_q1N3191];}else{fi[0]+=(f[
ex_vJNTlzCToBxcUvOWkhNhd0]*H1[ex__VPpmCt_TuqLdOtTsmwgk2]+fx1[
ex_vJNTlzCToBxcUvOWkhNhd0]*Hx1[ex__VPpmCt_TuqLdOtTsmwgk2])*H2[
ex_947YwtWZMq1Crv_q1N3191]+(ex_vbkgywIQ4eOJV3pIXML402[
ex_vJNTlzCToBxcUvOWkhNhd0]*H1[ex__VPpmCt_TuqLdOtTsmwgk2]+
ex_fIUN8VRWYW_vvrJBW8lXr0[ex_vJNTlzCToBxcUvOWkhNhd0]*Hx1[
ex__VPpmCt_TuqLdOtTsmwgk2])*Hx2[ex_947YwtWZMq1Crv_q1N3191];}}}}
