#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
size_t mc_KpKqaZjZ2rh3lSToFa7Oa2(const PmBoolVector*mc_ljExW6hRw43Vg4SLQUAvT1)
;void mc_KLKWK_FbEAF724qPNbehq1(const PmIntVector*mc_ykDPEcD4BuT8SJa7vuxej1,
const PmRealVector*x,const PmRealVector*mc_yS7VvSIKrGg9ddzBqHtUd_);void
mc_uJ_iGAyluQ5NndhonaPXl1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const PmIntVector*
mc_kmcnrlTt6IvFH5HSoyHe21);void mc_oT_HwSgZBfR7LPqZomt0Y0(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmIntVector*mc_kmcnrlTt6IvFH5HSoyHe21);void mc_mMmDjYPdSIEEQHj__7cd71(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_);void mc_zYvj4jole4TnufsPoZWW_2(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0);void
mc_TJe2EtJyyhfHpuJYOjxfC0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,boolean_T mc_7lBL31aWjgSfMHGQtksob2);
void mc_JM1DLKwRGzo9Uyq32V72E_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*mc_MmlNWCb0Iec292kl7KbkQ1);void mc_si_irLJWyQLY_l4tqebAe_(
const PmIntVector*mc_rxT7_6KqJcx5sNYEWRALX2,int32_T mc_RGllRMvIRPGkpbvuetJlO2)
;void mc_pJmDkwzzX3Iu6_VR_MyvL_(const PmBoolVector*mc_Hf_a_gs1wyoHoosYiGonU0,
const PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_YwEOIpm092vI_BA0rQzvJ2);void mc_SKE1EUStKD_KtRTTXrxqv2(const PmBoolVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmBoolVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_OT_v_IC_x9R85Z4eHn1jA0(const PmRealVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmRealVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_J9HotRGeuZtxiip_GSZPb0(PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);size_t
mc_lp5J2bZ8EcxnhyI1PKPZd2(const PmBoolVector*mc_G15g52JPQFeDaEm_uJadW_);void
mc__xr97Mh4VU4bdE2CcyEVf_(const PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,const
PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_);size_t mc_pdD80p5I4a4oDKki08oZ50(const
PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0);size_t mc_a_dd0x8Rstf0HD74BJt9A2(const
PmRealVector*mc_ZxltZcnt1eSoyJTnrOm7z2);size_t mc_8u8_LRBN9SbcEOkeum7ag0(const
PmBoolVector*mc_ZxltZcnt1eSoyJTnrOm7z2);boolean_T mc_Ukc2BYyTIIZDpb_lFOWTt0(
const PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0);boolean_T
mc_l26oJh0UM_xwSgKIeOC5J0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,int32_T
mc_RGllRMvIRPGkpbvuetJlO2);boolean_T mc_ocDPr6f6C4_v9b5NDj8JH_(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T mc_RGllRMvIRPGkpbvuetJlO2);void
mc_fuQc8C9CyCuf_KkBLV8eb0(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_8BTcsQ6C8h5zrW1ZQRhKf1(const
PmRealVector*x,real_T mc_ljExW6hRw43Vg4SLQUAvT1);void mc_W0fX8K54ez0qAgM9tXjsi_
(const PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_fjtK_RGCYgp34_TjPN6zv1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_LlLyVwCApgTvSBfIvzOuk0(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T a,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void mc_fIL9UyKjuKeUlnGmcXq5r2(const PmRealVector*x
,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_SheEjf_3lOXDmgzkmhMGG2);void mc_v7V5uZPqLRlsEpMCWsoMJ0(const PmRealVector*x
,const real_T a,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_DnL_y_DaeSoRsDtnK0hpB1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
real_T mc_8IKoYx3qsjeiwHerWlCOS1);void mc_I_W_409sg28ysFYlBfPcr_(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const real_T mc_8IKoYx3qsjeiwHerWlCOS1)
;void mc_MI5F4RaYNQR7pPk1GRkvn_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_lkC6x3YtrvW6L16S6aM60_(
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void mc_vfuXLuRk3KtAfbvK_cTrv2(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
mc_tOKZMGNlSqK650YhjgeKv0(const PmRealVector*mc_9JsNfMLIQx0SlNuEaL4I2_,real_T
mc_8IKoYx3qsjeiwHerWlCOS1);void mc_Uy10YSjkY75ViJd9dTdYI1(const PmBoolVector*
mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_Rhhlgu4QH_WTKd_5kpe4I2(const PmRealVector*
mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_WmHTznO_Ih_dJw_MhKtIQ1(const PmIntVector*
mc_9JsNfMLIQx0SlNuEaL4I2_,int32_T mc_RGllRMvIRPGkpbvuetJlO2);void
mc_nLc17gFNFcvBlJrwxJV4w_(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void
mc_W7kR8viSTKC_By0UjXE_A1(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void
mc_AQtCbBjZ792h1_Xaj_dR92(const PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0,const
PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,boolean_T mc_8IKoYx3qsjeiwHerWlCOS1);
void mc_tLxHiRii5tbHWjrunaI2i1(const PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_,
boolean_T mc_8IKoYx3qsjeiwHerWlCOS1);void mc_AZRifAjle326aZku91XJU2(const
PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_mGD4FL6_MDLg2bdqzdpfx_(const
PmBoolVector*x,size_t mc_SmSSPSQfR1qEYWsVj5ELF0,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_x2bRmxKlHWAMEwOZuiA_62(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);void
mc_eJ9VFRIFMWxO52_BT7X_C_(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);real_T mc_WJAbbKueqClxuItYQx7b61(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);real_T mc_TuU8NakpY91qxLM4is2wV2(const
PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82);int32_T mc_dLmR9a64iWQBHX4QM5zCr2(
const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82);int32_T mc_eIjmwucqCUJT1PyCl_z5b_
(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82);void mc_loSQGFba0sjWysbLdmqzS1(
PmIntVector*mc_QyVbO3pTvGiccU8Tn2eK2_,const PmIntVector*
mc_kI6kqxnpJaUqvLfVbMkdr0);void mc_O_flPmjeFB4ZmON9Xp2iV_(PmRealVector*
mc_EBUUePJ08d2hXtTa8LU0J_,const PmRealVector*mc_23nxQONnTNHWizowC7lIt0,const
PmSparsityPattern*mc_UYX2aVqEUCl0fW5_qT4Lo1);void mc_K1ezq3TzhoNUE_SEp0Dr12(
const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void
mc_WuGlfcFda9zO01qKeAxMn_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void
mc_qEYnRq0Ff87lxOQck1Gqi_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const real_T*x);void mc_SZGAWN4U4XTzc5RKGKSk5_(const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*
mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,
const PmRealVector*mc_2cVF0Ggof80TSRmRbhE8l1,size_t mc_LMkPrnaKcsYHEp0eExPFH1)
;void mc_FoRQvfcV_dWdjx5L1lyM_0(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,
const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*mc_5LkYradW8mKeL3fLSt9By1);void mc_lBp5wbXG7AvQ3hxoerNOW_(const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*
mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void mc_z041e_QXd3uR2ef2CH37s1(
const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_0R8y9UtrLk3busEbM65xW_,const PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,
size_t mc_OUB2pptsvtdGL_LyqpgOa0,real_T mc_8IKoYx3qsjeiwHerWlCOS1);void
mc_6IsBGrycIJELSxeQVWGP02(const PmRealVector*mc_SheEjf_3lOXDmgzkmhMGG2,const
PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_fDK_uVHGu_qFAztUmYrXG0(const PmRealVector*mc_Hf_a_gs1wyoHoosYiGonU0,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_Ma839gzucrzsXwGyDhMa82);void mc_Pv5PxBp1nNTpA2nv2TKO50(const PmRealVector*
mc_Hf_a_gs1wyoHoosYiGonU0,const PmIntVector*mc_Ma839gzucrzsXwGyDhMa82,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_);void mc_57l_YQYSoo0Ro6WNuRptH_(const
PmRealVector*a,const PmIntVector*mc_SmSSPSQfR1qEYWsVj5ELF0,const PmRealVector*
b);void mc_rQYUV3yV8oYU8KnRKkDRk1(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0);void mc_Xx__kIPwzSZkrHpStVmJF_(
const PmRealVector*a,const PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0,const
PmRealVector*b);void mc__oSPLVBiXeFzzJsThp3Cn_(const PmRealVector*a,const
PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0,real_T x);void mc_BtNbeiWJf_2ScS2FihDGI0
(const PmIntVector*mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*
mc_wgw5_klFOULlYUS4qsiDG1);void mc_rxnwynr09yoIhr_7WJOnw2(const PmBoolVector*
mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);
void mc_GXd0l4NyYg6UNbaEbfuyY1(const PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,
const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);void
mc_0IN6lZI7UaPeQvvz13t6Z_(const PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,const
PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);void mc_jk3AE9w8Z153JpwqOK4cP_(
const PmBoolVector*mc_v4k0LG4l9Qk9hEXlOIKML_,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmRealVector*mc_A1lUr3Ax9HoRb_bkcLe_A1);void
mc_PUtu_CUnyMAexj3n9ThPz1(const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_);void mc_wMbxp0k7MHKEjpdy17fjt_(const PmRealVector*
mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,
const PmBoolVector*mc_ID3sxM8zmIB_ZiazgNvWq2);void mc_5PAUXWifOqPPHW3wOzFa92(
const PmRealVector*mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmBoolVector*pm_gq3kPpO4Hdv_0UBmX5sfB1);
PmRealVector mc_mnPo3YlQdExsVqjHael_W2(const PmRealVector*
mc_ljExW6hRw43Vg4SLQUAvT1,size_t mc_XteRrKcywHWBP4sFymZ6y0,size_t
mc_jcOSsrULtHDGKqSRz3gAT0);void pm_rv_equals_rv(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_TnPSeUZeYw5Wc8bvD8sl80(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);void pm_fKS8kuV7G_WhlO7CcdVnc1(const PmCharVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm___43lXp90F4bzSkAXqYfT1(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);int_T
pm_create_real_vector_fields(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_create_real_vector(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(const PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_real_vector(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_int_vector_fields(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_create_int_vector(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*
pm_pLia5sG_NxTeQbxzYtpXx_(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_Rdk2CZ3CCj5T0d2uDHUZ20(
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_destroy_int_vector(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_SK8Vck8jU45BIyJDK11DV_(
PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_Or6MViYTj4_1rM_3pn1UZ0(
const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_cn_kUNHZ0hjihWokUKapj_(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_nUREx2_I6_H8Z9q4fW3LX2(
PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
#include "math.h"
#include "string.h"
static real_T mc_0yi6WMmI3Cf8fdFsUo8Qw0(real_T a){real_T
mc_LXJvYeN3pXrSY1rPyyAd9_=pmf_get_real_max();return((a!=a)||(a>
mc_LXJvYeN3pXrSY1rPyyAd9_)||(a<-mc_LXJvYeN3pXrSY1rPyyAd9_))?
mc_LXJvYeN3pXrSY1rPyyAd9_:fabs(a);}void mc_KLKWK_FbEAF724qPNbehq1(const
PmIntVector*mc_ykDPEcD4BuT8SJa7vuxej1,const PmRealVector*x,const PmRealVector*
mc_yS7VvSIKrGg9ddzBqHtUd_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,
mc_OUB2pptsvtdGL_LyqpgOa0=0;real_T mc_ZjVSXfIfnCBiU1HtWlFMT2= -1.0;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_ykDPEcD4BuT8SJa7vuxej1->mN;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_ykDPEcD4BuT8SJa7vuxej1->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]= -1;};for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<((
mc_ykDPEcD4BuT8SJa7vuxej1->mN)<(x->mN)?(mc_ykDPEcD4BuT8SJa7vuxej1->mN):(x->mN)
);mc_SmSSPSQfR1qEYWsVj5ELF0++){real_T mc_sZ15pycktQZ3Ghv_DCBfu_= -1.0;int32_T
mc_dgxKNThRdaII2T3FHtAfz1= -1;for(mc_OUB2pptsvtdGL_LyqpgOa0=0;
mc_OUB2pptsvtdGL_LyqpgOa0<x->mN;mc_OUB2pptsvtdGL_LyqpgOa0++){real_T
mc_lGrwWW0ERg3PEZB3txbfw2=mc_0yi6WMmI3Cf8fdFsUo8Qw0(x->mX[
mc_OUB2pptsvtdGL_LyqpgOa0]);if(mc_lGrwWW0ERg3PEZB3txbfw2==
mc_ZjVSXfIfnCBiU1HtWlFMT2){;if(((int32_T)mc_OUB2pptsvtdGL_LyqpgOa0)>
mc_ykDPEcD4BuT8SJa7vuxej1->mX[mc_SmSSPSQfR1qEYWsVj5ELF0-1]){
mc_sZ15pycktQZ3Ghv_DCBfu_=mc_lGrwWW0ERg3PEZB3txbfw2;mc_dgxKNThRdaII2T3FHtAfz1=
(int32_T)mc_OUB2pptsvtdGL_LyqpgOa0;break;}}if(mc_lGrwWW0ERg3PEZB3txbfw2>
mc_sZ15pycktQZ3Ghv_DCBfu_&&(mc_SmSSPSQfR1qEYWsVj5ELF0==0||
mc_lGrwWW0ERg3PEZB3txbfw2<mc_ZjVSXfIfnCBiU1HtWlFMT2)){
mc_sZ15pycktQZ3Ghv_DCBfu_=mc_lGrwWW0ERg3PEZB3txbfw2;mc_dgxKNThRdaII2T3FHtAfz1=
(int32_T)mc_OUB2pptsvtdGL_LyqpgOa0;}};;;mc_ZjVSXfIfnCBiU1HtWlFMT2=
mc_sZ15pycktQZ3Ghv_DCBfu_;if(mc_0yi6WMmI3Cf8fdFsUo8Qw0(x->mX[
mc_dgxKNThRdaII2T3FHtAfz1])>=mc_yS7VvSIKrGg9ddzBqHtUd_->mX[
mc_dgxKNThRdaII2T3FHtAfz1]){mc_ykDPEcD4BuT8SJa7vuxej1->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_dgxKNThRdaII2T3FHtAfz1;}else{break;}}}size_t
mc_KpKqaZjZ2rh3lSToFa7Oa2(const PmBoolVector*mc_ljExW6hRw43Vg4SLQUAvT1){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_ljExW6hRw43Vg4SLQUAvT1->mN;mc_SmSSPSQfR1qEYWsVj5ELF0>0;
mc_SmSSPSQfR1qEYWsVj5ELF0--){if(mc_ljExW6hRw43Vg4SLQUAvT1->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0-1]){return mc_SmSSPSQfR1qEYWsVj5ELF0;}};return 0;}
void mc_JM1DLKwRGzo9Uyq32V72E_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*mc_MmlNWCb0Iec292kl7KbkQ1){size_t mc_UcQ91Wou1NlJm_M1J1BSo1=
pm_JMQ_js3toioP0_0hj_fm5_->mN;int32_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;size_t
mc_J_8jBWbb0oKk4_H23VadG1=mc_MmlNWCb0Iec292kl7KbkQ1->mN;int32_T*
mc_cKcDRQOx_0QCxTFQuHuTX_=mc_MmlNWCb0Iec292kl7KbkQ1->mX;size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_UcQ91Wou1NlJm_M1J1BSo1;mc_SmSSPSQfR1qEYWsVj5ELF0
++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_cKcDRQOx_0QCxTFQuHuTX_[x[
mc_SmSSPSQfR1qEYWsVj5ELF0]];}}void mc_uJ_iGAyluQ5NndhonaPXl1(const PmIntVector
*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmIntVector*mc_kmcnrlTt6IvFH5HSoyHe21){size_t mc_UcQ91Wou1NlJm_M1J1BSo1=
pm_JMQ_js3toioP0_0hj_fm5_->mN;size_t mc_AoR8_FAMCEiy8t3uUiudM2=
pm__UmJPtGaW9C9junx1RpnH_->mN;size_t mc_OHoqm6pCNFp_0jat5JWFV2=
mc_kmcnrlTt6IvFH5HSoyHe21->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;int32_T*x=
pm_JMQ_js3toioP0_0hj_fm5_->mX;int32_T*mc_ET9_5EAP116KvP5KVqsrD2=
pm__UmJPtGaW9C9junx1RpnH_->mX;int32_T*mc_SheEjf_3lOXDmgzkmhMGG2=
mc_kmcnrlTt6IvFH5HSoyHe21->mX;;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_AoR8_FAMCEiy8t3uUiudM2;mc_SmSSPSQfR1qEYWsVj5ELF0
++){x[mc_ET9_5EAP116KvP5KVqsrD2[mc_SmSSPSQfR1qEYWsVj5ELF0]]=
mc_SheEjf_3lOXDmgzkmhMGG2[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_oT_HwSgZBfR7LPqZomt0Y0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const PmIntVector*
mc_kmcnrlTt6IvFH5HSoyHe21){size_t mc_UcQ91Wou1NlJm_M1J1BSo1=
pm_JMQ_js3toioP0_0hj_fm5_->mN;size_t mc_AoR8_FAMCEiy8t3uUiudM2=
pm__UmJPtGaW9C9junx1RpnH_->mN;size_t mc_OHoqm6pCNFp_0jat5JWFV2=
mc_kmcnrlTt6IvFH5HSoyHe21->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;int32_T*x=
pm_JMQ_js3toioP0_0hj_fm5_->mX;int32_T*mc_ET9_5EAP116KvP5KVqsrD2=
pm__UmJPtGaW9C9junx1RpnH_->mX;int32_T*mc_SheEjf_3lOXDmgzkmhMGG2=
mc_kmcnrlTt6IvFH5HSoyHe21->mX;;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_UcQ91Wou1NlJm_M1J1BSo1;mc_SmSSPSQfR1qEYWsVj5ELF0
++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_ET9_5EAP116KvP5KVqsrD2[
mc_SheEjf_3lOXDmgzkmhMGG2[mc_SmSSPSQfR1qEYWsVj5ELF0]];}}static void
mc_dyf2K4fbGz8RaiAo_5C_e2(int32_T*pm_JMQ_js3toioP0_0hj_fm5_,int32_T
mc_SmSSPSQfR1qEYWsVj5ELF0,int32_T mc_OUB2pptsvtdGL_LyqpgOa0){int32_T
mc_U938Ucreg_Pd41Eh8sAbX1;mc_U938Ucreg_Pd41Eh8sAbX1=pm_JMQ_js3toioP0_0hj_fm5_[
mc_SmSSPSQfR1qEYWsVj5ELF0];pm_JMQ_js3toioP0_0hj_fm5_[mc_SmSSPSQfR1qEYWsVj5ELF0
]=pm_JMQ_js3toioP0_0hj_fm5_[mc_OUB2pptsvtdGL_LyqpgOa0];
pm_JMQ_js3toioP0_0hj_fm5_[mc_OUB2pptsvtdGL_LyqpgOa0]=mc_U938Ucreg_Pd41Eh8sAbX1
;}static void mc_MvEN3VZm4ygiK2JIXtMPq2(int32_T*pm_JMQ_js3toioP0_0hj_fm5_,
int32_T mc_Z54JbeVS6g2FaSJpzTnPz_,int32_T mc_tXMARIq5F6Jl9Ic2QNtH50){int32_T
mc_SmSSPSQfR1qEYWsVj5ELF0,mc_0M_nindHJeXi30f_iWwGL0;if(
mc_Z54JbeVS6g2FaSJpzTnPz_>=mc_tXMARIq5F6Jl9Ic2QNtH50){return;}
mc_dyf2K4fbGz8RaiAo_5C_e2(pm_JMQ_js3toioP0_0hj_fm5_,mc_Z54JbeVS6g2FaSJpzTnPz_,
(mc_Z54JbeVS6g2FaSJpzTnPz_+mc_tXMARIq5F6Jl9Ic2QNtH50)/2);
mc_0M_nindHJeXi30f_iWwGL0=mc_Z54JbeVS6g2FaSJpzTnPz_;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=mc_Z54JbeVS6g2FaSJpzTnPz_+1;
mc_SmSSPSQfR1qEYWsVj5ELF0<=mc_tXMARIq5F6Jl9Ic2QNtH50;mc_SmSSPSQfR1qEYWsVj5ELF0
++){if(pm_JMQ_js3toioP0_0hj_fm5_[mc_SmSSPSQfR1qEYWsVj5ELF0]<
pm_JMQ_js3toioP0_0hj_fm5_[mc_Z54JbeVS6g2FaSJpzTnPz_]){
mc_dyf2K4fbGz8RaiAo_5C_e2(pm_JMQ_js3toioP0_0hj_fm5_,++
mc_0M_nindHJeXi30f_iWwGL0,mc_SmSSPSQfR1qEYWsVj5ELF0);}}
mc_dyf2K4fbGz8RaiAo_5C_e2(pm_JMQ_js3toioP0_0hj_fm5_,mc_Z54JbeVS6g2FaSJpzTnPz_,
mc_0M_nindHJeXi30f_iWwGL0);mc_MvEN3VZm4ygiK2JIXtMPq2(pm_JMQ_js3toioP0_0hj_fm5_
,mc_Z54JbeVS6g2FaSJpzTnPz_,mc_0M_nindHJeXi30f_iWwGL0-1);
mc_MvEN3VZm4ygiK2JIXtMPq2(pm_JMQ_js3toioP0_0hj_fm5_,mc_0M_nindHJeXi30f_iWwGL0+
1,mc_tXMARIq5F6Jl9Ic2QNtH50);}void mc_mMmDjYPdSIEEQHj__7cd71(const PmIntVector
*pm_JMQ_js3toioP0_0hj_fm5_){size_t mc_UcQ91Wou1NlJm_M1J1BSo1=
pm_JMQ_js3toioP0_0hj_fm5_->mN;int32_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;
mc_MvEN3VZm4ygiK2JIXtMPq2(x,0,(int32_T)(mc_UcQ91Wou1NlJm_M1J1BSo1-1));}void
mc_zYvj4jole4TnufsPoZWW_2(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const PmBoolVector*
mc_i34rFP0sHa_dTbFseidcw0){size_t mc_UcQ91Wou1NlJm_M1J1BSo1=
pm_JMQ_js3toioP0_0hj_fm5_->mN;size_t mc_AoR8_FAMCEiy8t3uUiudM2=
pm__UmJPtGaW9C9junx1RpnH_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,
mc_yrT_cAWVfAhvXNLD9hpDQ1=0;int32_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;int32_T*
mc_ET9_5EAP116KvP5KVqsrD2=pm__UmJPtGaW9C9junx1RpnH_->mX;boolean_T*
mc_nG9lEleqRQ___s_o0rpbM2=mc_i34rFP0sHa_dTbFseidcw0->mX;;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=mc_yrT_cAWVfAhvXNLD9hpDQ1=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_AoR8_FAMCEiy8t3uUiudM2;mc_SmSSPSQfR1qEYWsVj5ELF0
++){if(mc_nG9lEleqRQ___s_o0rpbM2[mc_SmSSPSQfR1qEYWsVj5ELF0]==true){x[
mc_yrT_cAWVfAhvXNLD9hpDQ1]=mc_ET9_5EAP116KvP5KVqsrD2[mc_SmSSPSQfR1qEYWsVj5ELF0
];mc_yrT_cAWVfAhvXNLD9hpDQ1++;}}}void mc_TJe2EtJyyhfHpuJYOjxfC0(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_,boolean_T mc_7lBL31aWjgSfMHGQtksob2){size_t n=
pm__UmJPtGaW9C9junx1RpnH_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;int32_T*
mc_ET9_5EAP116KvP5KVqsrD2=pm__UmJPtGaW9C9junx1RpnH_->mX;int32_T*x=
pm_JMQ_js3toioP0_0hj_fm5_->mX;int32_T mc_aQ4XejppzgVZPWRfV7wEz1=0;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){if(mc_7lBL31aWjgSfMHGQtksob2){
mc_aQ4XejppzgVZPWRfV7wEz1+=mc_ET9_5EAP116KvP5KVqsrD2[mc_SmSSPSQfR1qEYWsVj5ELF0
];}x[mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_aQ4XejppzgVZPWRfV7wEz1;if(!
mc_7lBL31aWjgSfMHGQtksob2){mc_aQ4XejppzgVZPWRfV7wEz1+=
mc_ET9_5EAP116KvP5KVqsrD2[mc_SmSSPSQfR1qEYWsVj5ELF0];}}}void
mc_si_irLJWyQLY_l4tqebAe_(const PmIntVector*mc_rxT7_6KqJcx5sNYEWRALX2,int32_T
mc_RGllRMvIRPGkpbvuetJlO2){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=
mc_rxT7_6KqJcx5sNYEWRALX2->mN;int32_T*x=mc_rxT7_6KqJcx5sNYEWRALX2->mX;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]+=
mc_RGllRMvIRPGkpbvuetJlO2;}}void mc_SKE1EUStKD_KtRTTXrxqv2(const PmBoolVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmBoolVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32){size_t mc_MXQeXSu_MWFOwfbChjq0w_=
mc_9_yWAFd98YjxIPCHmG5rr0->mN;size_t mc_pUjRTsp47EHBscIpj7Ulg0=
mc_Ds0gTsuf_v_EnBO9LqpvK_->mN;;;if(mc_QHNSjd8JBrVVYZAcs7Zm32>0){memcpy(
mc_9_yWAFd98YjxIPCHmG5rr0->mX+mc__VPpmCt_TuqLdOtTsmwgk2,
mc_Ds0gTsuf_v_EnBO9LqpvK_->mX+mc_947YwtWZMq1Crv_q1N3191,
mc_QHNSjd8JBrVVYZAcs7Zm32*sizeof(boolean_T));}}void mc_OT_v_IC_x9R85Z4eHn1jA0(
const PmRealVector*mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,
const PmRealVector*mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,
size_t mc_QHNSjd8JBrVVYZAcs7Zm32){size_t mc_MXQeXSu_MWFOwfbChjq0w_=
mc_9_yWAFd98YjxIPCHmG5rr0->mN;size_t mc_pUjRTsp47EHBscIpj7Ulg0=
mc_Ds0gTsuf_v_EnBO9LqpvK_->mN;;;if(mc_QHNSjd8JBrVVYZAcs7Zm32>0){memcpy(
mc_9_yWAFd98YjxIPCHmG5rr0->mX+mc__VPpmCt_TuqLdOtTsmwgk2,
mc_Ds0gTsuf_v_EnBO9LqpvK_->mX+mc_947YwtWZMq1Crv_q1N3191,
mc_QHNSjd8JBrVVYZAcs7Zm32*sizeof(real_T));}}void mc_J9HotRGeuZtxiip_GSZPb0(
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_){size_t n=pm__UmJPtGaW9C9junx1RpnH_->mN;;if(n>0){
memcpy(pm_JMQ_js3toioP0_0hj_fm5_->mX,pm__UmJPtGaW9C9junx1RpnH_->mX,n*sizeof(
real_T));}}size_t mc_lp5J2bZ8EcxnhyI1PKPZd2(const PmBoolVector*
mc_G15g52JPQFeDaEm_uJadW_){size_t mc_t0fiNNv2eaRsuMkKmBGaM_=0,
mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=mc_G15g52JPQFeDaEm_uJadW_->mN;const boolean_T*
mc_qxmrDXxPOfxekciiowUyB2=mc_G15g52JPQFeDaEm_uJadW_->mX;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=mc_t0fiNNv2eaRsuMkKmBGaM_=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
mc_qxmrDXxPOfxekciiowUyB2[mc_SmSSPSQfR1qEYWsVj5ELF0]==true){
mc_t0fiNNv2eaRsuMkKmBGaM_++;}}return mc_t0fiNNv2eaRsuMkKmBGaM_;}void
mc__xr97Mh4VU4bdE2CcyEVf_(const PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,const
PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_){int32_T*mc__cd08z0VIw72xfAEJaTa6_=
mc_YwEOIpm092vI_BA0rQzvJ2->mX;size_t mc_4vn8IVCVVW1oVUlqcKzI31=
mc_YwEOIpm092vI_BA0rQzvJ2->mN;boolean_T*b=mc_AV_LMGONnBUCahwCg3D4y_->mX;size_t
mc_j_SD_sgtshphDEvI4jhBO_=mc_AV_LMGONnBUCahwCg3D4y_->mN;size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0,mc_yrT_cAWVfAhvXNLD9hpDQ1=0;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=mc_yrT_cAWVfAhvXNLD9hpDQ1=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_j_SD_sgtshphDEvI4jhBO_;mc_SmSSPSQfR1qEYWsVj5ELF0
++){if(b[mc_SmSSPSQfR1qEYWsVj5ELF0]==true){mc__cd08z0VIw72xfAEJaTa6_[
mc_yrT_cAWVfAhvXNLD9hpDQ1]=((int32_T)(mc_SmSSPSQfR1qEYWsVj5ELF0));
mc_yrT_cAWVfAhvXNLD9hpDQ1++;}};}size_t mc_pdD80p5I4a4oDKki08oZ50(const
PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0){size_t mc_StaWXlpOQ6SIJ4_O8yBVR2=0,
mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=mc_kI6kqxnpJaUqvLfVbMkdr0->mN;const int32_T*
mc_lbQdH7Tm5Tc88ILxyGB9r_=mc_kI6kqxnpJaUqvLfVbMkdr0->mX;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=mc_StaWXlpOQ6SIJ4_O8yBVR2=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
mc_lbQdH7Tm5Tc88ILxyGB9r_[mc_SmSSPSQfR1qEYWsVj5ELF0]!=0){
mc_StaWXlpOQ6SIJ4_O8yBVR2++;}}return mc_StaWXlpOQ6SIJ4_O8yBVR2;}size_t
mc_a_dd0x8Rstf0HD74BJt9A2(const PmRealVector*mc_ZxltZcnt1eSoyJTnrOm7z2){size_t
mc_StaWXlpOQ6SIJ4_O8yBVR2=0,mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=
mc_ZxltZcnt1eSoyJTnrOm7z2->mN;const real_T*x=mc_ZxltZcnt1eSoyJTnrOm7z2->mX;for
(mc_SmSSPSQfR1qEYWsVj5ELF0=mc_StaWXlpOQ6SIJ4_O8yBVR2=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(x[
mc_SmSSPSQfR1qEYWsVj5ELF0]!=0.0){mc_StaWXlpOQ6SIJ4_O8yBVR2++;}}return
mc_StaWXlpOQ6SIJ4_O8yBVR2;}size_t mc_8u8_LRBN9SbcEOkeum7ag0(const PmBoolVector
*mc_ZxltZcnt1eSoyJTnrOm7z2){size_t mc_StaWXlpOQ6SIJ4_O8yBVR2=0,
mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=mc_ZxltZcnt1eSoyJTnrOm7z2->mN;const boolean_T*x=
mc_ZxltZcnt1eSoyJTnrOm7z2->mX;for(mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_StaWXlpOQ6SIJ4_O8yBVR2=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){if(x[mc_SmSSPSQfR1qEYWsVj5ELF0]){
mc_StaWXlpOQ6SIJ4_O8yBVR2++;}}return mc_StaWXlpOQ6SIJ4_O8yBVR2;}boolean_T
mc_Ukc2BYyTIIZDpb_lFOWTt0(const PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=mc_kI6kqxnpJaUqvLfVbMkdr0->mN;const int32_T*
mc_lbQdH7Tm5Tc88ILxyGB9r_=mc_kI6kqxnpJaUqvLfVbMkdr0->mX;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){if(mc_lbQdH7Tm5Tc88ILxyGB9r_[
mc_SmSSPSQfR1qEYWsVj5ELF0]!=0){return true;}}return false;}boolean_T
mc_l26oJh0UM_xwSgKIeOC5J0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,int32_T
mc_RGllRMvIRPGkpbvuetJlO2){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
pm_JMQ_js3toioP0_0hj_fm5_->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]==
mc_RGllRMvIRPGkpbvuetJlO2){return true;}}return false;}boolean_T
mc_ocDPr6f6C4_v9b5NDj8JH_(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T
mc_RGllRMvIRPGkpbvuetJlO2){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
pm_JMQ_js3toioP0_0hj_fm5_->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]==
mc_RGllRMvIRPGkpbvuetJlO2){return true;}}return false;}void
mc_fuQc8C9CyCuf_KkBLV8eb0(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*mc__y3ODgPUeYQZuqCAqWV3P2=
pm_JMQ_js3toioP0_0hj_fm5_->mX;const real_T*mc_MDk6FkOvgJ0bCXzpQOq1B_=
pm__UmJPtGaW9C9junx1RpnH_->mX;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc__y3ODgPUeYQZuqCAqWV3P2[mc_SmSSPSQfR1qEYWsVj5ELF0]+=
mc_MDk6FkOvgJ0bCXzpQOq1B_[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_8BTcsQ6C8h5zrW1ZQRhKf1(const PmRealVector*x,real_T mc_ljExW6hRw43Vg4SLQUAvT1
){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<x->mN;++mc_SmSSPSQfR1qEYWsVj5ELF0){x->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]+=mc_ljExW6hRw43Vg4SLQUAvT1;}}void
mc_fjtK_RGCYgp34_TjPN6zv1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*mc__y3ODgPUeYQZuqCAqWV3P2=
pm_JMQ_js3toioP0_0hj_fm5_->mX;const real_T*mc_MDk6FkOvgJ0bCXzpQOq1B_=
pm__UmJPtGaW9C9junx1RpnH_->mX;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc__y3ODgPUeYQZuqCAqWV3P2[mc_SmSSPSQfR1qEYWsVj5ELF0]-=
mc_MDk6FkOvgJ0bCXzpQOq1B_[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_W0fX8K54ez0qAgM9tXjsi_(const PmRealVector*x,const PmRealVector*
mc_ET9_5EAP116KvP5KVqsrD2){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,n=x->mN;real_T*
mc_FjBwsPbRbUUX8Bp7zbTYi0=x->mX;const real_T*mc_JCHbIKrhrQJ0XeuZ26BB1_=
mc_ET9_5EAP116KvP5KVqsrD2->mX;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_FjBwsPbRbUUX8Bp7zbTYi0[mc_SmSSPSQfR1qEYWsVj5ELF0]=fabs(
mc_JCHbIKrhrQJ0XeuZ26BB1_[mc_SmSSPSQfR1qEYWsVj5ELF0]);}}void
mc_fIL9UyKjuKeUlnGmcXq5r2(const PmRealVector*x,const PmRealVector*
mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*mc_SheEjf_3lOXDmgzkmhMGG2){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;size_t n=x->mN;real_T*mc_FjBwsPbRbUUX8Bp7zbTYi0=x
->mX;const real_T*mc_JCHbIKrhrQJ0XeuZ26BB1_=mc_ET9_5EAP116KvP5KVqsrD2->mX;
const real_T*mc_Hz_DyBfKyURt673AYYC7Q_=mc_SheEjf_3lOXDmgzkmhMGG2->mX;;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_FjBwsPbRbUUX8Bp7zbTYi0[
mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_JCHbIKrhrQJ0XeuZ26BB1_[mc_SmSSPSQfR1qEYWsVj5ELF0
]-mc_Hz_DyBfKyURt673AYYC7Q_[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_v7V5uZPqLRlsEpMCWsoMJ0(const PmRealVector*x,const real_T a,const
PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=x->
mN;real_T*mc_FjBwsPbRbUUX8Bp7zbTYi0=x->mX;const real_T*
mc_JCHbIKrhrQJ0XeuZ26BB1_=mc_ET9_5EAP116KvP5KVqsrD2->mX;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_FjBwsPbRbUUX8Bp7zbTYi0[
mc_SmSSPSQfR1qEYWsVj5ELF0]=a*mc_JCHbIKrhrQJ0XeuZ26BB1_[
mc_SmSSPSQfR1qEYWsVj5ELF0];}}void mc_LlLyVwCApgTvSBfIvzOuk0(const PmRealVector
*x,real_T a,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0,n=x->mN;real_T*mc_FjBwsPbRbUUX8Bp7zbTYi0=x->mX;const
real_T*mc_JCHbIKrhrQJ0XeuZ26BB1_=mc_ET9_5EAP116KvP5KVqsrD2->mX;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_FjBwsPbRbUUX8Bp7zbTYi0[
mc_SmSSPSQfR1qEYWsVj5ELF0]+=(a*mc_JCHbIKrhrQJ0XeuZ26BB1_[
mc_SmSSPSQfR1qEYWsVj5ELF0]);}}void mc_DnL_y_DaeSoRsDtnK0hpB1(const PmRealVector
*x,const real_T mc_8IKoYx3qsjeiwHerWlCOS1){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
x->mN;real_T*mc_FjBwsPbRbUUX8Bp7zbTYi0=x->mX;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_FjBwsPbRbUUX8Bp7zbTYi0[mc_SmSSPSQfR1qEYWsVj5ELF0]*=
mc_8IKoYx3qsjeiwHerWlCOS1;}}void mc_I_W_409sg28ysFYlBfPcr_(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const real_T mc_8IKoYx3qsjeiwHerWlCOS1){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0,n=pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*
mc__y3ODgPUeYQZuqCAqWV3P2=pm_JMQ_js3toioP0_0hj_fm5_->mX;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc__y3ODgPUeYQZuqCAqWV3P2[
mc_SmSSPSQfR1qEYWsVj5ELF0]/=mc_8IKoYx3qsjeiwHerWlCOS1;}}void
mc_MI5F4RaYNQR7pPk1GRkvn_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;int32_T*mc_Vx2sUrke7IMHneHjPaOc00=
pm_JMQ_js3toioP0_0hj_fm5_->mX;int32_T*mc_qZSg8HcYEvZ65sCP8Ra_e_=
pm__UmJPtGaW9C9junx1RpnH_->mX;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_Vx2sUrke7IMHneHjPaOc00[mc_SmSSPSQfR1qEYWsVj5ELF0]*=
mc_qZSg8HcYEvZ65sCP8Ra_e_[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_lkC6x3YtrvW6L16S6aM60_(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*mc_Vx2sUrke7IMHneHjPaOc00=
pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T*mc_qZSg8HcYEvZ65sCP8Ra_e_=
pm__UmJPtGaW9C9junx1RpnH_->mX;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_Vx2sUrke7IMHneHjPaOc00[mc_SmSSPSQfR1qEYWsVj5ELF0]*=
mc_qZSg8HcYEvZ65sCP8Ra_e_[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_vfuXLuRk3KtAfbvK_cTrv2(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*mc_Vx2sUrke7IMHneHjPaOc00=
pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T*mc_qZSg8HcYEvZ65sCP8Ra_e_=
pm__UmJPtGaW9C9junx1RpnH_->mX;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){;
mc_Vx2sUrke7IMHneHjPaOc00[mc_SmSSPSQfR1qEYWsVj5ELF0]/=
mc_qZSg8HcYEvZ65sCP8Ra_e_[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_tOKZMGNlSqK650YhjgeKv0(const PmRealVector*mc_9JsNfMLIQx0SlNuEaL4I2_,real_T
mc_8IKoYx3qsjeiwHerWlCOS1){real_T*x=mc_9JsNfMLIQx0SlNuEaL4I2_->mX;size_t n=
mc_9JsNfMLIQx0SlNuEaL4I2_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]=
mc_8IKoYx3qsjeiwHerWlCOS1;}}void mc_Uy10YSjkY75ViJd9dTdYI1(const PmBoolVector*
mc_9JsNfMLIQx0SlNuEaL4I2_){boolean_T*x=mc_9JsNfMLIQx0SlNuEaL4I2_->mX;size_t n=
mc_9JsNfMLIQx0SlNuEaL4I2_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]=(x[
mc_SmSSPSQfR1qEYWsVj5ELF0]==false)?true:false;}}void mc_Rhhlgu4QH_WTKd_5kpe4I2
(const PmRealVector*mc_9JsNfMLIQx0SlNuEaL4I2_){real_T*x=
mc_9JsNfMLIQx0SlNuEaL4I2_->mX;size_t n=mc_9JsNfMLIQx0SlNuEaL4I2_->mN;if(n>0){
memset(x,0,n*sizeof(real_T));}}void mc_nLc17gFNFcvBlJrwxJV4w_(const PmIntVector
*pm_JMQ_js3toioP0_0hj_fm5_){int32_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;size_t n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]=(int32_T)
mc_SmSSPSQfR1qEYWsVj5ELF0;}}void mc_WmHTznO_Ih_dJw_MhKtIQ1(const PmIntVector*
mc_9JsNfMLIQx0SlNuEaL4I2_,int32_T mc_RGllRMvIRPGkpbvuetJlO2){int32_T*x=
mc_9JsNfMLIQx0SlNuEaL4I2_->mX;size_t n=mc_9JsNfMLIQx0SlNuEaL4I2_->mN;size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){x[
mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_RGllRMvIRPGkpbvuetJlO2;}}void
mc_W7kR8viSTKC_By0UjXE_A1(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_){int32_T
*x=mc_9JsNfMLIQx0SlNuEaL4I2_->mX;size_t n=mc_9JsNfMLIQx0SlNuEaL4I2_->mN;if(n>0
){memset(x,0,n*sizeof(int32_T));}}void mc_AQtCbBjZ792h1_Xaj_dR92(const
PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0,const PmIntVector*
mc_YwEOIpm092vI_BA0rQzvJ2,boolean_T mc_8IKoYx3qsjeiwHerWlCOS1){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;size_t mc_uMdZIz56rnIMxw_D6SeuT0=
mc_YwEOIpm092vI_BA0rQzvJ2->mN;size_t mc_9w3dXfANdQnxyVvG2_Zs12=
mc_i34rFP0sHa_dTbFseidcw0->mN;int32_T*mc_WYUsvQBAVM99wBhxK_oqN0=
mc_YwEOIpm092vI_BA0rQzvJ2->mX;boolean_T*mc_n3sLXMPiodmQq7v5_hR6H2=
mc_i34rFP0sHa_dTbFseidcw0->mX;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_uMdZIz56rnIMxw_D6SeuT0;mc_SmSSPSQfR1qEYWsVj5ELF0
++){;mc_n3sLXMPiodmQq7v5_hR6H2[mc_WYUsvQBAVM99wBhxK_oqN0[
mc_SmSSPSQfR1qEYWsVj5ELF0]]=mc_8IKoYx3qsjeiwHerWlCOS1;}}void
mc_pJmDkwzzX3Iu6_VR_MyvL_(const PmBoolVector*mc_Hf_a_gs1wyoHoosYiGonU0,const
PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_YwEOIpm092vI_BA0rQzvJ2){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;size_t
mc_uMdZIz56rnIMxw_D6SeuT0=mc_YwEOIpm092vI_BA0rQzvJ2->mN;const int32_T*
mc_WYUsvQBAVM99wBhxK_oqN0=mc_YwEOIpm092vI_BA0rQzvJ2->mX;boolean_T*
mc__ufenpgxU3uuzynJdjZhJ1=mc_Hf_a_gs1wyoHoosYiGonU0->mX;const boolean_T*
mc_v1kc7h4iawvVowQOSKW021=mc_AV_LMGONnBUCahwCg3D4y_->mX;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_uMdZIz56rnIMxw_D6SeuT0;mc_SmSSPSQfR1qEYWsVj5ELF0++){;
mc__ufenpgxU3uuzynJdjZhJ1[mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_v1kc7h4iawvVowQOSKW021
[mc_WYUsvQBAVM99wBhxK_oqN0[mc_SmSSPSQfR1qEYWsVj5ELF0]];}}void
mc_tLxHiRii5tbHWjrunaI2i1(const PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_,
boolean_T mc_8IKoYx3qsjeiwHerWlCOS1){boolean_T*x=mc_9JsNfMLIQx0SlNuEaL4I2_->mX
;size_t n=mc_9JsNfMLIQx0SlNuEaL4I2_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;for
(mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){x[mc_SmSSPSQfR1qEYWsVj5ELF0]=
mc_8IKoYx3qsjeiwHerWlCOS1;}}void mc_AZRifAjle326aZku91XJU2(const PmBoolVector*
mc_9JsNfMLIQx0SlNuEaL4I2_){boolean_T*x=mc_9JsNfMLIQx0SlNuEaL4I2_->mX;size_t n=
mc_9JsNfMLIQx0SlNuEaL4I2_->mN;if(n>0){memset(x,0,n*sizeof(boolean_T));}}void
mc_mGD4FL6_MDLg2bdqzdpfx_(const PmBoolVector*x,size_t mc_SmSSPSQfR1qEYWsVj5ELF0
,size_t mc_QHNSjd8JBrVVYZAcs7Zm32){;if(mc_QHNSjd8JBrVVYZAcs7Zm32>0){memset(x->
mX+mc_SmSSPSQfR1qEYWsVj5ELF0,0,mc_QHNSjd8JBrVVYZAcs7Zm32*sizeof(boolean_T));}}
void mc_x2bRmxKlHWAMEwOZuiA_62(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_){size_t n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;boolean_T*
mc_OI6G61_JNe4A2dfwPtv0e1=pm_JMQ_js3toioP0_0hj_fm5_->mX;boolean_T*
mc_oBr0VobcvsoaKGeqAujWW1=pm__UmJPtGaW9C9junx1RpnH_->mX;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_OI6G61_JNe4A2dfwPtv0e1[
mc_SmSSPSQfR1qEYWsVj5ELF0]|=mc_oBr0VobcvsoaKGeqAujWW1[
mc_SmSSPSQfR1qEYWsVj5ELF0];}}void mc_eJ9VFRIFMWxO52_BT7X_C_(const PmBoolVector
*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_){
size_t n=pm_JMQ_js3toioP0_0hj_fm5_->mN;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;
boolean_T*mc_OI6G61_JNe4A2dfwPtv0e1=pm_JMQ_js3toioP0_0hj_fm5_->mX;boolean_T*
mc_oBr0VobcvsoaKGeqAujWW1=pm__UmJPtGaW9C9junx1RpnH_->mX;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_OI6G61_JNe4A2dfwPtv0e1[
mc_SmSSPSQfR1qEYWsVj5ELF0]&=mc_oBr0VobcvsoaKGeqAujWW1[
mc_SmSSPSQfR1qEYWsVj5ELF0];}}real_T mc_WJAbbKueqClxuItYQx7b61(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_){size_t mc_SmSSPSQfR1qEYWsVj5ELF0,n=
pm_JMQ_js3toioP0_0hj_fm5_->mN;real_T*mc__y3ODgPUeYQZuqCAqWV3P2=
pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T mc__ujxrncktQZilZzTUuVF32,
mc_lGrwWW0ERg3PEZB3txbfw2=0.0;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc__ujxrncktQZilZzTUuVF32=mc__y3ODgPUeYQZuqCAqWV3P2[mc_SmSSPSQfR1qEYWsVj5ELF0]
;mc_lGrwWW0ERg3PEZB3txbfw2+=mc__ujxrncktQZilZzTUuVF32*
mc__ujxrncktQZilZzTUuVF32;}mc_lGrwWW0ERg3PEZB3txbfw2=sqrt(
mc_lGrwWW0ERg3PEZB3txbfw2);return mc_lGrwWW0ERg3PEZB3txbfw2;}real_T
mc_TuU8NakpY91qxLM4is2wV2(const PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;size_t n=pm_VmBquL1cTEkIgP0cS5pM82->mN;real_T*
mc_RND97jNka2s3AHKx9kRjR_=pm_VmBquL1cTEkIgP0cS5pM82->mX;real_T
mc_WsaFNbC36NQ_qr6OJLi110=0.0;;mc_WsaFNbC36NQ_qr6OJLi110=
mc_RND97jNka2s3AHKx9kRjR_[0];for(mc_SmSSPSQfR1qEYWsVj5ELF0=1;
mc_SmSSPSQfR1qEYWsVj5ELF0<n;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
mc_RND97jNka2s3AHKx9kRjR_[mc_SmSSPSQfR1qEYWsVj5ELF0]>mc_WsaFNbC36NQ_qr6OJLi110
){mc_WsaFNbC36NQ_qr6OJLi110=mc_RND97jNka2s3AHKx9kRjR_[
mc_SmSSPSQfR1qEYWsVj5ELF0];}}return mc_WsaFNbC36NQ_qr6OJLi110;}int32_T
mc_dLmR9a64iWQBHX4QM5zCr2(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0,mc_AnS7Y4euB5dEkvfZmgB7x_=0;size_t n=
pm_VmBquL1cTEkIgP0cS5pM82->mN;int32_T*mc_RND97jNka2s3AHKx9kRjR_=
pm_VmBquL1cTEkIgP0cS5pM82->mX;for(mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_AnS7Y4euB5dEkvfZmgB7x_=0;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){mc_AnS7Y4euB5dEkvfZmgB7x_+=
mc_RND97jNka2s3AHKx9kRjR_[mc_SmSSPSQfR1qEYWsVj5ELF0];}return((int32_T)(
mc_AnS7Y4euB5dEkvfZmgB7x_));}int32_T mc_eIjmwucqCUJT1PyCl_z5b_(const
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;
size_t n=pm_VmBquL1cTEkIgP0cS5pM82->mN;int32_T*x=pm_VmBquL1cTEkIgP0cS5pM82->mX
;int32_T mc_mcw2tmzlvx0JVQ7wIPEsq2=0;;mc_mcw2tmzlvx0JVQ7wIPEsq2=x[0];for(
mc_SmSSPSQfR1qEYWsVj5ELF0=1;mc_SmSSPSQfR1qEYWsVj5ELF0<n;
mc_SmSSPSQfR1qEYWsVj5ELF0++){if(x[mc_SmSSPSQfR1qEYWsVj5ELF0]>
mc_mcw2tmzlvx0JVQ7wIPEsq2){mc_mcw2tmzlvx0JVQ7wIPEsq2=x[
mc_SmSSPSQfR1qEYWsVj5ELF0];}}return mc_mcw2tmzlvx0JVQ7wIPEsq2;}void
mc_loSQGFba0sjWysbLdmqzS1(PmIntVector*mc_QyVbO3pTvGiccU8Tn2eK2_,const
PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0){size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,
mc_yrT_cAWVfAhvXNLD9hpDQ1=0,mc_NrdrqgDg1bTGTUv4Q14Xb0=
mc_kI6kqxnpJaUqvLfVbMkdr0->mN,mc_lslarBD1qEuEMlPHZWQ_b_=
mc_QyVbO3pTvGiccU8Tn2eK2_->mN;int32_T*mc_kanR3Ftqix3swlefDSfo8_=
mc_QyVbO3pTvGiccU8Tn2eK2_->mX,*mc_WAi_AbOQTQBeSNDGwSOJx0=
mc_kI6kqxnpJaUqvLfVbMkdr0->mX;for(mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_yrT_cAWVfAhvXNLD9hpDQ1=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_NrdrqgDg1bTGTUv4Q14Xb0;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
mc_WAi_AbOQTQBeSNDGwSOJx0[mc_SmSSPSQfR1qEYWsVj5ELF0]!=0){;
mc_kanR3Ftqix3swlefDSfo8_[mc_yrT_cAWVfAhvXNLD9hpDQ1]=((int32_T)(
mc_SmSSPSQfR1qEYWsVj5ELF0));mc_yrT_cAWVfAhvXNLD9hpDQ1++;}}
mc_QyVbO3pTvGiccU8Tn2eK2_->mN=mc_yrT_cAWVfAhvXNLD9hpDQ1;}void
mc_O_flPmjeFB4ZmON9Xp2iV_(PmRealVector*mc_EBUUePJ08d2hXtTa8LU0J_,const
PmRealVector*mc_23nxQONnTNHWizowC7lIt0,const PmSparsityPattern*
mc_UYX2aVqEUCl0fW5_qT4Lo1){int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_UYX2aVqEUCl0fW5_qT4Lo1->mJc;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0,
mc_wpM2BH4ZgIGett_8VFoUR_=mc_UYX2aVqEUCl0fW5_qT4Lo1->mNumCol;int32_T
mc_OUB2pptsvtdGL_LyqpgOa0=0;real_T mc_xRNm677zEqIwmhpz865GP1=0.0,
mc_fHGAwl75v1iA5tNpm_GDs0;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_wpM2BH4ZgIGett_8VFoUR_;mc_SmSSPSQfR1qEYWsVj5ELF0
++){mc_xRNm677zEqIwmhpz865GP1=0.0;for(mc_OUB2pptsvtdGL_LyqpgOa0=
mc_S51jjFL079S8kdC86krPC0[mc_SmSSPSQfR1qEYWsVj5ELF0];mc_OUB2pptsvtdGL_LyqpgOa0
<mc_S51jjFL079S8kdC86krPC0[mc_SmSSPSQfR1qEYWsVj5ELF0+1];
mc_OUB2pptsvtdGL_LyqpgOa0++){mc_fHGAwl75v1iA5tNpm_GDs0=fabs(
mc_23nxQONnTNHWizowC7lIt0->mX[mc_OUB2pptsvtdGL_LyqpgOa0]);if(
mc_fHGAwl75v1iA5tNpm_GDs0>mc_xRNm677zEqIwmhpz865GP1){mc_xRNm677zEqIwmhpz865GP1
=mc_fHGAwl75v1iA5tNpm_GDs0;}}mc_EBUUePJ08d2hXtTa8LU0J_->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_xRNm677zEqIwmhpz865GP1;}}void
mc_K1ezq3TzhoNUE_SEp0Dr12(const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_){size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;size_t
mc_YB5Rsam2TX_DDukUFvfrh_=mc_73ubi6fCtM2UVxkG602gl0->mNumCol;int32_T
mc_SmSSPSQfR1qEYWsVj5ELF0=0;int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*mc_rX2Nhyrokuq9JmnRvEAkJ1=
mc_73ubi6fCtM2UVxkG602gl0->mIr;real_T*mc_A1lUr3Ax9HoRb_bkcLe_A1=
mc_kvOR3Cr3RdA0t5JHDRjvp1->mX;real_T*mc_2KOgmJz2fr_KI3PFk4Wj22=
pm_JMQ_js3toioP0_0hj_fm5_->mX;;;for(mc_OUB2pptsvtdGL_LyqpgOa0=0;
mc_OUB2pptsvtdGL_LyqpgOa0<mc_YB5Rsam2TX_DDukUFvfrh_;mc_OUB2pptsvtdGL_LyqpgOa0
++){for(mc_SmSSPSQfR1qEYWsVj5ELF0=mc_S51jjFL079S8kdC86krPC0[
mc_OUB2pptsvtdGL_LyqpgOa0];mc_SmSSPSQfR1qEYWsVj5ELF0<mc_S51jjFL079S8kdC86krPC0
[mc_OUB2pptsvtdGL_LyqpgOa0+1];mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_A1lUr3Ax9HoRb_bkcLe_A1[mc_SmSSPSQfR1qEYWsVj5ELF0]*=
mc_2KOgmJz2fr_KI3PFk4Wj22[mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_SmSSPSQfR1qEYWsVj5ELF0]
];}}}void mc_WuGlfcFda9zO01qKeAxMn_(const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_){size_t mc_wpM2BH4ZgIGett_8VFoUR_=
mc_73ubi6fCtM2UVxkG602gl0->mNumCol;size_t mc_XLDwXv2FCw6lwQmvJo2ni0=
mc_73ubi6fCtM2UVxkG602gl0->mNumRow;size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T*
mc_S51jjFL079S8kdC86krPC0=mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*
mc_rX2Nhyrokuq9JmnRvEAkJ1=mc_73ubi6fCtM2UVxkG602gl0->mIr;int32_T
mc_rxYOIOAUANTezy4ySs_vv1=0;real_T mc_m_Z52Un15z8W9o4hfpz7V0=0.0;real_T*x=
pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T*mc_ET9_5EAP116KvP5KVqsrD2=
pm__UmJPtGaW9C9junx1RpnH_->mX;real_T*mc__lerGssn0Ru_r3kSOzEmI_=
mc_kvOR3Cr3RdA0t5JHDRjvp1->mX;;;;for(mc_OUB2pptsvtdGL_LyqpgOa0=0;
mc_OUB2pptsvtdGL_LyqpgOa0<mc_wpM2BH4ZgIGett_8VFoUR_;mc_OUB2pptsvtdGL_LyqpgOa0
++){mc_m_Z52Un15z8W9o4hfpz7V0=x[mc_OUB2pptsvtdGL_LyqpgOa0];for(
mc_rxYOIOAUANTezy4ySs_vv1=mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_rxYOIOAUANTezy4ySs_vv1<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_rxYOIOAUANTezy4ySs_vv1++){mc_ET9_5EAP116KvP5KVqsrD2[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_rxYOIOAUANTezy4ySs_vv1]]+=
mc_m_Z52Un15z8W9o4hfpz7V0*mc__lerGssn0Ru_r3kSOzEmI_[mc_rxYOIOAUANTezy4ySs_vv1]
;}}}void mc_qEYnRq0Ff87lxOQck1Gqi_(const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const real_T*x){size_t
mc_wpM2BH4ZgIGett_8VFoUR_=mc_73ubi6fCtM2UVxkG602gl0->mNumCol;size_t
mc_XLDwXv2FCw6lwQmvJo2ni0=mc_73ubi6fCtM2UVxkG602gl0->mNumRow;size_t
mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*mc_rX2Nhyrokuq9JmnRvEAkJ1=
mc_73ubi6fCtM2UVxkG602gl0->mIr;int32_T mc_rxYOIOAUANTezy4ySs_vv1=0;real_T
mc_m_Z52Un15z8W9o4hfpz7V0=0.0;real_T*mc_ET9_5EAP116KvP5KVqsrD2=
pm__UmJPtGaW9C9junx1RpnH_->mX;real_T*mc__lerGssn0Ru_r3kSOzEmI_=
mc_kvOR3Cr3RdA0t5JHDRjvp1->mX;;;for(mc_OUB2pptsvtdGL_LyqpgOa0=0;
mc_OUB2pptsvtdGL_LyqpgOa0<mc_wpM2BH4ZgIGett_8VFoUR_;mc_OUB2pptsvtdGL_LyqpgOa0
++){mc_m_Z52Un15z8W9o4hfpz7V0=x[mc_OUB2pptsvtdGL_LyqpgOa0];for(
mc_rxYOIOAUANTezy4ySs_vv1=mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_rxYOIOAUANTezy4ySs_vv1<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_rxYOIOAUANTezy4ySs_vv1++){mc_ET9_5EAP116KvP5KVqsrD2[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_rxYOIOAUANTezy4ySs_vv1]]+=
mc_m_Z52Un15z8W9o4hfpz7V0*mc__lerGssn0Ru_r3kSOzEmI_[mc_rxYOIOAUANTezy4ySs_vv1]
;}}}void mc_SZGAWN4U4XTzc5RKGKSk5_(const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*
mc_2cVF0Ggof80TSRmRbhE8l1,size_t mc_LMkPrnaKcsYHEp0eExPFH1){size_t
mc_wpM2BH4ZgIGett_8VFoUR_=mc_73ubi6fCtM2UVxkG602gl0->mNumCol;size_t
mc_XLDwXv2FCw6lwQmvJo2ni0=mc_73ubi6fCtM2UVxkG602gl0->mNumRow;size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0,mc_OUB2pptsvtdGL_LyqpgOa0=0,
mc_PIqWtbzrbQqv_KS_31HnE2=0,mc_ZTWCJuk2WQHJWsDMYgHtM2=0;real_T*
mc_4zhexXalUvZGukuZerXZ01=NULL;int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*mc_rX2Nhyrokuq9JmnRvEAkJ1=
mc_73ubi6fCtM2UVxkG602gl0->mIr;int32_T mc_rxYOIOAUANTezy4ySs_vv1=0;real_T
mc_m_Z52Un15z8W9o4hfpz7V0=0.0;real_T*mc_ET9_5EAP116KvP5KVqsrD2=
pm__UmJPtGaW9C9junx1RpnH_->mX;real_T*mc__lerGssn0Ru_r3kSOzEmI_=
mc_kvOR3Cr3RdA0t5JHDRjvp1->mX;;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_LMkPrnaKcsYHEp0eExPFH1;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc_4zhexXalUvZGukuZerXZ01=mc_2cVF0Ggof80TSRmRbhE8l1[mc_SmSSPSQfR1qEYWsVj5ELF0]
.mX;mc_ZTWCJuk2WQHJWsDMYgHtM2=mc_2cVF0Ggof80TSRmRbhE8l1[
mc_SmSSPSQfR1qEYWsVj5ELF0].mN;for(mc_PIqWtbzrbQqv_KS_31HnE2=0;
mc_PIqWtbzrbQqv_KS_31HnE2<mc_ZTWCJuk2WQHJWsDMYgHtM2;mc_PIqWtbzrbQqv_KS_31HnE2
++,mc_OUB2pptsvtdGL_LyqpgOa0++){mc_m_Z52Un15z8W9o4hfpz7V0=
mc_4zhexXalUvZGukuZerXZ01[mc_PIqWtbzrbQqv_KS_31HnE2];for(
mc_rxYOIOAUANTezy4ySs_vv1=mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_rxYOIOAUANTezy4ySs_vv1<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_rxYOIOAUANTezy4ySs_vv1++){mc_ET9_5EAP116KvP5KVqsrD2[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_rxYOIOAUANTezy4ySs_vv1]]+=
mc_m_Z52Un15z8W9o4hfpz7V0*mc__lerGssn0Ru_r3kSOzEmI_[mc_rxYOIOAUANTezy4ySs_vv1]
;}}};}void mc_FoRQvfcV_dWdjx5L1lyM_0(const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*mc_5LkYradW8mKeL3fLSt9By1){size_t
mc_wpM2BH4ZgIGett_8VFoUR_=mc_73ubi6fCtM2UVxkG602gl0->mNumCol,
mc_XLDwXv2FCw6lwQmvJo2ni0=mc_73ubi6fCtM2UVxkG602gl0->mNumRow,
mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*mc_rX2Nhyrokuq9JmnRvEAkJ1=
mc_73ubi6fCtM2UVxkG602gl0->mIr;int32_T mc_rxYOIOAUANTezy4ySs_vv1=0;real_T
mc_m_Z52Un15z8W9o4hfpz7V0=0.0;real_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T*
mc_ET9_5EAP116KvP5KVqsrD2=pm__UmJPtGaW9C9junx1RpnH_->mX;real_T*
mc__lerGssn0Ru_r3kSOzEmI_=mc_kvOR3Cr3RdA0t5JHDRjvp1->mX;real_T*
mc_9vzhxzKknmyaJetRZA1K51=mc_5LkYradW8mKeL3fLSt9By1->mX;;;;;
mc_Rhhlgu4QH_WTKd_5kpe4I2(mc_5LkYradW8mKeL3fLSt9By1);for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_wpM2BH4ZgIGett_8VFoUR_;mc_OUB2pptsvtdGL_LyqpgOa0++){
mc_m_Z52Un15z8W9o4hfpz7V0=x[mc_OUB2pptsvtdGL_LyqpgOa0];for(
mc_rxYOIOAUANTezy4ySs_vv1=mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_rxYOIOAUANTezy4ySs_vv1<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_rxYOIOAUANTezy4ySs_vv1++){mc_9vzhxzKknmyaJetRZA1K51[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_rxYOIOAUANTezy4ySs_vv1]]+=
mc_m_Z52Un15z8W9o4hfpz7V0*mc__lerGssn0Ru_r3kSOzEmI_[mc_rxYOIOAUANTezy4ySs_vv1]
;}}for(mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_XLDwXv2FCw6lwQmvJo2ni0;mc_OUB2pptsvtdGL_LyqpgOa0++){
mc_ET9_5EAP116KvP5KVqsrD2[mc_OUB2pptsvtdGL_LyqpgOa0]+=
mc_9vzhxzKknmyaJetRZA1K51[mc_OUB2pptsvtdGL_LyqpgOa0];}
mc_Rhhlgu4QH_WTKd_5kpe4I2(mc_5LkYradW8mKeL3fLSt9By1);}void
mc_lBp5wbXG7AvQ3hxoerNOW_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_){size_t
mc_wpM2BH4ZgIGett_8VFoUR_=mc_73ubi6fCtM2UVxkG602gl0->mNumCol;size_t
mc_XLDwXv2FCw6lwQmvJo2ni0=mc_73ubi6fCtM2UVxkG602gl0->mNumRow;size_t
mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*mc_rX2Nhyrokuq9JmnRvEAkJ1=
mc_73ubi6fCtM2UVxkG602gl0->mIr;int32_T mc_rxYOIOAUANTezy4ySs_vv1=0;real_T
mc_m_Z52Un15z8W9o4hfpz7V0=0.0;real_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;real_T*
mc_ET9_5EAP116KvP5KVqsrD2=pm__UmJPtGaW9C9junx1RpnH_->mX;real_T*
mc__lerGssn0Ru_r3kSOzEmI_=mc_kvOR3Cr3RdA0t5JHDRjvp1->mX;;;;for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_wpM2BH4ZgIGett_8VFoUR_;mc_OUB2pptsvtdGL_LyqpgOa0++){
mc_m_Z52Un15z8W9o4hfpz7V0=x[mc_OUB2pptsvtdGL_LyqpgOa0];for(
mc_rxYOIOAUANTezy4ySs_vv1=mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_rxYOIOAUANTezy4ySs_vv1<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_rxYOIOAUANTezy4ySs_vv1++){mc_ET9_5EAP116KvP5KVqsrD2[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_rxYOIOAUANTezy4ySs_vv1]]+=
mc_m_Z52Un15z8W9o4hfpz7V0*fabs(mc__lerGssn0Ru_r3kSOzEmI_[
mc_rxYOIOAUANTezy4ySs_vv1]);}}}void mc_z041e_QXd3uR2ef2CH37s1(const
PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_0R8y9UtrLk3busEbM65xW_,const PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,
size_t mc_OUB2pptsvtdGL_LyqpgOa0,real_T mc_8IKoYx3qsjeiwHerWlCOS1){int32_T*
mc_Fs32gTLWwQAW_CGEpzznN2=mc__aqwF2UeMrHkDfRgGhMkr0->mIr;int32_T*
mc_sGGHC6VUhez6_bHt0sSzC1=mc__aqwF2UeMrHkDfRgGhMkr0->mJc;real_T*
mc_VJl0i9_HuTjyWEktSFg5z_=mc_0R8y9UtrLk3busEbM65xW_->mX;real_T*
mc_SB4XF236_SL7JmV1plze0_=mc_ET9_5EAP116KvP5KVqsrD2->mX;int32_T
mc_dtnkT1Km5ucMT0rXvotaC2=0;;;;for(mc_dtnkT1Km5ucMT0rXvotaC2=
mc_sGGHC6VUhez6_bHt0sSzC1[mc_OUB2pptsvtdGL_LyqpgOa0];mc_dtnkT1Km5ucMT0rXvotaC2
<mc_sGGHC6VUhez6_bHt0sSzC1[mc_OUB2pptsvtdGL_LyqpgOa0+1];
mc_dtnkT1Km5ucMT0rXvotaC2++){int32_T mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_Fs32gTLWwQAW_CGEpzznN2[mc_dtnkT1Km5ucMT0rXvotaC2];mc_SB4XF236_SL7JmV1plze0_
[mc_SmSSPSQfR1qEYWsVj5ELF0]+=mc_8IKoYx3qsjeiwHerWlCOS1*
mc_VJl0i9_HuTjyWEktSFg5z_[mc_dtnkT1Km5ucMT0rXvotaC2];}}void
mc_6IsBGrycIJELSxeQVWGP02(const PmRealVector*mc_SheEjf_3lOXDmgzkmhMGG2,const
PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2){real_T*
mc_ymVRqwMm7P_3pyMuLrMu22=mc_SheEjf_3lOXDmgzkmhMGG2->mX;real_T*
mc_oYiyv409AUw8iwzBlM2Ll1=x->mX;real_T*mc_SB4XF236_SL7JmV1plze0_=
mc_ET9_5EAP116KvP5KVqsrD2->mX;size_t mc_dtnkT1Km5ucMT0rXvotaC2=0;size_t
mc_UcQ91Wou1NlJm_M1J1BSo1=x->mN;size_t mc_AoR8_FAMCEiy8t3uUiudM2=
mc_ET9_5EAP116KvP5KVqsrD2->mN;;for(mc_dtnkT1Km5ucMT0rXvotaC2=0;
mc_dtnkT1Km5ucMT0rXvotaC2<mc_UcQ91Wou1NlJm_M1J1BSo1;mc_dtnkT1Km5ucMT0rXvotaC2
++){*(mc_ymVRqwMm7P_3pyMuLrMu22++)+= *(mc_oYiyv409AUw8iwzBlM2Ll1++);}for(
mc_dtnkT1Km5ucMT0rXvotaC2=0;mc_dtnkT1Km5ucMT0rXvotaC2<
mc_AoR8_FAMCEiy8t3uUiudM2;mc_dtnkT1Km5ucMT0rXvotaC2++){*(
mc_ymVRqwMm7P_3pyMuLrMu22++)+= *(mc_SB4XF236_SL7JmV1plze0_++);}}void
mc_fDK_uVHGu_qFAztUmYrXG0(const PmRealVector*mc_Hf_a_gs1wyoHoosYiGonU0,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_Ma839gzucrzsXwGyDhMa82){real_T*mc__ufenpgxU3uuzynJdjZhJ1=
mc_Hf_a_gs1wyoHoosYiGonU0->mX;size_t mc_GwQz52N684rykzgHSrp7k_=
mc_Hf_a_gs1wyoHoosYiGonU0->mN;size_t mc_j_SD_sgtshphDEvI4jhBO_=
mc_AV_LMGONnBUCahwCg3D4y_->mN;int32_T*mc_ZpLqIQEuhUWlcVHG7Xplw0=
mc_Ma839gzucrzsXwGyDhMa82->mX;real_T*mc_v1kc7h4iawvVowQOSKW021=
mc_AV_LMGONnBUCahwCg3D4y_->mX;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_GwQz52N684rykzgHSrp7k_;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc__ufenpgxU3uuzynJdjZhJ1[mc_SmSSPSQfR1qEYWsVj5ELF0]=mc_v1kc7h4iawvVowQOSKW021
[mc_ZpLqIQEuhUWlcVHG7Xplw0[mc_SmSSPSQfR1qEYWsVj5ELF0]];}}void
mc_Pv5PxBp1nNTpA2nv2TKO50(const PmRealVector*mc_Hf_a_gs1wyoHoosYiGonU0,const
PmIntVector*mc_Ma839gzucrzsXwGyDhMa82,const PmRealVector*
mc_AV_LMGONnBUCahwCg3D4y_){real_T*mc__ufenpgxU3uuzynJdjZhJ1=
mc_Hf_a_gs1wyoHoosYiGonU0->mX;size_t mc_GwQz52N684rykzgHSrp7k_=
mc_Hf_a_gs1wyoHoosYiGonU0->mN;size_t mc_j_SD_sgtshphDEvI4jhBO_=
mc_AV_LMGONnBUCahwCg3D4y_->mN;int32_T*mc_ZpLqIQEuhUWlcVHG7Xplw0=
mc_Ma839gzucrzsXwGyDhMa82->mX;real_T*mc_v1kc7h4iawvVowQOSKW021=
mc_AV_LMGONnBUCahwCg3D4y_->mX;size_t mc_SmSSPSQfR1qEYWsVj5ELF0=0;;;for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_j_SD_sgtshphDEvI4jhBO_;mc_SmSSPSQfR1qEYWsVj5ELF0++){
mc__ufenpgxU3uuzynJdjZhJ1[mc_ZpLqIQEuhUWlcVHG7Xplw0[mc_SmSSPSQfR1qEYWsVj5ELF0]
]=mc_v1kc7h4iawvVowQOSKW021[mc_SmSSPSQfR1qEYWsVj5ELF0];}}void
mc_57l_YQYSoo0Ro6WNuRptH_(const PmRealVector*a,const PmIntVector*
mc_SmSSPSQfR1qEYWsVj5ELF0,const PmRealVector*b){real_T*
mc__lerGssn0Ru_r3kSOzEmI_=a->mX;int_T*mc_me5rhv3R7Lr7M9NUyoGtz2=
mc_SmSSPSQfR1qEYWsVj5ELF0->mX;real_T*mc_8ksqc0VFHLjSHzNxXK8mN0=b->mX;size_t
mc_dtnkT1Km5ucMT0rXvotaC2=0,mc_yrT_cAWVfAhvXNLD9hpDQ1=0;size_t
mc_GwQz52N684rykzgHSrp7k_=a->mN;size_t mc_BReG8bBm2DEOUIwYTm9uk0=
mc_SmSSPSQfR1qEYWsVj5ELF0->mN;;;mc_yrT_cAWVfAhvXNLD9hpDQ1=0;for(
mc_dtnkT1Km5ucMT0rXvotaC2=0;mc_dtnkT1Km5ucMT0rXvotaC2<
mc_BReG8bBm2DEOUIwYTm9uk0;mc_dtnkT1Km5ucMT0rXvotaC2++){if(
mc_me5rhv3R7Lr7M9NUyoGtz2[mc_dtnkT1Km5ucMT0rXvotaC2]!=0){;
mc__lerGssn0Ru_r3kSOzEmI_[mc_dtnkT1Km5ucMT0rXvotaC2]+=
mc_8ksqc0VFHLjSHzNxXK8mN0[mc_yrT_cAWVfAhvXNLD9hpDQ1++];}};}void
mc_rQYUV3yV8oYU8KnRKkDRk1(const PmRealVector*a,const PmRealVector*b,const
PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0){real_T*mc__lerGssn0Ru_r3kSOzEmI_=a->mX
;real_T*mc_8ksqc0VFHLjSHzNxXK8mN0=b->mX;boolean_T*mc_me5rhv3R7Lr7M9NUyoGtz2=
mc_SmSSPSQfR1qEYWsVj5ELF0->mX;size_t mc_dtnkT1Km5ucMT0rXvotaC2=0,
mc_yrT_cAWVfAhvXNLD9hpDQ1=0;;;mc_yrT_cAWVfAhvXNLD9hpDQ1=0;for(
mc_dtnkT1Km5ucMT0rXvotaC2=0;mc_dtnkT1Km5ucMT0rXvotaC2<
mc_SmSSPSQfR1qEYWsVj5ELF0->mN;mc_dtnkT1Km5ucMT0rXvotaC2++){if(
mc_me5rhv3R7Lr7M9NUyoGtz2[mc_dtnkT1Km5ucMT0rXvotaC2]){
mc__lerGssn0Ru_r3kSOzEmI_[mc_yrT_cAWVfAhvXNLD9hpDQ1++]+=
mc_8ksqc0VFHLjSHzNxXK8mN0[mc_dtnkT1Km5ucMT0rXvotaC2];}};}void
mc_Xx__kIPwzSZkrHpStVmJF_(const PmRealVector*a,const PmBoolVector*
mc_SmSSPSQfR1qEYWsVj5ELF0,const PmRealVector*b){real_T*
mc__lerGssn0Ru_r3kSOzEmI_=a->mX;real_T*mc_8ksqc0VFHLjSHzNxXK8mN0=b->mX;
boolean_T*mc_me5rhv3R7Lr7M9NUyoGtz2=mc_SmSSPSQfR1qEYWsVj5ELF0->mX;size_t
mc_dtnkT1Km5ucMT0rXvotaC2=0,mc_yrT_cAWVfAhvXNLD9hpDQ1=0;;;
mc_yrT_cAWVfAhvXNLD9hpDQ1=0;for(mc_dtnkT1Km5ucMT0rXvotaC2=0;
mc_dtnkT1Km5ucMT0rXvotaC2<a->mN;mc_dtnkT1Km5ucMT0rXvotaC2++){if(
mc_me5rhv3R7Lr7M9NUyoGtz2[mc_dtnkT1Km5ucMT0rXvotaC2]){
mc__lerGssn0Ru_r3kSOzEmI_[mc_dtnkT1Km5ucMT0rXvotaC2]+=
mc_8ksqc0VFHLjSHzNxXK8mN0[mc_yrT_cAWVfAhvXNLD9hpDQ1++];}};}void
mc__oSPLVBiXeFzzJsThp3Cn_(const PmRealVector*a,const PmBoolVector*
mc_SmSSPSQfR1qEYWsVj5ELF0,real_T x){real_T*mc__lerGssn0Ru_r3kSOzEmI_=a->mX;
boolean_T*mc_me5rhv3R7Lr7M9NUyoGtz2=mc_SmSSPSQfR1qEYWsVj5ELF0->mX;size_t
mc_dtnkT1Km5ucMT0rXvotaC2=0;;for(mc_dtnkT1Km5ucMT0rXvotaC2=0;
mc_dtnkT1Km5ucMT0rXvotaC2<a->mN;mc_dtnkT1Km5ucMT0rXvotaC2++){if(
mc_me5rhv3R7Lr7M9NUyoGtz2[mc_dtnkT1Km5ucMT0rXvotaC2]){
mc__lerGssn0Ru_r3kSOzEmI_[mc_dtnkT1Km5ucMT0rXvotaC2]=x;}}}void
mc_BtNbeiWJf_2ScS2FihDGI0(const PmIntVector*mc_Fgipzm4dZtWjNvleXva_V1,const
PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1){size_t mc_OUB2pptsvtdGL_LyqpgOa0=
0;int32_T*mc_ljExW6hRw43Vg4SLQUAvT1=mc_Fgipzm4dZtWjNvleXva_V1->mX;int32_T*
mc_S51jjFL079S8kdC86krPC0=mc_wgw5_klFOULlYUS4qsiDG1->mJc;;
mc_W7kR8viSTKC_By0UjXE_A1(mc_Fgipzm4dZtWjNvleXva_V1);for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_wgw5_klFOULlYUS4qsiDG1->mNumCol;mc_OUB2pptsvtdGL_LyqpgOa0++){;if(
mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]<mc_S51jjFL079S8kdC86krPC0
[mc_OUB2pptsvtdGL_LyqpgOa0+1]){mc_ljExW6hRw43Vg4SLQUAvT1[
mc_OUB2pptsvtdGL_LyqpgOa0]=1;}}}void mc_GXd0l4NyYg6UNbaEbfuyY1(const
PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*
mc_wgw5_klFOULlYUS4qsiDG1){size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;boolean_T*
mc_ljExW6hRw43Vg4SLQUAvT1=mc_Fgipzm4dZtWjNvleXva_V1->mX;int32_T*
mc_S51jjFL079S8kdC86krPC0=mc_wgw5_klFOULlYUS4qsiDG1->mJc;;for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_wgw5_klFOULlYUS4qsiDG1->mNumCol;mc_OUB2pptsvtdGL_LyqpgOa0++){;if(
mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0]<mc_S51jjFL079S8kdC86krPC0
[mc_OUB2pptsvtdGL_LyqpgOa0+1]){mc_ljExW6hRw43Vg4SLQUAvT1[
mc_OUB2pptsvtdGL_LyqpgOa0]=true;}}}void mc_rxnwynr09yoIhr_7WJOnw2(const
PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*
mc_wgw5_klFOULlYUS4qsiDG1){mc_AZRifAjle326aZku91XJU2(mc_Fgipzm4dZtWjNvleXva_V1
);mc_GXd0l4NyYg6UNbaEbfuyY1(mc_Fgipzm4dZtWjNvleXva_V1,
mc_wgw5_klFOULlYUS4qsiDG1);}void mc_0IN6lZI7UaPeQvvz13t6Z_(const PmBoolVector*
mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1){
int32_T*mc_Fs32gTLWwQAW_CGEpzznN2=mc_wgw5_klFOULlYUS4qsiDG1->mIr;int32_T*
mc_sGGHC6VUhez6_bHt0sSzC1=mc_wgw5_klFOULlYUS4qsiDG1->mJc;boolean_T*
mc_ljExW6hRw43Vg4SLQUAvT1=mc_Fgipzm4dZtWjNvleXva_V1->mX;size_t
mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T mc_dtnkT1Km5ucMT0rXvotaC2=0;;
mc_AZRifAjle326aZku91XJU2(mc_Fgipzm4dZtWjNvleXva_V1);for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_wgw5_klFOULlYUS4qsiDG1->mNumCol;mc_OUB2pptsvtdGL_LyqpgOa0++){for(
mc_dtnkT1Km5ucMT0rXvotaC2=mc_sGGHC6VUhez6_bHt0sSzC1[mc_OUB2pptsvtdGL_LyqpgOa0]
;mc_dtnkT1Km5ucMT0rXvotaC2<mc_sGGHC6VUhez6_bHt0sSzC1[mc_OUB2pptsvtdGL_LyqpgOa0
+1];mc_dtnkT1Km5ucMT0rXvotaC2++){mc_ljExW6hRw43Vg4SLQUAvT1[
mc_Fs32gTLWwQAW_CGEpzznN2[mc_dtnkT1Km5ucMT0rXvotaC2]]=true;}}}void
mc_jk3AE9w8Z153JpwqOK4cP_(const PmBoolVector*mc_v4k0LG4l9Qk9hEXlOIKML_,const
PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,const PmRealVector*
mc_ihxo7l7GSMXRbcDTYJN_h_){int32_T*mc_rX2Nhyrokuq9JmnRvEAkJ1=
mc_3fmwBoA2gfKGlaDfp8GCd1->mIr;int32_T*mc_S51jjFL079S8kdC86krPC0=
mc_3fmwBoA2gfKGlaDfp8GCd1->mJc;real_T*mc_A1lUr3Ax9HoRb_bkcLe_A1=
mc_ihxo7l7GSMXRbcDTYJN_h_->mX;boolean_T*mc_kDbFK62RTDL9nqq9jdcp40=
mc_v4k0LG4l9Qk9hEXlOIKML_->mX;size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T
mc_dtnkT1Km5ucMT0rXvotaC2=0;;mc_AZRifAjle326aZku91XJU2(
mc_v4k0LG4l9Qk9hEXlOIKML_);for(mc_OUB2pptsvtdGL_LyqpgOa0=0;
mc_OUB2pptsvtdGL_LyqpgOa0<mc_3fmwBoA2gfKGlaDfp8GCd1->mNumCol;
mc_OUB2pptsvtdGL_LyqpgOa0++){for(mc_dtnkT1Km5ucMT0rXvotaC2=
mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0];mc_dtnkT1Km5ucMT0rXvotaC2
<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0+1];
mc_dtnkT1Km5ucMT0rXvotaC2++){mc_kDbFK62RTDL9nqq9jdcp40[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_dtnkT1Km5ucMT0rXvotaC2]]=
mc_kDbFK62RTDL9nqq9jdcp40[mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_dtnkT1Km5ucMT0rXvotaC2]
]||(mc_A1lUr3Ax9HoRb_bkcLe_A1[mc_dtnkT1Km5ucMT0rXvotaC2]!=0.0);}}}void
mc_PUtu_CUnyMAexj3n9ThPz1(const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_){size_t mc_wpM2BH4ZgIGett_8VFoUR_=
mc_73ubi6fCtM2UVxkG602gl0->mNumCol;size_t mc_XLDwXv2FCw6lwQmvJo2ni0=
mc_73ubi6fCtM2UVxkG602gl0->mNumRow;size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;int32_T*
mc_S51jjFL079S8kdC86krPC0=mc_73ubi6fCtM2UVxkG602gl0->mJc;int32_T*
mc_rX2Nhyrokuq9JmnRvEAkJ1=mc_73ubi6fCtM2UVxkG602gl0->mIr;int32_T
mc_rxYOIOAUANTezy4ySs_vv1=0;boolean_T*x=pm_JMQ_js3toioP0_0hj_fm5_->mX;
boolean_T*mc_ET9_5EAP116KvP5KVqsrD2=pm__UmJPtGaW9C9junx1RpnH_->mX;;;for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_wpM2BH4ZgIGett_8VFoUR_;mc_OUB2pptsvtdGL_LyqpgOa0++){if(x[
mc_OUB2pptsvtdGL_LyqpgOa0]){for(mc_rxYOIOAUANTezy4ySs_vv1=
mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0];mc_rxYOIOAUANTezy4ySs_vv1
<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0+1];
mc_rxYOIOAUANTezy4ySs_vv1++){mc_ET9_5EAP116KvP5KVqsrD2[
mc_rX2Nhyrokuq9JmnRvEAkJ1[mc_rxYOIOAUANTezy4ySs_vv1]]=true;}}}}void
mc_wMbxp0k7MHKEjpdy17fjt_(const PmRealVector*mc_jJ78FsEfvlTthTdupUhHD2,const
PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,const PmBoolVector*
mc_ID3sxM8zmIB_ZiazgNvWq2){size_t pm_MUnOgYpKkviTC4TqWArmj2=0;size_t
mc_SmSSPSQfR1qEYWsVj5ELF0=0;;;for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<((size_t)(mc_3fmwBoA2gfKGlaDfp8GCd1)->mJc[(
mc_3fmwBoA2gfKGlaDfp8GCd1)->mNumCol]);mc_SmSSPSQfR1qEYWsVj5ELF0++){if(
mc_ID3sxM8zmIB_ZiazgNvWq2->mX[mc_3fmwBoA2gfKGlaDfp8GCd1->mIr[
mc_SmSSPSQfR1qEYWsVj5ELF0]]){mc_jJ78FsEfvlTthTdupUhHD2->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=0.0;}}}void mc_5PAUXWifOqPPHW3wOzFa92(const
PmRealVector*mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmBoolVector*pm_gq3kPpO4Hdv_0UBmX5sfB1){size_t
pm_wOc1JAYSv_gXX9xk1sd2n0=0;size_t mc_OUB2pptsvtdGL_LyqpgOa0=0;;;for(
mc_OUB2pptsvtdGL_LyqpgOa0=0;mc_OUB2pptsvtdGL_LyqpgOa0<
mc_3fmwBoA2gfKGlaDfp8GCd1->mNumCol;++mc_OUB2pptsvtdGL_LyqpgOa0){if(
pm_gq3kPpO4Hdv_0UBmX5sfB1->mX[mc_OUB2pptsvtdGL_LyqpgOa0]){int32_T*
mc_S51jjFL079S8kdC86krPC0=mc_3fmwBoA2gfKGlaDfp8GCd1->mJc;int32_T
mc_SmSSPSQfR1qEYWsVj5ELF0=0;for(mc_SmSSPSQfR1qEYWsVj5ELF0=
mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0];mc_SmSSPSQfR1qEYWsVj5ELF0
<mc_S51jjFL079S8kdC86krPC0[mc_OUB2pptsvtdGL_LyqpgOa0+1];++
mc_SmSSPSQfR1qEYWsVj5ELF0){mc_jJ78FsEfvlTthTdupUhHD2->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=0.0;}}}}PmRealVector mc_mnPo3YlQdExsVqjHael_W2(
const PmRealVector*mc_ljExW6hRw43Vg4SLQUAvT1,size_t mc_XteRrKcywHWBP4sFymZ6y0,
size_t mc_jcOSsrULtHDGKqSRz3gAT0){PmRealVector mc_cPpFNNxfnE9grx4hesF5K_;;;;
mc_cPpFNNxfnE9grx4hesF5K_.mN=mc_jcOSsrULtHDGKqSRz3gAT0-
mc_XteRrKcywHWBP4sFymZ6y0;mc_cPpFNNxfnE9grx4hesF5K_.mX=
mc_ljExW6hRw43Vg4SLQUAvT1->mX+mc_XteRrKcywHWBP4sFymZ6y0;return
mc_cPpFNNxfnE9grx4hesF5K_;}
