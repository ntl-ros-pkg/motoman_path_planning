#include "pm_std.h"
struct sm_39o9C7eH78XBurNHtfXnY0{unsigned int sm_KMCaNyN5l_No7j_K4C8JM0;};
typedef struct sm_39o9C7eH78XBurNHtfXnY0 sm_9g8PGoII0TEO4gLkdB4RM2;void
sm_2nj_Xu7v0yLpkq4U7_s8M2(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
unsigned int sm_V1223Gsg2_1bKbHdwp5PT2);unsigned int sm_eHSy2EC5pEWhOunizVA051
(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,unsigned int
pm_rtvAiaZQgzgWqstgEIdKX1);boolean_T sm_GcVcm5xKPgQaNZ9z0wpvV_(
sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2);unsigned int
sm__awwdRWT70IT3Fqkjq9Ik2(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
size_t n);int sm_rrQA4FS_2SYYdh0eMOLJh1(sm_9g8PGoII0TEO4gLkdB4RM2*
sm_paFfp6oQ7dDgCaOpw32gt2,int sm_9Ns_5orApDy0O9aCFnwy61,int
sm_I5MNPp2_vVk1tb_6FESlZ1);double sm_twH4FEfqMpMUxM3iB_BAj_(
sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,double
sm_I5MNPp2_vVk1tb_6FESlZ1);double sm_hiZS4wLKCIwIM5CGdZRra2(
sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,double
sm_6UyWRzlMTcajvGkn1_c9t_);
#include "pm_std.h"
static void sm_v0ec9h6reAxuqFM5k43ye2(sm_9g8PGoII0TEO4gLkdB4RM2*
sm_paFfp6oQ7dDgCaOpw32gt2){const unsigned int a=0x4A71FE3D;const unsigned int
sm_ojAHyVHgbHhAjmJFnG_l31=263941511;sm_paFfp6oQ7dDgCaOpw32gt2->
sm_KMCaNyN5l_No7j_K4C8JM0*=a;sm_paFfp6oQ7dDgCaOpw32gt2->
sm_KMCaNyN5l_No7j_K4C8JM0+=sm_ojAHyVHgbHhAjmJFnG_l31;}void
sm_2nj_Xu7v0yLpkq4U7_s8M2(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
unsigned int sm_V1223Gsg2_1bKbHdwp5PT2){sm_paFfp6oQ7dDgCaOpw32gt2->
sm_KMCaNyN5l_No7j_K4C8JM0=sm_V1223Gsg2_1bKbHdwp5PT2;}unsigned int
sm_eHSy2EC5pEWhOunizVA051(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
unsigned int pm_rtvAiaZQgzgWqstgEIdKX1){unsigned int orig=
sm_paFfp6oQ7dDgCaOpw32gt2->sm_KMCaNyN5l_No7j_K4C8JM0;sm_paFfp6oQ7dDgCaOpw32gt2
->sm_KMCaNyN5l_No7j_K4C8JM0=pm_rtvAiaZQgzgWqstgEIdKX1;return orig;}boolean_T
sm_GcVcm5xKPgQaNZ9z0wpvV_(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2)
{sm_v0ec9h6reAxuqFM5k43ye2(sm_paFfp6oQ7dDgCaOpw32gt2);return((int)
sm_paFfp6oQ7dDgCaOpw32gt2->sm_KMCaNyN5l_No7j_K4C8JM0)<0;}unsigned int
sm__awwdRWT70IT3Fqkjq9Ik2(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
size_t sm_Pdk2ePvI_9rpqVHjHUYWU0){const unsigned int n=(unsigned int)
sm_Pdk2ePvI_9rpqVHjHUYWU0;int b;unsigned int sm_SmSSPSQfR1qEYWsVj5ELF0,
sm_1OA72Ccil1N0vbkmvAJe61,sm__hMJlY8ynCkROZdDuZyH72;sm_v0ec9h6reAxuqFM5k43ye2(
sm_paFfp6oQ7dDgCaOpw32gt2);if(n==0)return sm_paFfp6oQ7dDgCaOpw32gt2->
sm_KMCaNyN5l_No7j_K4C8JM0;b=0;for(sm_SmSSPSQfR1qEYWsVj5ELF0=n;
sm_SmSSPSQfR1qEYWsVj5ELF0!=0;sm_SmSSPSQfR1qEYWsVj5ELF0>>=1,++b){}
sm_1OA72Ccil1N0vbkmvAJe61=(b==32)?0xFFFFFFFF:((1u<<b)-1);
sm__hMJlY8ynCkROZdDuZyH72=(sm_paFfp6oQ7dDgCaOpw32gt2->
sm_KMCaNyN5l_No7j_K4C8JM0>>(32-b))&sm_1OA72Ccil1N0vbkmvAJe61;while(
sm__hMJlY8ynCkROZdDuZyH72>=n){sm_v0ec9h6reAxuqFM5k43ye2(
sm_paFfp6oQ7dDgCaOpw32gt2);sm__hMJlY8ynCkROZdDuZyH72=(
sm_paFfp6oQ7dDgCaOpw32gt2->sm_KMCaNyN5l_No7j_K4C8JM0>>(32-b))&
sm_1OA72Ccil1N0vbkmvAJe61;}return sm__hMJlY8ynCkROZdDuZyH72;}int
sm_rrQA4FS_2SYYdh0eMOLJh1(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
int sm_9Ns_5orApDy0O9aCFnwy61,int sm_I5MNPp2_vVk1tb_6FESlZ1){;return
sm_9Ns_5orApDy0O9aCFnwy61+(int)sm__awwdRWT70IT3Fqkjq9Ik2(
sm_paFfp6oQ7dDgCaOpw32gt2,(size_t)(sm_I5MNPp2_vVk1tb_6FESlZ1-
sm_9Ns_5orApDy0O9aCFnwy61+1));}double sm_twH4FEfqMpMUxM3iB_BAj_(
sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,double
sm_I5MNPp2_vVk1tb_6FESlZ1){;return sm_I5MNPp2_vVk1tb_6FESlZ1*(
sm__awwdRWT70IT3Fqkjq9Ik2(sm_paFfp6oQ7dDgCaOpw32gt2,0)/4294967296.0);}double
sm_hiZS4wLKCIwIM5CGdZRra2(sm_9g8PGoII0TEO4gLkdB4RM2*sm_paFfp6oQ7dDgCaOpw32gt2,
double sm_6UyWRzlMTcajvGkn1_c9t_){return sm_twH4FEfqMpMUxM3iB_BAj_(
sm_paFfp6oQ7dDgCaOpw32gt2,2.0*sm_6UyWRzlMTcajvGkn1_c9t_)-
sm_6UyWRzlMTcajvGkn1_c9t_;}
