#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
typedef struct ssc_core_KNcJ1jU8piEi_2g0Ydzzo2 ssc_core_L4FImzp6iu_cikM_QSiOq1
;typedef struct ssc_core_mxYVgQYwCLIPwD6arnF2g0 ssc_core_5Z1inCkB2uIKKdlyf3XlZ0
;typedef enum{ssc_core_PQvF_V2l5jTui_cnayCtx1= -1,
ssc_core_A054j0gk4AqU55YWXLdcE_,ssc_core_Pb8JUwx4ywPtUw65I_hnN2,
ssc_core_Nrc9kYdGOx7oW_IqsZeAq2}ssc_core_5lRuVpDVc6bG2IVKfGVqN_;
#include "pm_std.h"
#include "stdarg.h"
typedef ssc_core_L4FImzp6iu_cikM_QSiOq1*ssc_core_W6s6ejAuxmf3Rn5u3Prmo1;
typedef struct ssc_core_ldPgUTwLyE_x1JdTSz2P_2 ssc_core_l7Vl0LGT7AfeKsNNq2ohE_
;struct ssc_core_mxYVgQYwCLIPwD6arnF2g0{ssc_core_l7Vl0LGT7AfeKsNNq2ohE_*
mPrivateData;ssc_core_W6s6ejAuxmf3Rn5u3Prmo1(*ssc_core_jcnGpJQgTcmoivKt9gMXJ2)
(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11);void(*
ssc_core_i2NW6LM_KwvKtnEPF1Orc_)(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
ssc_core_5oGXXguX8Nt1GG4V0iIu11,ssc_core_W6s6ejAuxmf3Rn5u3Prmo1
ssc_core_MFU8AZc1sVWww5aGi0_bW1,ssc_core_5lRuVpDVc6bG2IVKfGVqN_
ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId ssc_core_HWujgKbJDK__6hXlZ2n4h1,
va_list args);void(*ssc_core_FGt3kHNgY0FD6WtT9A7ZX1)(const
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11,
ssc_core_W6s6ejAuxmf3Rn5u3Prmo1 ssc_core_MFU8AZc1sVWww5aGi0_bW1,
ssc_core_5lRuVpDVc6bG2IVKfGVqN_ ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId
ssc_core_HWujgKbJDK__6hXlZ2n4h1,va_list args);void(*
ssc_core_dIxsRfQPvJkJ8GAzpkhG_2)(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
ssc_core_5oGXXguX8Nt1GG4V0iIu11,ssc_core_W6s6ejAuxmf3Rn5u3Prmo1
ssc_core_MFU8AZc1sVWww5aGi0_bW1);void(*ssc_core_dz_RWLqYzBWNrh9nmgYH4_)(const
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_aYJ6B0B9Fj1TBcEqe7roh0,const
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*src);const ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_YYYkUiIsbcGVoY_mppukX_)(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
ssc_core_5oGXXguX8Nt1GG4V0iIu11);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11);};
PmfMessageId ssc_core_ngsKQfybc3dXXgWu3kMDK_(const
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11,
ssc_core_W6s6ejAuxmf3Rn5u3Prmo1 ssc_core_MFU8AZc1sVWww5aGi0_bW1,
ssc_core_5lRuVpDVc6bG2IVKfGVqN_ ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId
ssc_core_HWujgKbJDK__6hXlZ2n4h1,...);PmfMessageId
ssc_core_IKSN8QHwicUJYTLVFP7Ia0(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
ssc_core_5oGXXguX8Nt1GG4V0iIu11,ssc_core_W6s6ejAuxmf3Rn5u3Prmo1
ssc_core_MFU8AZc1sVWww5aGi0_bW1,ssc_core_5lRuVpDVc6bG2IVKfGVqN_
ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId ssc_core_HWujgKbJDK__6hXlZ2n4h1,
...);PmfMessageId ssc_core_7iomSuWDwroANLyLpFWrN_(const
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11,
ssc_core_5lRuVpDVc6bG2IVKfGVqN_ ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId
ssc_core_HWujgKbJDK__6hXlZ2n4h1,...);PmfMessageId
ssc_core_D4HdOXDY4msISsxzAoWjV_(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
ssc_core_5oGXXguX8Nt1GG4V0iIu11,ssc_core_W6s6ejAuxmf3Rn5u3Prmo1
ssc_core_MFU8AZc1sVWww5aGi0_bW1,ssc_core_5lRuVpDVc6bG2IVKfGVqN_
ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId ssc_core_HWujgKbJDK__6hXlZ2n4h1,
const char*ssc_core__ERPI7nFZcjivUhOMK8_I1);PmfMessageId
ssc_core_1C51fYR3zpbOEkQ1RRAIQ0(const ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
ssc_core_5oGXXguX8Nt1GG4V0iIu11,ssc_core_5lRuVpDVc6bG2IVKfGVqN_
ssc_core_lKDbSBX8Dd_1ESULrp8vl2,PmfMessageId ssc_core_HWujgKbJDK__6hXlZ2n4h1,
const char*ssc_core__ERPI7nFZcjivUhOMK8_I1);ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*
neu_create_diagnostic_manager(PmAllocator*mc_YMfc_eB3rHMVJUig1uu500);struct
ssc_sli_wAayweXjOYFF6BsuNZrLX1{PmSparsityPattern ssc_sli_JxZ2lkwyBUm5ZftOVAJXZ0
;PmRealVector ssc_sli_FqX9Sf4omHsO4fZT08Pfn2;PmSparsityPattern
ssc_sli_M1B7ldbMD2AZKJltYjWSF_;PmRealVector ssc_sli_t_pDylaBmAxguE6KJ9YXz0;
PmRealVector ssc_sli_8GS41MzlE5XJondPh_gjk1;};typedef struct
ssc_sli_wAayweXjOYFF6BsuNZrLX1 ssc_sli_OZp3BoovP9hz1c3QP_4KZ1;struct
ssc_sli_I19iaTRsLXiDPRn8qEW1w1{PmSparsityPattern ssc_sli_J37SNUIXrn9q_Uqqr__A2_
;PmRealVector ssc_sli_xoYj2toK8NmTQpPypjeyn_;PmSparsityPattern
ssc_sli_N0jibk_xX5GD3sK50rvWm1;PmRealVector ssc_sli_NG3w5CynTNKkm1WIm54z20;
PmRealVector ssc_sli_FCKGBPh971dGh1fbE6Ltb2;};typedef struct
ssc_sli_I19iaTRsLXiDPRn8qEW1w1 ssc_sli_lCpfWX_wXDHmqxsOyLDte0;struct
ssc_sli_zkcwaeaNWnKOJipxh5inI2{ssc_sli_OZp3BoovP9hz1c3QP_4KZ1
ssc_sli_C3TKwX8RBAYn1kmr_2usY2,ssc_sli_E6k7McF_Vl6CmqEsbI8mE1;
ssc_sli_lCpfWX_wXDHmqxsOyLDte0 ssc_sli_bqs36EqSOESDXU5wkjWP42;PmRealVector
ssc_sli_gp_x31PBpZSGk9lwf_YMF2;real_T ssc_sli_ebbbRH7XaAiHCUUa7Z78P0;boolean_T
ssc_core_XL_gZqocnFSK6dfns5Qdk2;};typedef struct ssc_sli_zkcwaeaNWnKOJipxh5inI2
ssc_sli_d9_27aAXZ1ygXoMJr5sTK0;typedef void(*ssc_sli_V3Se8WUxu_uOWv74IJ6CM_)(
void*,PmCharVector);typedef struct ssc_sli__YyjtPxLKYkcp1tfJYb_J_{void*
ssc_sli_MViN0FmkzA0TTrsEIwoW90;ssc_sli_V3Se8WUxu_uOWv74IJ6CM_
ssc_sli_YMj_lFUyMUAQ5NGHKzTbq2;ssc_sli_V3Se8WUxu_uOWv74IJ6CM_
ssc_sli_Zy1q0_4Dis0UBahJ7LEsV_;}ssc_sli_AIgk9qyNVi5uKcJbFNYIR1;boolean_T
ic_solve_impl(PmRealVector*x,const PmRealVector*mc_MJ6HaMWdyRxHm3p_EZiD41,
const ssc_sli_d9_27aAXZ1ygXoMJr5sTK0*ssc_sli_z0ZLRcfet_AHsL45JYPiy2,const
ssc_sli_AIgk9qyNVi5uKcJbFNYIR1*ssc_core_ZYWXY67LkEIFg_fAKXl61_,
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11);struct
ssc_sli_TveuOuuz_7rSXp2jMuHzn2{struct{char const*
ssc_sli_d0KC4E_C04INeRdStGyX0_;char const*ssc_sli_71h37iCrNIRoA0Fuz8Br1_;char
const*ssc_sli_J7L8c_xGqNqToa0gyKqrA_;char const*ssc_sli_bnZTNJZePTPixobuL7g6r2
;char const*ssc_sli_Cdey9tFCJKiq3RvEAzqZA2;char const*
ssc_sli_iAz0saed35ijRf0stLdzV_;char const*ssc_sli_wBf_uVMtIzWw_DT3zRvLW_;char
const*ssc_sli_3oao4QosKKr5tb3h7b_3k1;}ssc_sli_quXm4UhnWp_tEhxQXk4mw_;struct{
char const*ssc_sli_iNHp7SEo6J1K_NVA3XotB0;char const*
ssc_sli_U_CBw16lf9jbDq5WZ7rO_2;char const*ssc_sli_aacb3Qf__8jiwROyUozNz0;}
ssc_sli_24MCYv9QMnEhcVWqH_r3O_;struct{char const*
ssc_sli_62pIARaz12Y6KlmUDEV3x0;char const*ssc_sli_oFkt6HmamOK3kQxC1ndB91;char
const*ssc_sli_f3IVsYBfdXij1sTFVarwh1;char const*ssc_sli_dgoUPzmmdVFRzxGXV0UOu0
;char const*ssc_sli_ZDFYs9_5PfijfGQ8qWd1g0;char const*
ssc_sli_fFU87dPt5fNvCNNxLyMDy1;char const*ssc_sli__SJ2w4HE2QzJ_m1x11yQD1;char
const*ssc_sli_a0K7_MOuYlLuaCNUTIgMs0;char const*ssc_sli_5uUzHSTnhMec_QEZ39yew1
;char const*ssc_sli_wfAkiPQLIMgwmCXaltZM_0;char const*
ssc_sli_SaIazKr0nvYkwgrtuJDGd2;char const*ssc_sli_eNCDQdqkjRfmdbpsGiFhO0;char
const*ssc_sli_nQyqKn7Uoh4Maq4mvd1Ma0;char const*ssc_sli_fI7NG9ipq_ET6aeiHB0Z_1
;char const*ssc_sli_qJh5yfAB8O7_fq_jNvpod0;char const*
ssc_sli__iPLU1R_HzeOQgx8v2NY_2;char const*ssc_sli_rC6rzPDx9_DHVKa9oNHyv_;char
const*ssc_sli__bAvR_d3iAlUn9_tJl_eM1;char const*ssc_sli_zC9_8AU0aRkLd8KBXoyx1_
;char const*ssc_sli_WY_oTGR95R9UyxrxALXk9_;char const*
ssc_sli_dAWaVAbljGHliznq40YkB1;char const*ssc_sli_lpdQAWbUr8e3MtcSN24Ua1;char
const*ssc_sli_GbX4cwN0_HZAuIYQoonTr1;char const*ssc_sli_JslLhZ_haz2GP4P6f6WIT1
;char const*ssc_sli_1qEUpYoL05WhIApHLTF1U0;char const*
ssc_sli_2lVe_SP4xddtcTiZGd__J_;}ssc_sli_MAZejEIE7f5iDR2USo5EO_;struct{char
const*ssc_sli_YLQbygAawqdpMEE_LUPfn1;}ssc_sli_obPCJUAzujUaxF2_CbLJs0;};extern
struct ssc_sli_TveuOuuz_7rSXp2jMuHzn2 ssc_sli_z8JnA55sA_IR2MbuPWpVm1;struct
ssc_sli_TveuOuuz_7rSXp2jMuHzn2 ssc_sli_z8JnA55sA_IR2MbuPWpVm1={{
"When local solver is selected, the NDF2 local solver choice is not supported. Either unselect local solver, or choose Backward Euler or Trapezoidal Rule on the Solver Configuration block instead."
,"%s",
"Simscape succeeded in finding consistent states with which to start the simulation, but the states found may deviate from requested initial conditions."
,"Here is the set of components with unconverged equations:\n%s",
"Nonlinear solver to advance time one step failed to converge due to Linear Algebra error. Failed to solve using iteration matrix.\n"
,"Nonlinear solver to advance time one step failed to converge.\n",
"Nonlinear solver to advance time one step failed to converge, residual norm too large.\n"
,"Variable-step local solver failed to meet tolerance.",},{
"Insufficient memory budget for delay expressions history.",
"Detected inconsistent parameters specified with simset or in the model reference hierarchy. Use the same settings for Solver, StartTime and FixedStep in the top model and all referenced models."
,"Unable to restore SimState due to model changes.",},{
"Failed to diagnose failure.",
"The Simscape network contains frequency-domain equations. Transient simulation of such networks is not allowed."
,
"Explicit solvers are not supported in frequency-time equation formulation. Choose an implicit solver (ode14x, ode15s, or ode23t) or use local solver."
,"%s","%s",
"First solve for initial conditions failed to converge. Trying again with all high priorities relaxed to low."
,
"Second solve for initial conditions failed to converge. Trying again with all variable targets ignored."
,
"Detected inconsistent solvers specified with simset or in the model reference hierarchy. Use the same solver in the top model and all referenced models."
,
"Detected nonfinite (Inf or NaN) values while evaluating equations or their partial derivatives at the start of initialization. Such equations may cause the initialization solve to fail. In order to fix this problem, you can either modify some equations or set different prestart values for some of the variables involved. The equations are listed below, as well as their prestart values in computational units.\n%s"
,"%s",
"Transient initialization at time %s, solving for consistent states with the modes of the model fixed, failed to converge."
,
"Transient initialization at time %s, solving for consistent states and modes, failed to converge."
,
"Solving for consistent states with discrete states of the model fixed failed to converge at time %s."
,"Steady state solve failed to converge.",
"Initial conditions solve failed to converge.",
"State derivative calculation failed, possibly due to singular upper-left (differential states and equations) corner of mass matrix."
,"Calculation for differential and algebraic state derivatives failed.","%s",
"... (Truncated error message at maximum length of buffer.)",
"Event iteration failed to converge within the iteration limit (100).",
"Nonlinear solver: Linear Algebra error. Failed to solve using iteration matrix."
,"Nonlinear solver failed to converge.",
"Nonlinear solver: failed to converge, residual norm too large.",
"Here is the set of components with unconverged equations:\n%s",
"Failed to update switched linear model, due to system singularity in current configuration."
,"The following event variables changed at the last allowed iteration:\n%s",},
{
"All discrete sample times in your model must be an integer multiple of the local solver sample time."
,},};
#include "pm_std.h"
#include "pm_std.h"
int_T pm_FBD_ZCGRyF9Zix4mvl6Ip0(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
size_t pm_JhTijL0ZlABf2EhQiFVX71,size_t pm_qYV3thKugwWwSrIbTfcS10,size_t
pm_8oezoIPNG9LZPP18xVIrw_,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_JhTijL0ZlABf2EhQiFVX71,
size_t pm_qYV3thKugwWwSrIbTfcS10,size_t pm_8oezoIPNG9LZPP18xVIrw_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_3YYVuJb7mmfC_9_znq5yH2(PmSparsityPattern*
pm_xhS7ip83N1al9vsl9z_jP2,const PmSparsityPattern*pm_7CpwkWeWUw6deoCGAHlcg0);
boolean_T pm_F9dzGbF9bw2QlZyj3V1Gf_(const PmSparsityPattern*
pm_xhS7ip83N1al9vsl9z_jP2,const PmSparsityPattern*pm_7CpwkWeWUw6deoCGAHlcg0);
PmSparsityPattern*pm_9oMk0xBPD28NQC6egedGY2(const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_s_tA_vyom56bxaGbqlGcb0(PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);void pm_06dTzOwkhN7oGBM_7J2hK1(
PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*pm_OLpBo6MxIVPIjv0_z_qCc2(size_t
pm_WkDzWdo3HJglufgddrvj_1,size_t pm_Y_WQkyfqLWq4_EV8mXQjt_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*pm_8BokEnlj2bsehUZ6VBVqc0(size_t
pm_WkDzWdo3HJglufgddrvj_1,size_t pm_Y_WQkyfqLWq4_EV8mXQjt_,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*pm_LPeaDYoYWpCMrX0FHDZrj2(size_t
pm_KYlcoOk9rSSGYswizhYqZ2,size_t n,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmSparsityPattern*pm_Fd_reSzeOBuDPZtoIWlnj0(size_t n,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_rv_equals_rv(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
pm_U1h5Sl4yTxoF_YCvN9hBa1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void pm_TnPSeUZeYw5Wc8bvD8sl80(const
PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*
pm__UmJPtGaW9C9junx1RpnH_);void pm_fKS8kuV7G_WhlO7CcdVnc1(const PmCharVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmCharVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm___43lXp90F4bzSkAXqYfT1(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_XDtBnYqrul1zO7ccbIlmV2(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);
boolean_T pm_9IegWBFmNW3wA_0fRmj9m2(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);int_T
pm_create_real_vector_fields(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size
,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmRealVector*pm_create_real_vector(
size_t pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmRealVector*pm_ZdJ6KB36NX_7JjULh6fi72(const PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_MgDXCYHfYCiNYyF5Ik7dF2(PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_destroy_real_vector(PmRealVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T
pm_create_int_vector_fields(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*pm_create_int_vector(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmIntVector*
pm_pLia5sG_NxTeQbxzYtpXx_(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_Rdk2CZ3CCj5T0d2uDHUZ20(
PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_destroy_int_vector(PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmBoolVector*pm_YZQHxvtiv5rBT_iBt45HQ_(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_SK8Vck8jU45BIyJDK11DV_(
PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_qv4zOCjtiVRVC86eoqx06_(PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmBoolVector*pm_Or6MViYTj4_1rM_3pn1UZ0(
const PmBoolVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_create_char_vector_fields(PmCharVector*
pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmCharVector*pm_VJ_YkZBOp_Ry9yis8LShD1(size_t pm_Z_HH1rAAmOFPWVcI_yamd_,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_cn_kUNHZ0hjihWokUKapj_(
PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
void pm_ea51z6lAUjevRfjOCHL37_(PmCharVector*pm_VmBquL1cTEkIgP0cS5pM82,
PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);int_T pm_nUREx2_I6_H8Z9q4fW3LX2(
PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,size_t size,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSizeVector*pm_P_7OU_rMIBro7VhkR5sYZ0(size_t
pm_Z_HH1rAAmOFPWVcI_yamd_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_5sJaU0uW397ggcDhUnm4m0(PmSizeVector*pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void pm_hU5rOc4ZvyOrVHd_MYDl_2(PmSizeVector*
pm_VmBquL1cTEkIgP0cS5pM82,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
pm_WlKWB9N0DUmpIlj3_4orb_(const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmSizeVector*pm__UmJPtGaW9C9junx1RpnH_);boolean_T pm_IdLJ4aCFEkd1hlk5xl7aY_(
const PmSizeVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmSizeVector*
pm__UmJPtGaW9C9junx1RpnH_);
#include "pm_std.h"
size_t mc_KpKqaZjZ2rh3lSToFa7Oa2(const PmBoolVector*mc_ljExW6hRw43Vg4SLQUAvT1)
;void mc_KLKWK_FbEAF724qPNbehq1(const PmIntVector*mc_ykDPEcD4BuT8SJa7vuxej1,
const PmRealVector*x,const PmRealVector*mc_yS7VvSIKrGg9ddzBqHtUd_);void
mc_uJ_iGAyluQ5NndhonaPXl1(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const PmIntVector*
mc_kmcnrlTt6IvFH5HSoyHe21);void mc_oT_HwSgZBfR7LPqZomt0Y0(const PmIntVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmIntVector*mc_kmcnrlTt6IvFH5HSoyHe21);void mc_mMmDjYPdSIEEQHj__7cd71(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_);void mc_zYvj4jole4TnufsPoZWW_2(const
PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmIntVector*
pm__UmJPtGaW9C9junx1RpnH_,const PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0);void
mc_TJe2EtJyyhfHpuJYOjxfC0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmIntVector*pm__UmJPtGaW9C9junx1RpnH_,boolean_T mc_7lBL31aWjgSfMHGQtksob2);
void mc_JM1DLKwRGzo9Uyq32V72E_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*mc_MmlNWCb0Iec292kl7KbkQ1);void mc_si_irLJWyQLY_l4tqebAe_(
const PmIntVector*mc_rxT7_6KqJcx5sNYEWRALX2,int32_T mc_RGllRMvIRPGkpbvuetJlO2)
;void mc_pJmDkwzzX3Iu6_VR_MyvL_(const PmBoolVector*mc_Hf_a_gs1wyoHoosYiGonU0,
const PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_YwEOIpm092vI_BA0rQzvJ2);void mc_SKE1EUStKD_KtRTTXrxqv2(const PmBoolVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmBoolVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_OT_v_IC_x9R85Z4eHn1jA0(const PmRealVector*
mc_9_yWAFd98YjxIPCHmG5rr0,size_t mc__VPpmCt_TuqLdOtTsmwgk2,const PmRealVector*
mc_Ds0gTsuf_v_EnBO9LqpvK_,size_t mc_947YwtWZMq1Crv_q1N3191,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_J9HotRGeuZtxiip_GSZPb0(PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);size_t
mc_lp5J2bZ8EcxnhyI1PKPZd2(const PmBoolVector*mc_G15g52JPQFeDaEm_uJadW_);void
mc__xr97Mh4VU4bdE2CcyEVf_(const PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,const
PmBoolVector*mc_AV_LMGONnBUCahwCg3D4y_);size_t mc_pdD80p5I4a4oDKki08oZ50(const
PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0);size_t mc_a_dd0x8Rstf0HD74BJt9A2(const
PmRealVector*mc_ZxltZcnt1eSoyJTnrOm7z2);size_t mc_8u8_LRBN9SbcEOkeum7ag0(const
PmBoolVector*mc_ZxltZcnt1eSoyJTnrOm7z2);boolean_T mc_Ukc2BYyTIIZDpb_lFOWTt0(
const PmIntVector*mc_kI6kqxnpJaUqvLfVbMkdr0);boolean_T
mc_l26oJh0UM_xwSgKIeOC5J0(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,int32_T
mc_RGllRMvIRPGkpbvuetJlO2);boolean_T mc_ocDPr6f6C4_v9b5NDj8JH_(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T mc_RGllRMvIRPGkpbvuetJlO2);void
mc_fuQc8C9CyCuf_KkBLV8eb0(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_8BTcsQ6C8h5zrW1ZQRhKf1(const
PmRealVector*x,real_T mc_ljExW6hRw43Vg4SLQUAvT1);void mc_W0fX8K54ez0qAgM9tXjsi_
(const PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_fjtK_RGCYgp34_TjPN6zv1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_LlLyVwCApgTvSBfIvzOuk0(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,real_T a,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void mc_fIL9UyKjuKeUlnGmcXq5r2(const PmRealVector*x
,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_SheEjf_3lOXDmgzkmhMGG2);void mc_v7V5uZPqLRlsEpMCWsoMJ0(const PmRealVector*x
,const real_T a,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_DnL_y_DaeSoRsDtnK0hpB1(const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
real_T mc_8IKoYx3qsjeiwHerWlCOS1);void mc_I_W_409sg28ysFYlBfPcr_(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const real_T mc_8IKoYx3qsjeiwHerWlCOS1)
;void mc_MI5F4RaYNQR7pPk1GRkvn_(const PmIntVector*pm_JMQ_js3toioP0_0hj_fm5_,
const PmIntVector*pm__UmJPtGaW9C9junx1RpnH_);void mc_lkC6x3YtrvW6L16S6aM60_(
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*
pm__UmJPtGaW9C9junx1RpnH_);void mc_vfuXLuRk3KtAfbvK_cTrv2(const PmRealVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_);void
mc_tOKZMGNlSqK650YhjgeKv0(const PmRealVector*mc_9JsNfMLIQx0SlNuEaL4I2_,real_T
mc_8IKoYx3qsjeiwHerWlCOS1);void mc_Uy10YSjkY75ViJd9dTdYI1(const PmBoolVector*
mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_Rhhlgu4QH_WTKd_5kpe4I2(const PmRealVector*
mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_WmHTznO_Ih_dJw_MhKtIQ1(const PmIntVector*
mc_9JsNfMLIQx0SlNuEaL4I2_,int32_T mc_RGllRMvIRPGkpbvuetJlO2);void
mc_nLc17gFNFcvBlJrwxJV4w_(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void
mc_W7kR8viSTKC_By0UjXE_A1(const PmIntVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void
mc_AQtCbBjZ792h1_Xaj_dR92(const PmBoolVector*mc_i34rFP0sHa_dTbFseidcw0,const
PmIntVector*mc_YwEOIpm092vI_BA0rQzvJ2,boolean_T mc_8IKoYx3qsjeiwHerWlCOS1);
void mc_tLxHiRii5tbHWjrunaI2i1(const PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_,
boolean_T mc_8IKoYx3qsjeiwHerWlCOS1);void mc_AZRifAjle326aZku91XJU2(const
PmBoolVector*mc_9JsNfMLIQx0SlNuEaL4I2_);void mc_mGD4FL6_MDLg2bdqzdpfx_(const
PmBoolVector*x,size_t mc_SmSSPSQfR1qEYWsVj5ELF0,size_t
mc_QHNSjd8JBrVVYZAcs7Zm32);void mc_x2bRmxKlHWAMEwOZuiA_62(const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_,const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);void
mc_eJ9VFRIFMWxO52_BT7X_C_(const PmBoolVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_);real_T mc_WJAbbKueqClxuItYQx7b61(const
PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);real_T mc_TuU8NakpY91qxLM4is2wV2(const
PmRealVector*pm_VmBquL1cTEkIgP0cS5pM82);int32_T mc_dLmR9a64iWQBHX4QM5zCr2(
const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82);int32_T mc_eIjmwucqCUJT1PyCl_z5b_
(const PmIntVector*pm_VmBquL1cTEkIgP0cS5pM82);void mc_loSQGFba0sjWysbLdmqzS1(
PmIntVector*mc_QyVbO3pTvGiccU8Tn2eK2_,const PmIntVector*
mc_kI6kqxnpJaUqvLfVbMkdr0);void mc_O_flPmjeFB4ZmON9Xp2iV_(PmRealVector*
mc_EBUUePJ08d2hXtTa8LU0J_,const PmRealVector*mc_23nxQONnTNHWizowC7lIt0,const
PmSparsityPattern*mc_UYX2aVqEUCl0fW5_qT4Lo1);void mc_K1ezq3TzhoNUE_SEp0Dr12(
const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void
mc_WuGlfcFda9zO01qKeAxMn_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void
mc_qEYnRq0Ff87lxOQck1Gqi_(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const real_T*x);void mc_SZGAWN4U4XTzc5RKGKSk5_(const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*
mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,
const PmRealVector*mc_2cVF0Ggof80TSRmRbhE8l1,size_t mc_LMkPrnaKcsYHEp0eExPFH1)
;void mc_FoRQvfcV_dWdjx5L1lyM_0(const PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,
const PmRealVector*mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*
mc_73ubi6fCtM2UVxkG602gl0,const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_,const
PmRealVector*mc_5LkYradW8mKeL3fLSt9By1);void mc_lBp5wbXG7AvQ3hxoerNOW_(const
PmRealVector*pm__UmJPtGaW9C9junx1RpnH_,const PmRealVector*
mc_kvOR3Cr3RdA0t5JHDRjvp1,const PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,
const PmRealVector*pm_JMQ_js3toioP0_0hj_fm5_);void mc_z041e_QXd3uR2ef2CH37s1(
const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2,const PmRealVector*
mc_0R8y9UtrLk3busEbM65xW_,const PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,
size_t mc_OUB2pptsvtdGL_LyqpgOa0,real_T mc_8IKoYx3qsjeiwHerWlCOS1);void
mc_6IsBGrycIJELSxeQVWGP02(const PmRealVector*mc_SheEjf_3lOXDmgzkmhMGG2,const
PmRealVector*x,const PmRealVector*mc_ET9_5EAP116KvP5KVqsrD2);void
mc_fDK_uVHGu_qFAztUmYrXG0(const PmRealVector*mc_Hf_a_gs1wyoHoosYiGonU0,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_,const PmIntVector*
mc_Ma839gzucrzsXwGyDhMa82);void mc_Pv5PxBp1nNTpA2nv2TKO50(const PmRealVector*
mc_Hf_a_gs1wyoHoosYiGonU0,const PmIntVector*mc_Ma839gzucrzsXwGyDhMa82,const
PmRealVector*mc_AV_LMGONnBUCahwCg3D4y_);void mc_57l_YQYSoo0Ro6WNuRptH_(const
PmRealVector*a,const PmIntVector*mc_SmSSPSQfR1qEYWsVj5ELF0,const PmRealVector*
b);void mc_rQYUV3yV8oYU8KnRKkDRk1(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0);void mc_Xx__kIPwzSZkrHpStVmJF_(
const PmRealVector*a,const PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0,const
PmRealVector*b);void mc__oSPLVBiXeFzzJsThp3Cn_(const PmRealVector*a,const
PmBoolVector*mc_SmSSPSQfR1qEYWsVj5ELF0,real_T x);void mc_BtNbeiWJf_2ScS2FihDGI0
(const PmIntVector*mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*
mc_wgw5_klFOULlYUS4qsiDG1);void mc_rxnwynr09yoIhr_7WJOnw2(const PmBoolVector*
mc_Fgipzm4dZtWjNvleXva_V1,const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);
void mc_GXd0l4NyYg6UNbaEbfuyY1(const PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,
const PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);void
mc_0IN6lZI7UaPeQvvz13t6Z_(const PmBoolVector*mc_Fgipzm4dZtWjNvleXva_V1,const
PmSparsityPattern*mc_wgw5_klFOULlYUS4qsiDG1);void mc_jk3AE9w8Z153JpwqOK4cP_(
const PmBoolVector*mc_v4k0LG4l9Qk9hEXlOIKML_,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmRealVector*mc_A1lUr3Ax9HoRb_bkcLe_A1);void
mc_PUtu_CUnyMAexj3n9ThPz1(const PmBoolVector*pm__UmJPtGaW9C9junx1RpnH_,const
PmSparsityPattern*mc_73ubi6fCtM2UVxkG602gl0,const PmBoolVector*
pm_JMQ_js3toioP0_0hj_fm5_);void mc_wMbxp0k7MHKEjpdy17fjt_(const PmRealVector*
mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*mc_3fmwBoA2gfKGlaDfp8GCd1,
const PmBoolVector*mc_ID3sxM8zmIB_ZiazgNvWq2);void mc_5PAUXWifOqPPHW3wOzFa92(
const PmRealVector*mc_jJ78FsEfvlTthTdupUhHD2,const PmSparsityPattern*
mc_3fmwBoA2gfKGlaDfp8GCd1,const PmBoolVector*pm_gq3kPpO4Hdv_0UBmX5sfB1);
PmRealVector mc_mnPo3YlQdExsVqjHael_W2(const PmRealVector*
mc_ljExW6hRw43Vg4SLQUAvT1,size_t mc_XteRrKcywHWBP4sFymZ6y0,size_t
mc_jcOSsrULtHDGKqSRz3gAT0);PmSparsityPattern*mc_S33zPe8SknN9LcYhCb5wi0(const
PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void mc_I9gOpdxdkDtFisWaAcueS2(real_T*
mc_8VOewhnYPTbEOlk_QYcri_,const PmSparsityPattern*mc_EosJ0tDP9FinOzz9f3ExR0,
const real_T*mc__lerGssn0Ru_r3kSOzEmI_,const PmSparsityPattern*
mc__aqwF2UeMrHkDfRgGhMkr0);void mc_8PNvEo7OREfPPqdHoj4v91(PmSparsityPattern*
mc_zjv8smHIpfaW50M42kA_f0,PmRealVector*mc_EJqOvdCztL0mVeO_IBz710);
PmSparsityPattern*mc_fs9G14AuSjx6a7_fW1jDc2(const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,const PmBoolVector*mc_crpmV1NfytxB6epLFDbeY2,const
PmBoolVector*mc_l6yizd46ODo8FXwxtVTrF_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmSparsityPattern*mc_QrDTyksvE_fzwQPgWfWMo0(const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,const PmBoolVector*mc_crpmV1NfytxB6epLFDbeY2,const
PmBoolVector*mc_l6yizd46ODo8FXwxtVTrF_,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);
PmSparsityPattern*mc_lya_e_YIJ3zOEAoJRDe0c1(const PmSparsityPattern*b,const
PmBoolVector*mc_ID3sxM8zmIB_ZiazgNvWq2,const PmBoolVector*
pm_gq3kPpO4Hdv_0UBmX5sfB1,PmAllocator*mc_J3BYejxvpAX9ghSFCe0tN1);void
mc_UQyLykYxB6RfV3R5UafUE0(const PmRealVector*mc_hZWQ2ZXreN1MIi_7Oc0hF_,const
real_T*mc_He9JzoY7_Zv_2kVxHiuP90,const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,const PmBoolVector*mc_crpmV1NfytxB6epLFDbeY2,const
PmBoolVector*mc_l6yizd46ODo8FXwxtVTrF_);PmSparsityPattern*
mc_OvyDOAB_3upKwMOnK3EZV1(const PmSparsityPattern*pm_PJaAk_OAdWPbuizgCm_rK1,
size_t mc_N_EjeQp4WJPJRftR0Y3Cd1,size_t mc_iFeOP4BSbdQmZZgCGP03i0,size_t
mc_I98x_QlzPPBua1Isb8hyI0,size_t mc_Q968L5leQKUG_5PDr9DIY2,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*mc_dCGqQVZgg5nte_jY9_Cd01(const
PmSparsityPattern*pm_PJaAk_OAdWPbuizgCm_rK1,size_t mc_N_EjeQp4WJPJRftR0Y3Cd1,
size_t mc_iFeOP4BSbdQmZZgCGP03i0,size_t mc_I98x_QlzPPBua1Isb8hyI0,size_t
mc_Q968L5leQKUG_5PDr9DIY2,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
mc_oA0IbcqlgIdVsQKAmscwa0(const PmRealVector*mc_D8uN6coYCbZ1Qg6YMrSWl_,const
PmRealVector*mc_31d6WAc2j8nDPGeo8k4eo_,const PmSparsityPattern*
pm_PJaAk_OAdWPbuizgCm_rK1,size_t mc_N_EjeQp4WJPJRftR0Y3Cd1,size_t
mc_iFeOP4BSbdQmZZgCGP03i0,size_t mc_I98x_QlzPPBua1Isb8hyI0,size_t
mc_Q968L5leQKUG_5PDr9DIY2);void mc_zxKlKqk_QHLlgCOo_2ImC_(PmSparsityPattern*
mc__aqwF2UeMrHkDfRgGhMkr0,size_t n);void mc_Tdqt4n_f38OzgBkReWoiP1(
PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,size_t n);PmSparsityPattern*
mc_4gIlQP6_fYrNISbOZFNkP_(const PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
size_t n,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*
mc_83hy7P7oW7aRSDM7TcBsA2(const PmSparsityPattern*pm_Pc8_RQ7nsOlzNUh7aYI680,
size_t n,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);PmSparsityPattern*
mc_PPbEGaGW9CGqvjemmEymj2(const PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,
const PmSparsityPattern*mc_VcKY7m0QAr85hALPtvLmC2,PmAllocator*
pm_WFHqm0fOpgfhKZFbY5NWh2);void mc_SNiMSuxDEldsSjsl5k9Ry1(const PmRealVector*
mc_82a3DKJG1OnqEvQnRrma62,const PmSparsityPattern*mc_d9m7txhohSpkYAQKYp3sR1,
const PmRealVector*mc_frpbnk4Y0M4ZDQTQA_Say1,const PmSparsityPattern*
mc__aqwF2UeMrHkDfRgGhMkr0,const PmRealVector*mc_LvXhgCm6S5lTCS5qnZ0nL0,const
PmSparsityPattern*mc_VcKY7m0QAr85hALPtvLmC2,const PmRealVector*
mc_8oHKE_vHwVdaX05lQda_c1);PmSparsityPattern*mc_pPG5PIgnV_OuwvOl9CVnj_(const
PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,const PmSparsityPattern*
mc_VcKY7m0QAr85hALPtvLmC2,PmAllocator*pm_WFHqm0fOpgfhKZFbY5NWh2);void
mc_qmyb9URRq9IoJgMqa3xih1(const PmRealVector*mc_82a3DKJG1OnqEvQnRrma62,const
PmSparsityPattern*mc_d9m7txhohSpkYAQKYp3sR1,const PmRealVector*
mc_frpbnk4Y0M4ZDQTQA_Say1,const PmSparsityPattern*mc__aqwF2UeMrHkDfRgGhMkr0,
const PmRealVector*mc_LvXhgCm6S5lTCS5qnZ0nL0,const PmSparsityPattern*
mc_VcKY7m0QAr85hALPtvLmC2,const PmRealVector*mc_8oHKE_vHwVdaX05lQda_c1);
PmSparsityPattern*mc_LFaZy0_889U2Wsk9bwBoz1(const PmSparsityPattern*a,const
PmSparsityPattern*b,PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2);
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_linear_algebra(void);
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_rect_la(void);
#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_core_MWRIsrAoC66NYgRx_QWr82 NeDae;typedef struct
ssc_core_Y8I7htfZ70KizQ5bIs_sf2 ssc_core_GkLc1vDOD09gpAPEJHaFT_;typedef struct
ssc_core_u8s0sBRt_Z2G7min_SVGE_ ssc_core_XGgIsCtd1z1LHvGN74avH_;
#include "math.h"
#include "string.h"
boolean_T ssc_sli_BCaGDUfJ_rcOPNe83MPUF_(PmRealVector*
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,const PmRealVector*
ssc_sli_xAyBKV96ekiEfuhbh4Omh0,const PmRealVector*x,const PmRealVector*
ssc_sli_SZhonOpgcZahs9rBlFIv6_,const PmSparsityPattern*
ssc_sli_5o09eFtac71yuzRVtLhhP0,real_T ssc_sli_geKg_B0CcWrLFOGkyC1bm2){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0,mc_gN74BbsU5wqNjkJbC9b672=
ssc_sli_xAyBKV96ekiEfuhbh4Omh0->mN;mc_v7V5uZPqLRlsEpMCWsoMJ0(
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,-1.0,ssc_sli_xAyBKV96ekiEfuhbh4Omh0);
mc_WuGlfcFda9zO01qKeAxMn_(ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,
ssc_sli_SZhonOpgcZahs9rBlFIv6_,ssc_sli_5o09eFtac71yuzRVtLhhP0,x);for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_gN74BbsU5wqNjkJbC9b672;mc_SmSSPSQfR1qEYWsVj5ELF0++){if(fabs(
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1->mX[mc_SmSSPSQfR1qEYWsVj5ELF0])>
ssc_sli_geKg_B0CcWrLFOGkyC1bm2){return false;}}return true;}boolean_T
ssc_sli_rSmuVqtOn2ucXYxJk9Q5D1(PmRealVector*ssc_sli_xITzttsmbrCAOieuzz4ke_,
const PmRealVector*ssc_sli_4KfM_LiTB8Q2tueGeVh_V2,const PmSparsityPattern*
ssc_sli_1TZk8wUtYgxYCMnUhTo6Y2,PmRealVector*ssc_sli_cUDNFs2OIyQYltSPBT9ww_,
boolean_T ssc_sli__g6A5SqWi__FIyXPerwJq1,PmAllocator*mc_YMfc_eB3rHMVJUig1uu500
){const McLinearAlgebraFactory*ssc_sli_mtrxVDfH1giRjP_fn_GLu1=
ssc_sli__g6A5SqWi__FIyXPerwJq1?mc_get_csparse_linear_algebra():
mc_get_csparse_rect_la();McLinearAlgebra*ssc_sli_hWAHcsuAg4VvIe1q1qkLx0=NULL;
McLinearAlgebraStatus ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=MC_LA_OK;
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=ssc_sli_mtrxVDfH1giRjP_fn_GLu1->
mCreateLinearAlgebra(ssc_sli_mtrxVDfH1giRjP_fn_GLu1,&
ssc_sli_hWAHcsuAg4VvIe1q1qkLx0,ssc_sli_1TZk8wUtYgxYCMnUhTo6Y2);if(
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0!=MC_LA_OK){return false;}
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=ssc_sli_hWAHcsuAg4VvIe1q1qkLx0->mFactor(
ssc_sli_hWAHcsuAg4VvIe1q1qkLx0,ssc_sli_4KfM_LiTB8Q2tueGeVh_V2->mX);if(
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0!=MC_LA_OK){ssc_sli_hWAHcsuAg4VvIe1q1qkLx0->
mDestructor(ssc_sli_hWAHcsuAg4VvIe1q1qkLx0);return false;}
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=ssc_sli_hWAHcsuAg4VvIe1q1qkLx0->mSolve(
ssc_sli_hWAHcsuAg4VvIe1q1qkLx0,ssc_sli_4KfM_LiTB8Q2tueGeVh_V2->mX,
ssc_sli_xITzttsmbrCAOieuzz4ke_->mX,ssc_sli_cUDNFs2OIyQYltSPBT9ww_->mX);
ssc_sli_hWAHcsuAg4VvIe1q1qkLx0->mDestructor(ssc_sli_hWAHcsuAg4VvIe1q1qkLx0);
return ssc_sli_G9Ug5Uhj979D3_dBSwlTW0==MC_LA_OK;}boolean_T
ssc_sli_2eF7ZkVKGXn46jFHE5rhc2(PmRealVector*ssc_core_KO4NVhU1GJMCcllF9OlCo0,
const PmRealVector*ssc_sli_VHh7q26LSHqFMgOURIzm22,const PmRealVector*
ssc_sli_Kyh2UZhdKzt0jZSd_71Xg2,const PmSparsityPattern*
ssc_sli_3Q6oTWAkJxkMTiPCfp0gF0,PmRealVector*ssc_sli_xAyBKV96ekiEfuhbh4Omh0,
real_T ssc_sli_geKg_B0CcWrLFOGkyC1bm2,PmAllocator*mc_YMfc_eB3rHMVJUig1uu500){
boolean_T ssc_sli_G9Ug5Uhj979D3_dBSwlTW0;PmRealVector*
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,*x;size_t mc_SmSSPSQfR1qEYWsVj5ELF0,
ssc_sli_OxcgP1ypvBMlyQzEN_Uhj_=ssc_sli_VHh7q26LSHqFMgOURIzm22->mN,
ssc_sli_Dh5XLeffdc8iWC5BIqko62=ssc_sli_xAyBKV96ekiEfuhbh4Omh0->mN;
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1=pm_create_real_vector(
ssc_sli_Dh5XLeffdc8iWC5BIqko62,mc_YMfc_eB3rHMVJUig1uu500);x=
pm_create_real_vector(ssc_sli_OxcgP1ypvBMlyQzEN_Uhj_,mc_YMfc_eB3rHMVJUig1uu500
);mc_v7V5uZPqLRlsEpMCWsoMJ0(ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,-1.0,
ssc_sli_xAyBKV96ekiEfuhbh4Omh0);mc_WuGlfcFda9zO01qKeAxMn_(
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,ssc_sli_Kyh2UZhdKzt0jZSd_71Xg2,
ssc_sli_3Q6oTWAkJxkMTiPCfp0gF0,ssc_sli_VHh7q26LSHqFMgOURIzm22);
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=ssc_sli_rSmuVqtOn2ucXYxJk9Q5D1(x,
ssc_sli_Kyh2UZhdKzt0jZSd_71Xg2,ssc_sli_3Q6oTWAkJxkMTiPCfp0gF0,
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,false,mc_YMfc_eB3rHMVJUig1uu500);if(
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0){ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=
ssc_sli_BCaGDUfJ_rcOPNe83MPUF_(ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,x,ssc_sli_Kyh2UZhdKzt0jZSd_71Xg2,
ssc_sli_3Q6oTWAkJxkMTiPCfp0gF0,ssc_sli_geKg_B0CcWrLFOGkyC1bm2);if(
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0){for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<ssc_sli_OxcgP1ypvBMlyQzEN_Uhj_;
mc_SmSSPSQfR1qEYWsVj5ELF0++)ssc_core_KO4NVhU1GJMCcllF9OlCo0->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=ssc_sli_VHh7q26LSHqFMgOURIzm22->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]-x->mX[mc_SmSSPSQfR1qEYWsVj5ELF0];}}
pm_destroy_real_vector(x,mc_YMfc_eB3rHMVJUig1uu500);pm_destroy_real_vector(
ssc_sli_Q8VtzeoRIo_YV0krpDyRu1,mc_YMfc_eB3rHMVJUig1uu500);return
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0;}boolean_T ssc_sli_N7mrEmdGHb5kU6r7oeHa_0(
PmRealVector*x,const PmSparsityPattern*ssc_sli_3Q6oTWAkJxkMTiPCfp0gF0,const
PmRealVector*ssc_sli_Kyh2UZhdKzt0jZSd_71Xg2,const PmSparsityPattern*
ssc_sli_fxdlNqDRGG8e3EZ2JKLJq0,const PmRealVector*
ssc_sli_TWecJz5stbwsA0_XAWJbl_,const PmRealVector*
ssc_sli_qLxDhymCxe6YFr7HuwyWQ_,const PmRealVector*
ssc_sli_ks8rkpJYX5jHaEJjD6Z6h1,const PmRealVector*
ssc_sli_VHh7q26LSHqFMgOURIzm22,real_T ssc_sli_geKg_B0CcWrLFOGkyC1bm2){size_t
mc_SmSSPSQfR1qEYWsVj5ELF0;boolean_T ssc_sli_yzwJDqeRXvk84Olal_KT_1=false;const
size_t ssc_sli_OxcgP1ypvBMlyQzEN_Uhj_=ssc_sli_VHh7q26LSHqFMgOURIzm22->mN,n=
ssc_sli_qLxDhymCxe6YFr7HuwyWQ_->mN;PmAllocator*mc_YMfc_eB3rHMVJUig1uu500=
pm_default_allocator();PmRealVector*ssc_sli_cSrnKvYBwr5sJtVgheEdZ_,*
ssc_sli_K9hJE24ssIrrkr9yOYRLt0,*ssc_sli_xAyBKV96ekiEfuhbh4Omh0;
ssc_sli_cSrnKvYBwr5sJtVgheEdZ_=pm_create_real_vector(n,
mc_YMfc_eB3rHMVJUig1uu500);ssc_sli_K9hJE24ssIrrkr9yOYRLt0=
pm_create_real_vector(n,mc_YMfc_eB3rHMVJUig1uu500);
ssc_sli_xAyBKV96ekiEfuhbh4Omh0=pm_create_real_vector(n,
mc_YMfc_eB3rHMVJUig1uu500);for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<ssc_sli_OxcgP1ypvBMlyQzEN_Uhj_;
mc_SmSSPSQfR1qEYWsVj5ELF0++){ssc_sli_K9hJE24ssIrrkr9yOYRLt0->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=ssc_sli_VHh7q26LSHqFMgOURIzm22->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0];}pm_rv_equals_rv(ssc_sli_xAyBKV96ekiEfuhbh4Omh0,
ssc_sli_qLxDhymCxe6YFr7HuwyWQ_);mc_WuGlfcFda9zO01qKeAxMn_(
ssc_sli_xAyBKV96ekiEfuhbh4Omh0,ssc_sli_TWecJz5stbwsA0_XAWJbl_,
ssc_sli_fxdlNqDRGG8e3EZ2JKLJq0,ssc_sli_ks8rkpJYX5jHaEJjD6Z6h1);
ssc_sli_yzwJDqeRXvk84Olal_KT_1=ssc_sli_2eF7ZkVKGXn46jFHE5rhc2(
ssc_sli_cSrnKvYBwr5sJtVgheEdZ_,ssc_sli_K9hJE24ssIrrkr9yOYRLt0,
ssc_sli_Kyh2UZhdKzt0jZSd_71Xg2,ssc_sli_3Q6oTWAkJxkMTiPCfp0gF0,
ssc_sli_xAyBKV96ekiEfuhbh4Omh0,ssc_sli_geKg_B0CcWrLFOGkyC1bm2,
mc_YMfc_eB3rHMVJUig1uu500);if(ssc_sli_yzwJDqeRXvk84Olal_KT_1){for(
mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
ssc_sli_OxcgP1ypvBMlyQzEN_Uhj_;mc_SmSSPSQfR1qEYWsVj5ELF0++){x->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]=ssc_sli_cSrnKvYBwr5sJtVgheEdZ_->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0];}}pm_destroy_real_vector(
ssc_sli_xAyBKV96ekiEfuhbh4Omh0,mc_YMfc_eB3rHMVJUig1uu500);
pm_destroy_real_vector(ssc_sli_K9hJE24ssIrrkr9yOYRLt0,
mc_YMfc_eB3rHMVJUig1uu500);pm_destroy_real_vector(
ssc_sli_cSrnKvYBwr5sJtVgheEdZ_,mc_YMfc_eB3rHMVJUig1uu500);return
ssc_sli_yzwJDqeRXvk84Olal_KT_1;}boolean_T ssc_sli_GDD2Gp6w_weIyfcQ_Wxij_(
PmRealVector*x,const PmSparsityPattern*ssc_sli_5o09eFtac71yuzRVtLhhP0,const
PmRealVector*ssc_sli_SZhonOpgcZahs9rBlFIv6_,const PmSparsityPattern*
ssc_sli_sdv8J3cGRqltHukZtY_tm2,const PmRealVector*
ssc_sli_jat_gnM5w1Pc2zp4J9Dn61,const PmRealVector*
ssc_sli_aXC1_0_on2XdbeH1SpaIG2,const PmRealVector*
ssc_sli_ks8rkpJYX5jHaEJjD6Z6h1,real_T ssc_sli_geKg_B0CcWrLFOGkyC1bm2){const
double ssc_sli_nr4v4IY9eJyMUBBIDYmkm_=1.0e-8;PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500=pm_default_allocator();PmRealVector*
mc_8oHKE_vHwVdaX05lQda_c1,*ssc_sli__7ROOWNHPq49xfXRoq_9_1,*
ssc_sli_wnw9iGRUa4_6Ye85S_Vxd_;PmSparsityPattern*
ssc_sli_fHLfjGmEJy0TRXHbTEasB1,*ssc_sli_t65MrHtwp_qxOyo1z1Oxw0;size_t
mc_SmSSPSQfR1qEYWsVj5ELF0,mc_gN74BbsU5wqNjkJbC9b672=
ssc_sli_5o09eFtac71yuzRVtLhhP0->mNumRow;boolean_T
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0;if(mc_gN74BbsU5wqNjkJbC9b672==0){return true;};
ssc_sli_fHLfjGmEJy0TRXHbTEasB1=pm_LPeaDYoYWpCMrX0FHDZrj2(
mc_gN74BbsU5wqNjkJbC9b672,mc_gN74BbsU5wqNjkJbC9b672,mc_YMfc_eB3rHMVJUig1uu500)
;ssc_sli__7ROOWNHPq49xfXRoq_9_1=pm_create_real_vector(
mc_gN74BbsU5wqNjkJbC9b672,mc_YMfc_eB3rHMVJUig1uu500);mc_8oHKE_vHwVdaX05lQda_c1
=pm_create_real_vector(mc_gN74BbsU5wqNjkJbC9b672,mc_YMfc_eB3rHMVJUig1uu500);
for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;mc_SmSSPSQfR1qEYWsVj5ELF0<
mc_gN74BbsU5wqNjkJbC9b672;mc_SmSSPSQfR1qEYWsVj5ELF0++){
ssc_sli__7ROOWNHPq49xfXRoq_9_1->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]= -
ssc_sli_nr4v4IY9eJyMUBBIDYmkm_;}ssc_sli_t65MrHtwp_qxOyo1z1Oxw0=
mc_PPbEGaGW9CGqvjemmEymj2(ssc_sli_fHLfjGmEJy0TRXHbTEasB1,
ssc_sli_5o09eFtac71yuzRVtLhhP0,mc_YMfc_eB3rHMVJUig1uu500);
ssc_sli_wnw9iGRUa4_6Ye85S_Vxd_=pm_create_real_vector(((size_t)(
ssc_sli_t65MrHtwp_qxOyo1z1Oxw0)->mJc[(ssc_sli_t65MrHtwp_qxOyo1z1Oxw0)->mNumCol
]),mc_YMfc_eB3rHMVJUig1uu500);mc_SNiMSuxDEldsSjsl5k9Ry1(
ssc_sli_wnw9iGRUa4_6Ye85S_Vxd_,ssc_sli_t65MrHtwp_qxOyo1z1Oxw0,
ssc_sli_SZhonOpgcZahs9rBlFIv6_,ssc_sli_5o09eFtac71yuzRVtLhhP0,
ssc_sli__7ROOWNHPq49xfXRoq_9_1,ssc_sli_fHLfjGmEJy0TRXHbTEasB1,
mc_8oHKE_vHwVdaX05lQda_c1);mc_Rhhlgu4QH_WTKd_5kpe4I2(mc_8oHKE_vHwVdaX05lQda_c1
);mc_WuGlfcFda9zO01qKeAxMn_(mc_8oHKE_vHwVdaX05lQda_c1,
ssc_sli_jat_gnM5w1Pc2zp4J9Dn61,ssc_sli_sdv8J3cGRqltHukZtY_tm2,
ssc_sli_ks8rkpJYX5jHaEJjD6Z6h1);for(mc_SmSSPSQfR1qEYWsVj5ELF0=0;
mc_SmSSPSQfR1qEYWsVj5ELF0<mc_gN74BbsU5wqNjkJbC9b672;mc_SmSSPSQfR1qEYWsVj5ELF0
++){mc_8oHKE_vHwVdaX05lQda_c1->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]+=
ssc_sli_aXC1_0_on2XdbeH1SpaIG2->mX[mc_SmSSPSQfR1qEYWsVj5ELF0]+x->mX[
mc_SmSSPSQfR1qEYWsVj5ELF0]*ssc_sli_nr4v4IY9eJyMUBBIDYmkm_;}
mc_v7V5uZPqLRlsEpMCWsoMJ0(mc_8oHKE_vHwVdaX05lQda_c1,-1.0,
mc_8oHKE_vHwVdaX05lQda_c1);ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=
ssc_sli_rSmuVqtOn2ucXYxJk9Q5D1(x,ssc_sli_wnw9iGRUa4_6Ye85S_Vxd_,
ssc_sli_t65MrHtwp_qxOyo1z1Oxw0,mc_8oHKE_vHwVdaX05lQda_c1,true,
mc_YMfc_eB3rHMVJUig1uu500);if(ssc_sli_G9Ug5Uhj979D3_dBSwlTW0){
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=ssc_sli_BCaGDUfJ_rcOPNe83MPUF_(
ssc_sli__7ROOWNHPq49xfXRoq_9_1,mc_8oHKE_vHwVdaX05lQda_c1,x,
ssc_sli_wnw9iGRUa4_6Ye85S_Vxd_,ssc_sli_t65MrHtwp_qxOyo1z1Oxw0,
ssc_sli_geKg_B0CcWrLFOGkyC1bm2);}pm_destroy_real_vector(
ssc_sli_wnw9iGRUa4_6Ye85S_Vxd_,mc_YMfc_eB3rHMVJUig1uu500);
pm_06dTzOwkhN7oGBM_7J2hK1(ssc_sli_t65MrHtwp_qxOyo1z1Oxw0,
mc_YMfc_eB3rHMVJUig1uu500);pm_destroy_real_vector(mc_8oHKE_vHwVdaX05lQda_c1,
mc_YMfc_eB3rHMVJUig1uu500);pm_destroy_real_vector(
ssc_sli__7ROOWNHPq49xfXRoq_9_1,mc_YMfc_eB3rHMVJUig1uu500);
pm_06dTzOwkhN7oGBM_7J2hK1(ssc_sli_fHLfjGmEJy0TRXHbTEasB1,
mc_YMfc_eB3rHMVJUig1uu500);return ssc_sli_G9Ug5Uhj979D3_dBSwlTW0;}void
ssc_sli_UiJdX2NSr8Ud52TRnxOa51(void*ssc_sli_c87_pOkZyU1XLuGFljCiq_,
PmCharVector ssc_sli_m8FpSik4c5_zOvF6ZJsxL0){}boolean_T ic_solve_impl(
PmRealVector*x,const PmRealVector*mc_MJ6HaMWdyRxHm3p_EZiD41,const
ssc_sli_d9_27aAXZ1ygXoMJr5sTK0*ssc_sli_z0ZLRcfet_AHsL45JYPiy2,const
ssc_sli_AIgk9qyNVi5uKcJbFNYIR1*ssc_core_ZYWXY67LkEIFg_fAKXl61_,
ssc_core_5Z1inCkB2uIKKdlyf3XlZ0*ssc_core_5oGXXguX8Nt1GG4V0iIu11){static
ssc_sli_AIgk9qyNVi5uKcJbFNYIR1 ssc_sli_Sx5_MKACc6vDequuCUMiq2={NULL,
ssc_sli_UiJdX2NSr8Ud52TRnxOa51,ssc_sli_UiJdX2NSr8Ud52TRnxOa51};boolean_T
ssc_sli_nPeSamnms280SxSV7yfbC1,ssc_sli_8gcuIbpkmzQeEV4c_j8bn2,
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0;char ssc_sli_h2YFSqhsXylStjxe7G1DI0[16384];
PmCharVector ssc_sli_m8FpSik4c5_zOvF6ZJsxL0;const PmRealVector*
ssc_sli_VHh7q26LSHqFMgOURIzm22= &(ssc_sli_z0ZLRcfet_AHsL45JYPiy2->
ssc_sli_gp_x31PBpZSGk9lwf_YMF2);const ssc_sli_OZp3BoovP9hz1c3QP_4KZ1*
ssc_sli_Ue6rjgVcbuJHwhLL3BdXu1= &(ssc_sli_z0ZLRcfet_AHsL45JYPiy2->
ssc_sli_C3TKwX8RBAYn1kmr_2usY2);const ssc_sli_OZp3BoovP9hz1c3QP_4KZ1*
ssc_sli_WZdEAue4Ydsnt_DQ_RKyy0= &(ssc_sli_z0ZLRcfet_AHsL45JYPiy2->
ssc_sli_E6k7McF_Vl6CmqEsbI8mE1);const ssc_sli_lCpfWX_wXDHmqxsOyLDte0*
ssc_sli_v0M3_qI_ikpyt5_iH_myW0= &(ssc_sli_z0ZLRcfet_AHsL45JYPiy2->
ssc_sli_bqs36EqSOESDXU5wkjWP42);real_T ssc_sli_geKg_B0CcWrLFOGkyC1bm2=
ssc_sli_z0ZLRcfet_AHsL45JYPiy2->ssc_sli_ebbbRH7XaAiHCUUa7Z78P0;boolean_T
ssc_sli__g6A5SqWi__FIyXPerwJq1=ssc_sli_z0ZLRcfet_AHsL45JYPiy2->
ssc_core_XL_gZqocnFSK6dfns5Qdk2;ssc_core_W6s6ejAuxmf3Rn5u3Prmo1
ssc_core_MFU8AZc1sVWww5aGi0_bW1=(ssc_core_5oGXXguX8Nt1GG4V0iIu11)->
ssc_core_jcnGpJQgTcmoivKt9gMXJ2((ssc_core_5oGXXguX8Nt1GG4V0iIu11));
ssc_sli_m8FpSik4c5_zOvF6ZJsxL0 .mN=16384;ssc_sli_m8FpSik4c5_zOvF6ZJsxL0 .mX=
ssc_sli_h2YFSqhsXylStjxe7G1DI0;if(ssc_core_ZYWXY67LkEIFg_fAKXl61_==NULL)
ssc_core_ZYWXY67LkEIFg_fAKXl61_= &ssc_sli_Sx5_MKACc6vDequuCUMiq2;
ssc_sli_nPeSamnms280SxSV7yfbC1=ssc_sli_N7mrEmdGHb5kU6r7oeHa_0(x,&
ssc_sli_Ue6rjgVcbuJHwhLL3BdXu1->ssc_sli_JxZ2lkwyBUm5ZftOVAJXZ0,&
ssc_sli_Ue6rjgVcbuJHwhLL3BdXu1->ssc_sli_FqX9Sf4omHsO4fZT08Pfn2,&
ssc_sli_Ue6rjgVcbuJHwhLL3BdXu1->ssc_sli_M1B7ldbMD2AZKJltYjWSF_,&
ssc_sli_Ue6rjgVcbuJHwhLL3BdXu1->ssc_sli_t_pDylaBmAxguE6KJ9YXz0,&
ssc_sli_Ue6rjgVcbuJHwhLL3BdXu1->ssc_sli_8GS41MzlE5XJondPh_gjk1,
mc_MJ6HaMWdyRxHm3p_EZiD41,ssc_sli_VHh7q26LSHqFMgOURIzm22,
ssc_sli_geKg_B0CcWrLFOGkyC1bm2);ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=
ssc_sli_nPeSamnms280SxSV7yfbC1;if(!ssc_sli_nPeSamnms280SxSV7yfbC1){if(!
ssc_sli__g6A5SqWi__FIyXPerwJq1){pmf_warning(ssc_sli_z8JnA55sA_IR2MbuPWpVm1 .
ssc_sli_MAZejEIE7f5iDR2USo5EO_.ssc_sli_fFU87dPt5fNvCNNxLyMDy1);strcpy(
ssc_sli_m8FpSik4c5_zOvF6ZJsxL0 .mX,"");ssc_core_ZYWXY67LkEIFg_fAKXl61_->
ssc_sli_YMj_lFUyMUAQ5NGHKzTbq2(ssc_core_ZYWXY67LkEIFg_fAKXl61_->
ssc_sli_MViN0FmkzA0TTrsEIwoW90,ssc_sli_m8FpSik4c5_zOvF6ZJsxL0);if(strlen(
ssc_sli_m8FpSik4c5_zOvF6ZJsxL0 .mX)>0){pmf_warning(
ssc_sli_z8JnA55sA_IR2MbuPWpVm1 .ssc_sli_MAZejEIE7f5iDR2USo5EO_.
ssc_sli_dgoUPzmmdVFRzxGXV0UOu0,ssc_sli_m8FpSik4c5_zOvF6ZJsxL0 .mX);}}
ssc_sli_8gcuIbpkmzQeEV4c_j8bn2=ssc_sli_N7mrEmdGHb5kU6r7oeHa_0(x,&
ssc_sli_WZdEAue4Ydsnt_DQ_RKyy0->ssc_sli_JxZ2lkwyBUm5ZftOVAJXZ0,&
ssc_sli_WZdEAue4Ydsnt_DQ_RKyy0->ssc_sli_FqX9Sf4omHsO4fZT08Pfn2,&
ssc_sli_WZdEAue4Ydsnt_DQ_RKyy0->ssc_sli_M1B7ldbMD2AZKJltYjWSF_,&
ssc_sli_WZdEAue4Ydsnt_DQ_RKyy0->ssc_sli_t_pDylaBmAxguE6KJ9YXz0,&
ssc_sli_WZdEAue4Ydsnt_DQ_RKyy0->ssc_sli_8GS41MzlE5XJondPh_gjk1,
mc_MJ6HaMWdyRxHm3p_EZiD41,ssc_sli_VHh7q26LSHqFMgOURIzm22,
ssc_sli_geKg_B0CcWrLFOGkyC1bm2);if(!ssc_sli_8gcuIbpkmzQeEV4c_j8bn2){if(!
ssc_sli__g6A5SqWi__FIyXPerwJq1){pmf_warning(ssc_sli_z8JnA55sA_IR2MbuPWpVm1 .
ssc_sli_MAZejEIE7f5iDR2USo5EO_.ssc_sli__SJ2w4HE2QzJ_m1x11yQD1);}
pm_rv_equals_rv(x,ssc_sli_VHh7q26LSHqFMgOURIzm22);}
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=true;}if(ssc_sli__g6A5SqWi__FIyXPerwJq1){
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0=ssc_sli_GDD2Gp6w_weIyfcQ_Wxij_(x,&
ssc_sli_v0M3_qI_ikpyt5_iH_myW0->ssc_sli_J37SNUIXrn9q_Uqqr__A2_,&
ssc_sli_v0M3_qI_ikpyt5_iH_myW0->ssc_sli_xoYj2toK8NmTQpPypjeyn_,&
ssc_sli_v0M3_qI_ikpyt5_iH_myW0->ssc_sli_N0jibk_xX5GD3sK50rvWm1,&
ssc_sli_v0M3_qI_ikpyt5_iH_myW0->ssc_sli_NG3w5CynTNKkm1WIm54z20,&
ssc_sli_v0M3_qI_ikpyt5_iH_myW0->ssc_sli_FCKGBPh971dGh1fbE6Ltb2,
mc_MJ6HaMWdyRxHm3p_EZiD41,ssc_sli_geKg_B0CcWrLFOGkyC1bm2);}if(
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0){(ssc_core_5oGXXguX8Nt1GG4V0iIu11)->
ssc_core_dIxsRfQPvJkJ8GAzpkhG_2((ssc_core_5oGXXguX8Nt1GG4V0iIu11),(
ssc_core_MFU8AZc1sVWww5aGi0_bW1));}else{ssc_core_ngsKQfybc3dXXgWu3kMDK_(
ssc_core_5oGXXguX8Nt1GG4V0iIu11,ssc_core_MFU8AZc1sVWww5aGi0_bW1,
ssc_core_A054j0gk4AqU55YWXLdcE_,ssc_sli_z8JnA55sA_IR2MbuPWpVm1 .
ssc_sli_MAZejEIE7f5iDR2USo5EO_.ssc_sli_qJh5yfAB8O7_fq_jNvpod0);}return
ssc_sli_G9Ug5Uhj979D3_dBSwlTW0;}
