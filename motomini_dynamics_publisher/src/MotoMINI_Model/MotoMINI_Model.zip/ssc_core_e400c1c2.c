#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
struct ssc_core_TveuOuuz_7rSXp2jMuHzn2{struct{char const*
ssc_core_YXzkxYJn9NSiN9Z9bDN_j1;char const*ssc_core_PyUkBbSYvh9M0tfDeehhs2;
char const*ssc_core_hVyoAoVUeTlBzzjEN4Tes_;}ssc_core_TvdcT1Skb8XmnvysdU4cU1;
struct{struct{struct{char const*ssc_core_afltH4h6Y_5kACV060SCR2;char const*
ssc_core_HkU0IkxQsDOkHqd7RUMmT0;char const*ssc_core_fUmAhsv_bzCmd4MeOOwL51;}
ssc_core_sV18S3m11NyjodVa5teRF1;}ssc_core_JKyUfD2hlK50xsO6jdDBG2;struct{char
const*ssc_core_fku74wkl_klvkcPCC_RMP1;char const*
ssc_core_f4JO4uNoJYl4SZasUs4fH1;}ssc_core_YbAZHUrYJkFvZaGQE42QM0;}
ssc_core_P9dPVvlqCKCFiKaxNQkV00;struct{struct{char const*
ssc_core_evBXO0cl8H40083K_ej0W1;char const*ssc_core_06H4MmadY58Pg0pmNdH4Y2;
char const*ssc_core_Vy0U27_sculur0R7s9tbc1;}ssc_core_EP2woV9oGli0eqVfqSdHN0;}
ssc_core_4ZVoyR3TlhdtIJBBDfVfF1;struct{char const*mc__lerGssn0Ru_r3kSOzEmI_;
char const*mc_8ksqc0VFHLjSHzNxXK8mN0;char const*
ssc_core_CH6pya__frGySt3NjsQiR2;char const*ssc_core_BOXZTEAmCrs_EsW1Z7QvC0;
char const*ssc_core_JE7u1GWR9b6PFfJMTZ5DN2;}ssc_core_j6qjQjZ2uFDAoy7ab2fmT2;};
extern struct ssc_core_TveuOuuz_7rSXp2jMuHzn2 ssc_core_I0_CyOiADc_VeNAqMLy092;
struct ssc_core_TveuOuuz_7rSXp2jMuHzn2 ssc_core_I0_CyOiADc_VeNAqMLy092={{
"... (Truncated error message at maximum length of buffer.)\n",
"Unexpected internal error: diagnostic error message requested but tree is empty."
,"%s",},{{{"Constraints are inconsistent.","States are inconsistent.",
"Orthogonal projection is singular.",},},{"Dynamic states are not consistent."
,"Failed to satisfy dynamic state constraints.",},},{{"Equation location is:",
"line %s","(no line number info)",},},{"Alice","Bob","Chris eats %s","Dan",
"Ernie",},};
