#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_core_KNcJ1jU8piEi_2g0Ydzzo2 ssc_core_L4FImzp6iu_cikM_QSiOq1
;typedef struct ssc_core_mxYVgQYwCLIPwD6arnF2g0 ssc_core_5Z1inCkB2uIKKdlyf3XlZ0
;typedef enum{ssc_core_PQvF_V2l5jTui_cnayCtx1= -1,
ssc_core_A054j0gk4AqU55YWXLdcE_,ssc_core_Pb8JUwx4ywPtUw65I_hnN2,
ssc_core_Nrc9kYdGOx7oW_IqsZeAq2}ssc_core_5lRuVpDVc6bG2IVKfGVqN_;typedef struct
ssc_core_h3W2Es5Dd5ECkBBGihhpy2 ssc_core_jEm68s33g57Of0sNBmgop_;typedef struct
ssc_core_FPoEjIXZi6eDu_NJnUUwA0 ssc_core_BNjWAgMJ0Mukk_YOIqL5n1;struct
ssc_core_h3W2Es5Dd5ECkBBGihhpy2{ssc_core_BNjWAgMJ0Mukk_YOIqL5n1*mPrivateData;
void(*mc_2FQxl16aJPaXJJesMoqWt0)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0,ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_k_j2lx8W_dda_yvKS1xp7_);ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_wsXdF7Y4tIGroeVw6EQeX2)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0);ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_p6I2CZ7dMpbzsp9WeGsko_)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0);ssc_core_L4FImzp6iu_cikM_QSiOq1*(*
ssc_core_xK_kmwIp2VMJ2wdR_CPlX2)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0,size_t n);size_t(*
ssc_core_jSsiqJwfr5ffaYw4Jon_M_)(ssc_core_jEm68s33g57Of0sNBmgop_*
ssc_core_hPvEE3EAaw3i03g01xCqv0);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
ssc_core_jEm68s33g57Of0sNBmgop_*ssc_core_hPvEE3EAaw3i03g01xCqv0);};
ssc_core_jEm68s33g57Of0sNBmgop_*ssc_core_JslMZiKqcnP95ggOb5exk_(PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500);
#include "pm_std.h"
#include "string.h"
struct ssc_core_FPoEjIXZi6eDu_NJnUUwA0{PmAllocator*
ssc_core__4I9iHUhzuzbTikLaqzp02;size_t ssc_core_y2_VlEULF0es_m6LHpskE1;size_t
ssc_core_iQHdtVCXMx80N476XkQRS0;ssc_core_L4FImzp6iu_cikM_QSiOq1**
ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0;};static void ssc_core__PhSlRGygoUrBLjcCdD9B2(
ssc_core_jEm68s33g57Of0sNBmgop_*mc_ZxltZcnt1eSoyJTnrOm7z2,
ssc_core_L4FImzp6iu_cikM_QSiOq1*ssc_core_k_j2lx8W_dda_yvKS1xp7_){if(
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_iQHdtVCXMx80N476XkQRS0>=
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_y2_VlEULF0es_m6LHpskE1){
ssc_core_L4FImzp6iu_cikM_QSiOq1**ssc_core_U938Ucreg_Pd41Eh8sAbX1=
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0;;
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_y2_VlEULF0es_m6LHpskE1*=2;
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0=(
ssc_core_L4FImzp6iu_cikM_QSiOq1**)((mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core__4I9iHUhzuzbTikLaqzp02)->mCallocFcn((mc_ZxltZcnt1eSoyJTnrOm7z2->
mPrivateData->ssc_core__4I9iHUhzuzbTikLaqzp02),(sizeof(
ssc_core_L4FImzp6iu_cikM_QSiOq1*)),(mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core_y2_VlEULF0es_m6LHpskE1)));memcpy(mc_ZxltZcnt1eSoyJTnrOm7z2->
mPrivateData->ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0,ssc_core_U938Ucreg_Pd41Eh8sAbX1,
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_iQHdtVCXMx80N476XkQRS0*
sizeof(ssc_core_L4FImzp6iu_cikM_QSiOq1*));{void*
ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(ssc_core_U938Ucreg_Pd41Eh8sAbX1);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core__4I9iHUhzuzbTikLaqzp02)->mFreeFcn(mc_ZxltZcnt1eSoyJTnrOm7z2->
mPrivateData->ssc_core__4I9iHUhzuzbTikLaqzp02,ssc_core_GAbHnJspJ6sMhe_Yzxehb_)
;}};};mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0
[(mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_iQHdtVCXMx80N476XkQRS0)++]
=ssc_core_k_j2lx8W_dda_yvKS1xp7_;}static ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_yu8fEse7Dk1jaHIvMIE0f_(ssc_core_jEm68s33g57Of0sNBmgop_*
mc_ZxltZcnt1eSoyJTnrOm7z2){;;return mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0[--(mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core_iQHdtVCXMx80N476XkQRS0)];}static ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_Kh7EuN9a4Jy6yvEeAJpge2(ssc_core_jEm68s33g57Of0sNBmgop_*
mc_ZxltZcnt1eSoyJTnrOm7z2,size_t ssc_core_PIqWtbzrbQqv_KS_31HnE2){;;return
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0[
ssc_core_PIqWtbzrbQqv_KS_31HnE2];}static ssc_core_L4FImzp6iu_cikM_QSiOq1*
ssc_core_OczHRrs8B0hzpJwRmNsLe1(ssc_core_jEm68s33g57Of0sNBmgop_*
mc_ZxltZcnt1eSoyJTnrOm7z2){size_t n=mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core_iQHdtVCXMx80N476XkQRS0;if(n>0){return ssc_core_Kh7EuN9a4Jy6yvEeAJpge2
(mc_ZxltZcnt1eSoyJTnrOm7z2,n-1);}else{return NULL;}}static size_t
ssc_core_9Xrtc415PY5n4CHB8pNYJ2(ssc_core_jEm68s33g57Of0sNBmgop_*
mc_ZxltZcnt1eSoyJTnrOm7z2){return mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core_iQHdtVCXMx80N476XkQRS0;}static void ssc_core_zhwET1R_gIkLTDmIIaieh1(
ssc_core_jEm68s33g57Of0sNBmgop_*mc_ZxltZcnt1eSoyJTnrOm7z2){PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500=mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->
ssc_core__4I9iHUhzuzbTikLaqzp02;{void*ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(
mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData->ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};{void*
ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};{void*
ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(mc_ZxltZcnt1eSoyJTnrOm7z2);if(
ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(mc_YMfc_eB3rHMVJUig1uu500)->mFreeFcn(
mc_YMfc_eB3rHMVJUig1uu500,ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};}
ssc_core_jEm68s33g57Of0sNBmgop_*ssc_core_JslMZiKqcnP95ggOb5exk_(PmAllocator*
mc_YMfc_eB3rHMVJUig1uu500){ssc_core_jEm68s33g57Of0sNBmgop_*
mc_ZxltZcnt1eSoyJTnrOm7z2=(ssc_core_jEm68s33g57Of0sNBmgop_*)((
mc_YMfc_eB3rHMVJUig1uu500)->mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(
ssc_core_jEm68s33g57Of0sNBmgop_)),(1)));ssc_core_BNjWAgMJ0Mukk_YOIqL5n1*
mc_6peHhhgu8wo0Kp3HDh_aI0=(ssc_core_BNjWAgMJ0Mukk_YOIqL5n1*)((
mc_YMfc_eB3rHMVJUig1uu500)->mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(
ssc_core_BNjWAgMJ0Mukk_YOIqL5n1)),(1)));const size_t
ssc_core_rX8o5iiCyWpHpduA5nzye_=5;mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core__4I9iHUhzuzbTikLaqzp02=mc_YMfc_eB3rHMVJUig1uu500;
mc_6peHhhgu8wo0Kp3HDh_aI0->ssc_core_y2_VlEULF0es_m6LHpskE1=
ssc_core_rX8o5iiCyWpHpduA5nzye_;mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core_iQHdtVCXMx80N476XkQRS0=0;mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core_YJjUFjmXq2ZZOUWxE_w5Q0=(ssc_core_L4FImzp6iu_cikM_QSiOq1**)((
mc_YMfc_eB3rHMVJUig1uu500)->mCallocFcn((mc_YMfc_eB3rHMVJUig1uu500),(sizeof(
ssc_core_L4FImzp6iu_cikM_QSiOq1*)),(mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core_y2_VlEULF0es_m6LHpskE1)));mc_ZxltZcnt1eSoyJTnrOm7z2->mPrivateData=
mc_6peHhhgu8wo0Kp3HDh_aI0;mc_ZxltZcnt1eSoyJTnrOm7z2->mc_2FQxl16aJPaXJJesMoqWt0
= &ssc_core__PhSlRGygoUrBLjcCdD9B2;mc_ZxltZcnt1eSoyJTnrOm7z2->
ssc_core_wsXdF7Y4tIGroeVw6EQeX2= &ssc_core_yu8fEse7Dk1jaHIvMIE0f_;
mc_ZxltZcnt1eSoyJTnrOm7z2->ssc_core_p6I2CZ7dMpbzsp9WeGsko_= &
ssc_core_OczHRrs8B0hzpJwRmNsLe1;mc_ZxltZcnt1eSoyJTnrOm7z2->
ssc_core_xK_kmwIp2VMJ2wdR_CPlX2= &ssc_core_Kh7EuN9a4Jy6yvEeAJpge2;
mc_ZxltZcnt1eSoyJTnrOm7z2->ssc_core_jSsiqJwfr5ffaYw4Jon_M_= &
ssc_core_9Xrtc415PY5n4CHB8pNYJ2;mc_ZxltZcnt1eSoyJTnrOm7z2->
mc_YCFci8IAJkK9w_xpRtHta2= &ssc_core_zhwET1R_gIkLTDmIIaieh1;return
mc_ZxltZcnt1eSoyJTnrOm7z2;}
