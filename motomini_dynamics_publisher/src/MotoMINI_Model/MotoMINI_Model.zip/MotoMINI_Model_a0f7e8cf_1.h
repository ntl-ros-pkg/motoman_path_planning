/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'MotoMINI_Model/Yaskawa Motomini/World/Solver Configuration'.
 */

#ifndef __MotoMINI_Model_a0f7e8cf_1_h__
#define __MotoMINI_Model_a0f7e8cf_1_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void MotoMINI_Model_a0f7e8cf_1_dae( NeDae **dae, const
    NeModelParameters
    *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}
#endif
#endif
