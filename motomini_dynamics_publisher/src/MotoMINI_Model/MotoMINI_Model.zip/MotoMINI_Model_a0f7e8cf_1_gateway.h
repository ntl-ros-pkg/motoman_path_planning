/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'MotoMINI_Model/Yaskawa Motomini/World/Solver Configuration'.
 */

#ifndef __MotoMINI_Model_a0f7e8cf_1_gateway_h__
#define __MotoMINI_Model_a0f7e8cf_1_gateway_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void MotoMINI_Model_a0f7e8cf_1_gateway(void);

#ifdef __cplusplus

}
#endif
#endif                     /* #ifndef __MotoMINI_Model_a0f7e8cf_1_gateway_h__ */
