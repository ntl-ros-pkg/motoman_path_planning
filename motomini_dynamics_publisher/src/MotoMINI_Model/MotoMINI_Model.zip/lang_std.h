#ifndef __lang_std_h__
#define __lang_std_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef void*PMValue;typedef const void*ConstPMValue;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __lang_std_h__ */
