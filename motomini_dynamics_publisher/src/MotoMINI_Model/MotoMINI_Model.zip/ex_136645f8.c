#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_8GXoVYNB7xMB70dsCbAyA0(const real_T*a,const size_t n);real_T
ex_N_clXqffVCzi68eTuA7Z92(const real_T x);void ex_hvjqVE7WfEAt6jcTNsW1u1(
real_T*fx1,real_T*ex_qqj_9pClxpUaveq616vWX_,real_T*ex_ODvhPeUiIMv_N9a0J2IIb_,
real_T*ex_LoObIqjlDGtLzUnGZVFIh_,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51,const size_t
ex_VkP8sW5ujEbh_RG29El9R_,const size_t ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t
ex_2Y91_CRjyUMrCFE4844Jf2,const size_t ex_Ea66QGACnnAzBr5cQEISd_,const size_t
ex_Lyxgt0ApsOxYV7SxIdPws0,const size_t ex_FWzS4LG9JH3q_zkgeM_bR_,const size_t
ex_B6u9Yh3NFQBXCHXd_cy3L1,const size_t ex_2VFGnsOS8QAJGmX42jhDs2,const real_T
ex_9R2ICyFZrMWnnqVz69LS_0);void ex_8Lr4A0sHb9kykh8D_nd4y1(real_T*
ex_fIUN8VRWYW_vvrJBW8lXr0,real_T*ex_CC2nBop_AzM8GWVhi5l_y_,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51,const size_t ex_VkP8sW5ujEbh_RG29El9R_,const size_t
ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t ex_2Y91_CRjyUMrCFE4844Jf2,const size_t
ex_Ea66QGACnnAzBr5cQEISd_,const size_t ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t
ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t ex_tgAG8_0Nazq7r3JqH9poq_,const size_t
ex_DZjm31wkoWuZA_gQ2ngh90,const size_t ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t
ex_Crw725fjFuk9WoyqNW5D90,const size_t ex_216LSH5aKi96he3yzgTIY2,const size_t
ex_5mllB3D9zrHViNrvMthgP_,const real_T ex_9R2ICyFZrMWnnqVz69LS_0,const real_T
ex_Cx97aITo5DLOpdlBjw0Ev2);void ex_c908i9DZYVP8NLFJeVsnP_(real_T*
ex_dWVCFoCXPoLwscxjXxh7F0,real_T*ex_t0DOW86Hne7Cet0k6nxk50,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const real_T*ex_spvq_BLax0ZY7BWNVJdV3_,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t ex_KTkrfjRMBsZjPvzwkIouc_,const size_t
ex_x_teXoaz0hlS1RzJxhHla0,const size_t ex_fo8lU9fQuflzUTvG3MoQ51,const size_t
ex_VkP8sW5ujEbh_RG29El9R_,const size_t ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t
ex_2Y91_CRjyUMrCFE4844Jf2,const size_t ex_Ea66QGACnnAzBr5cQEISd_,const size_t
ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t
ex_tgAG8_0Nazq7r3JqH9poq_,const size_t ex_DZjm31wkoWuZA_gQ2ngh90,const size_t
ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t ex_Crw725fjFuk9WoyqNW5D90,const size_t
ex_216LSH5aKi96he3yzgTIY2,const size_t ex_5mllB3D9zrHViNrvMthgP_,const size_t
ex_dfsGKZ4SOnBWg0_LthaSE1,const size_t ex_f_G4CiEEGpLNC_d__6Otr_,const size_t
ex_sPax9bjJmVREGHAn0mqfe1,const size_t ex_V_jgHYQ6HxaicixaD4B4m_,const real_T
ex_9R2ICyFZrMWnnqVz69LS_0,const real_T ex_Cx97aITo5DLOpdlBjw0Ev2,const real_T
ex_wtdXVMGIS6xhoVmY9M2nE0);void ex_g6tFmYqTirCa3ZPS1u16h0(real_T*
ex_X3vLkYlbdpuLDjBGk57vo_,real_T*ex_WV0gRaOXjiFGQaR18XBfo_,const real_T*
ex_ODvhPeUiIMv_N9a0J2IIb_,const real_T*ex_qqj_9pClxpUaveq616vWX_,const real_T*
ex_bV4aNk1wGsZsv9PfSG7ML_,const real_T*ex_spvq_BLax0ZY7BWNVJdV3_,const real_T*
ex_YZ_rgSdzO2vZDxo7EhthC1,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51,const size_t ex_VkP8sW5ujEbh_RG29El9R_,const size_t
ex_w9siNcZ8q9Ps4bukNuo6T2,const size_t ex_2Y91_CRjyUMrCFE4844Jf2,const size_t
ex_Ea66QGACnnAzBr5cQEISd_,const size_t ex_zAvn4SDXaXE1tRMzhVx8u0,const size_t
ex_dCQH4g_NXK9XSd2Vv9I7R2,const size_t ex_tgAG8_0Nazq7r3JqH9poq_,const size_t
ex_DZjm31wkoWuZA_gQ2ngh90,const size_t ex_LX8MDhfG0H3nvIAZ7b1xv2,const size_t
ex_Crw725fjFuk9WoyqNW5D90,const size_t ex_216LSH5aKi96he3yzgTIY2,const size_t
ex_5mllB3D9zrHViNrvMthgP_,const size_t ex_dfsGKZ4SOnBWg0_LthaSE1,const size_t
ex_f_G4CiEEGpLNC_d__6Otr_,const size_t ex_sPax9bjJmVREGHAn0mqfe1,const size_t
ex_V_jgHYQ6HxaicixaD4B4m_,const size_t ex_U9lWWqx0jFokA4xwwiPb71,const size_t
ex_2rLQUCwyQWFWspPbF4UpE2,const size_t ex_BL4aaq_PAxk1Nxu_rJOWw0,const size_t
ex_y90_D_qMktK1Fkn1BdLpK2,const real_T ex_9R2ICyFZrMWnnqVz69LS_0,const real_T
ex_Cx97aITo5DLOpdlBjw0Ev2,const real_T ex_wtdXVMGIS6xhoVmY9M2nE0,const real_T
ex_Wu5vsdT_Yw4IM6TngEpjz1);size_t ex_EPCusphBPNYsP9i21jsva0(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_XPTig2EtwH6R7_NgNRUTK0,const boolean_T
ex_Qmu676yE9oxL758xSv1lO1);size_t ex_XgFqE_qWosDa601lsTn6b1(const real_T*x,
const size_t n,const real_T t);void ex_58tHK_FJLrTVg5pTR2KLX0(real_T*
ex__lerGssn0Ru_r3kSOzEmI_,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_G5C_Yq8nLf6PL2EMNiFAc1,const size_t
ex_KTkrfjRMBsZjPvzwkIouc_,const size_t ex_x_teXoaz0hlS1RzJxhHla0,const size_t
ex_fo8lU9fQuflzUTvG3MoQ51);void ex_kxquG9pkEjt4fXtMQOsqG2(real_T*x,real_T*f,
const size_t n);void ex_nC4jUddYFsKRLzFkVBm3G0(real_T*x1,real_T*x2,real_T*f,
const size_t n1,const size_t n2);void ex_p_64ouPbD9bddOkoAZOpZ1(real_T*x1,
real_T*x2,real_T*x3,real_T*f,const size_t n1,const size_t n2,const size_t n3);
void ex_5NKaAbmUyQr1tleeDl4Vc2(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*
f,const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "pm_std.h"
#include "lang_std.h"
#include "string.h"
static void ex_WGHw9K_F4Ex0dN1kGCLmw2(real_T*fi,const real_T*H,const real_T*Hx
,const real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const
real_T*f,const real_T*fx,const boolean_T*mode,const size_t*n,const real_T
ex_XPTig2EtwH6R7_NgNRUTK0,const boolean_T ex_Qmu676yE9oxL758xSv1lO1);static
void ex_uC_V3EfyiPI_fcdlh0knx1(real_T*x,real_T*f,real_T*fx,real_T*bv,const
real_T*xs,const real_T*fs,const size_t n);void tlu2_1d_akima_nearest_process(
real_T*x,real_T*f,real_T*fx,real_T*bv,const real_T*xs,const real_T*fs,const
size_t*n){ex_uC_V3EfyiPI_fcdlh0knx1(x,f,fx,bv,xs,fs,*n);}void
tlu2_1d_akima_nearest_process_custom_function_(void*out,const void*in){const
real_T*xs=(const real_T*)((const void*const*)in)[0];const real_T*fs=(const
real_T*)((const void*const*)in)[1];const size_t*n=(const size_t*)((const void*
const*)in)[2];real_T*x=(real_T*)((void**)out)[0];real_T*f=(real_T*)((void**)
out)[1];real_T*fx=(real_T*)((void**)out)[2];real_T*bv=(real_T*)((void**)out)[3
];tlu2_1d_akima_nearest_process(x,f,fx,bv,xs,fs,n);}void
tlu2_1d_akima_linear_process(real_T*x,real_T*f,real_T*fx,real_T*bv,const real_T
*xs,const real_T*fs,const size_t*n){ex_uC_V3EfyiPI_fcdlh0knx1(x,f,fx,bv,xs,fs,
*n);}void tlu2_1d_akima_linear_process_custom_function_(void*out,const void*in
){const real_T*xs=(const real_T*)((const void*const*)in)[0];const real_T*fs=(
const real_T*)((const void*const*)in)[1];const size_t*n=(const size_t*)((const
void*const*)in)[2];real_T*x=(real_T*)((void**)out)[0];real_T*f=(real_T*)((void
**)out)[1];real_T*fx=(real_T*)((void**)out)[2];real_T*bv=(real_T*)((void**)out
)[3];tlu2_1d_akima_linear_process(x,f,fx,bv,xs,fs,n);}static void
ex_uC_V3EfyiPI_fcdlh0knx1(real_T*x,real_T*f,real_T*fx,real_T*bv,const real_T*
xs,const real_T*fs,const size_t n){const real_T ex_yS7VvSIKrGg9ddzBqHtUd_=
1.0e-12;real_T*ex_w_oCkEWPNmlVJvldp25MJ1=pmf_calloc(n-1,sizeof(real_T));real_T
*ex_EmlJ8S26XlbOCyZiCkwA11=pmf_calloc(n+1,sizeof(real_T));real_T*
ex_cOnNpZibruamLe7g_F6N3_=pmf_calloc(n+2,sizeof(real_T));real_T
ex_4AO9K2_NQw9OWwOYDDTSh0,ex_ER1h_1EVPL8fiwyFSpjD92;memcpy(x,xs,n*sizeof(
real_T));memcpy(f,fs,n*sizeof(real_T));ex_kxquG9pkEjt4fXtMQOsqG2(x,f,n);bv[0]=
x[0];bv[1]=x[n-1];ex_4AO9K2_NQw9OWwOYDDTSh0=ex_N_clXqffVCzi68eTuA7Z92(x[n-1]-x
[0])+ex_yS7VvSIKrGg9ddzBqHtUd_;ex_ER1h_1EVPL8fiwyFSpjD92=
ex_8GXoVYNB7xMB70dsCbAyA0(f,n)+ex_yS7VvSIKrGg9ddzBqHtUd_;
ex_hvjqVE7WfEAt6jcTNsW1u1(fx,ex_cOnNpZibruamLe7g_F6N3_,
ex_w_oCkEWPNmlVJvldp25MJ1,ex_EmlJ8S26XlbOCyZiCkwA11,x,f,n,1,1,1,1,0,0,0,1,0,0,
0,1,0,0,0,ex_yS7VvSIKrGg9ddzBqHtUd_*ex_ER1h_1EVPL8fiwyFSpjD92/
ex_4AO9K2_NQw9OWwOYDDTSh0);pmf_free(ex_w_oCkEWPNmlVJvldp25MJ1);pmf_free(
ex_EmlJ8S26XlbOCyZiCkwA11);pmf_free(ex_cOnNpZibruamLe7g_F6N3_);}void
tlu2_1d_akima_nearest_value(real_T*fi,const real_T*H,const real_T*Hx,const
real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const real_T*f
,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_WGHw9K_F4Ex0dN1kGCLmw2(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,0.0,false);}
void tlu2_1d_akima_nearest_value_custom_function_(void*out,const void*in){
const real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(
const real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const
void*const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*
bin=(const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((
const void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in
)[7];const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const
size_t*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_nearest_value(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}void
tlu2_1d_akima_linear_value(real_T*fi,const real_T*H,const real_T*Hx,const
real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const real_T*f
,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_WGHw9K_F4Ex0dN1kGCLmw2(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,1.0,false);}
void tlu2_1d_akima_linear_value_custom_function_(void*out,const void*in){const
real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(const
real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const void*
const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];const
size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*bin=(
const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((const
void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in)[7];
const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const size_t
*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_linear_value(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}void
tlu2_1d_akima_nearest_derivatives(real_T*fi,const real_T*H,const real_T*Hx,
const real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const
real_T*f,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_WGHw9K_F4Ex0dN1kGCLmw2(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,0.0,true);}
void tlu2_1d_akima_nearest_derivatives_custom_function_(void*out,const void*in
){const real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(
const real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const
void*const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*
bin=(const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((
const void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in
)[7];const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const
size_t*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_nearest_derivatives(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}void
tlu2_1d_akima_linear_derivatives(real_T*fi,const real_T*H,const real_T*Hx,
const real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const
real_T*f,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_WGHw9K_F4Ex0dN1kGCLmw2(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,1.0,true);}
void tlu2_1d_akima_linear_derivatives_custom_function_(void*out,const void*in)
{const real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(
const real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const
void*const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*
bin=(const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((
const void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in
)[7];const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const
size_t*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_linear_derivatives(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}
static void ex_WGHw9K_F4Ex0dN1kGCLmw2(real_T*fi,const real_T*H,const real_T*Hx
,const real_T*G,const real_T*Gx,const size_t*ex_kBepeSFLrrwL__yvXOwx02,const
size_t*ex_nojcxOuQdDNrZlkHNs5QX_,const real_T*f,const real_T*fx,const boolean_T
*mode,const size_t*n,const real_T ex_XPTig2EtwH6R7_NgNRUTK0,const boolean_T
ex_Qmu676yE9oxL758xSv1lO1){size_t numEdges= *ex_kBepeSFLrrwL__yvXOwx02;size_t
bin= *ex_nojcxOuQdDNrZlkHNs5QX_;if(ex_Qmu676yE9oxL758xSv1lO1){if(numEdges<2){
fi[0]=0.0;}else{fi[0]=f[bin]*G[0]+f[bin+1]*G[1]+fx[bin]*Gx[0]+fx[bin+1]*Gx[1];
}}else{if(numEdges<2){fi[0]=f[0];}else{fi[0]=f[bin]*H[0]+f[bin+1]*H[1]+fx[bin]
*Hx[0]+fx[bin+1]*Hx[1];}}}
