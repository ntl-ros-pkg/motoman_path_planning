#include "pm_std.h"
#include "math.h"
#include "pm_std.h"
double sm_core_canonicalAngle(double sm_pCQ1n2WM2xYXeVFN6qo7v1);double
sm_1uQ1dTjyCtr7yi5zkhqq2_(double sm_PkoPYRgnaS_7wAYKv_SDp2,double
sm_bG5Ubuo7MuS5eqkPEDJV_0);double sm_core_canonicalAngle(double
sm_RAQgyWVtpyqfEVcLRZFTL_){const double sm_sHv_3RfqaWfo5SoqyYLGM_=pmf_get_pi()
;const double sm_YHjW6Z6lv6_YxkJ8L5gh5_=2.0*sm_sHv_3RfqaWfo5SoqyYLGM_;if(
sm_RAQgyWVtpyqfEVcLRZFTL_>=0.0)return fmod(sm_sHv_3RfqaWfo5SoqyYLGM_+
sm_RAQgyWVtpyqfEVcLRZFTL_,sm_YHjW6Z6lv6_YxkJ8L5gh5_)-sm_sHv_3RfqaWfo5SoqyYLGM_
;else{const double sm_Ecx5wv_MYm33eMTWzHSgl0=sm_sHv_3RfqaWfo5SoqyYLGM_-fmod(
sm_sHv_3RfqaWfo5SoqyYLGM_-sm_RAQgyWVtpyqfEVcLRZFTL_,sm_YHjW6Z6lv6_YxkJ8L5gh5_)
;return(sm_Ecx5wv_MYm33eMTWzHSgl0<sm_sHv_3RfqaWfo5SoqyYLGM_)?
sm_Ecx5wv_MYm33eMTWzHSgl0:-sm_sHv_3RfqaWfo5SoqyYLGM_;}}double
sm_1uQ1dTjyCtr7yi5zkhqq2_(double sm_PkoPYRgnaS_7wAYKv_SDp2,double
sm_bG5Ubuo7MuS5eqkPEDJV_0){const double sm_hMpAw9m5O_arUCc5GVcld0=
sm_core_canonicalAngle(sm_bG5Ubuo7MuS5eqkPEDJV_0-sm_PkoPYRgnaS_7wAYKv_SDp2);
return sm_PkoPYRgnaS_7wAYKv_SDp2+sm_hMpAw9m5O_arUCc5GVcld0;}
