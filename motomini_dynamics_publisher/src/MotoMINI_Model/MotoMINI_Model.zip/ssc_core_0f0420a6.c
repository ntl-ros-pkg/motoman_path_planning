#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_core_apWKlSiqYlOEuzjHKc5GX2 ssc_core_7Gx_dh5Tki38AkADLkE2H1
;typedef struct ssc_core_UobhgC__LOfn05I_A6cSj2 ssc_core__OM7G9uJF4tZY9vaH_Qv_1
;struct ssc_core_UobhgC__LOfn05I_A6cSj2{boolean_T(*
ssc_core_r3XTQSiIyT97jRZuxAZzV_)(const ssc_core__OM7G9uJF4tZY9vaH_Qv_1*
ssc_core_aTYoAWr1REqCeqF3MxzWA1,const NeSystemInput*mc_w2sbHOBWMTHvn1ViunNc91)
;void(*mc_Yw61cZ13Da0qoNu7ejn121)(const ssc_core__OM7G9uJF4tZY9vaH_Qv_1*
ssc_core_aTYoAWr1REqCeqF3MxzWA1);void(*mc_YCFci8IAJkK9w_xpRtHta2)(
ssc_core__OM7G9uJF4tZY9vaH_Qv_1*ssc_core_aTYoAWr1REqCeqF3MxzWA1);
ssc_core_7Gx_dh5Tki38AkADLkE2H1*mc_0TyJOxmrCFOwXODumYaSw2;};
ssc_core__OM7G9uJF4tZY9vaH_Qv_1*ssc_core_4j__kh8z8I8ltQ6wGYrps0(
NeSystemInputSizes ne_18op92eXGiCTt3cPVSrLy_,PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2);
#include "pm_std.h"
struct ssc_core_apWKlSiqYlOEuzjHKc5GX2{PmAllocator*
ssc_core_EJyLFJLNS54LEp1_ia1250;};static boolean_T
ssc_core_kDJGKeSTzftk4Fx2VZp2V_(const ssc_core__OM7G9uJF4tZY9vaH_Qv_1*
ssc_core_aTYoAWr1REqCeqF3MxzWA1,const NeSystemInput*mc_w2sbHOBWMTHvn1ViunNc91)
{return true;}static void ssc_core_MjyayLohviegIRpo_V4Bs2(const
ssc_core__OM7G9uJF4tZY9vaH_Qv_1*ssc_core_aTYoAWr1REqCeqF3MxzWA1){(void)
ssc_core_aTYoAWr1REqCeqF3MxzWA1;}static void ssc_core_Clylum_FvI3A4t2pE2Yoy1(
ssc_core__OM7G9uJF4tZY9vaH_Qv_1*ssc_core_aTYoAWr1REqCeqF3MxzWA1){
ssc_core_7Gx_dh5Tki38AkADLkE2H1*mc_6peHhhgu8wo0Kp3HDh_aI0=
ssc_core_aTYoAWr1REqCeqF3MxzWA1->mc_0TyJOxmrCFOwXODumYaSw2;PmAllocator*
pm_an0wiQTjdlKE72zC6FJ0a2=mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core_EJyLFJLNS54LEp1_ia1250;{void*ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(
mc_6peHhhgu8wo0Kp3HDh_aI0);if(ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};{void*ssc_core_GAbHnJspJ6sMhe_Yzxehb_=(
ssc_core_aTYoAWr1REqCeqF3MxzWA1);if(ssc_core_GAbHnJspJ6sMhe_Yzxehb_!=0){(
pm_an0wiQTjdlKE72zC6FJ0a2)->mFreeFcn(pm_an0wiQTjdlKE72zC6FJ0a2,
ssc_core_GAbHnJspJ6sMhe_Yzxehb_);}};}ssc_core__OM7G9uJF4tZY9vaH_Qv_1*
ssc_core_4j__kh8z8I8ltQ6wGYrps0(NeSystemInputSizes ne_18op92eXGiCTt3cPVSrLy_,
PmAllocator*pm_an0wiQTjdlKE72zC6FJ0a2){ssc_core__OM7G9uJF4tZY9vaH_Qv_1*
ssc_core_aTYoAWr1REqCeqF3MxzWA1=(ssc_core__OM7G9uJF4tZY9vaH_Qv_1*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
ssc_core__OM7G9uJF4tZY9vaH_Qv_1)),(1)));ssc_core_7Gx_dh5Tki38AkADLkE2H1*
mc_6peHhhgu8wo0Kp3HDh_aI0=(ssc_core_7Gx_dh5Tki38AkADLkE2H1*)((
pm_an0wiQTjdlKE72zC6FJ0a2)->mCallocFcn((pm_an0wiQTjdlKE72zC6FJ0a2),(sizeof(
ssc_core_7Gx_dh5Tki38AkADLkE2H1)),(1)));mc_6peHhhgu8wo0Kp3HDh_aI0->
ssc_core_EJyLFJLNS54LEp1_ia1250=pm_an0wiQTjdlKE72zC6FJ0a2;
ssc_core_aTYoAWr1REqCeqF3MxzWA1->ssc_core_r3XTQSiIyT97jRZuxAZzV_=
ssc_core_kDJGKeSTzftk4Fx2VZp2V_;ssc_core_aTYoAWr1REqCeqF3MxzWA1->
mc_Yw61cZ13Da0qoNu7ejn121=ssc_core_MjyayLohviegIRpo_V4Bs2;
ssc_core_aTYoAWr1REqCeqF3MxzWA1->mc_YCFci8IAJkK9w_xpRtHta2=
ssc_core_Clylum_FvI3A4t2pE2Yoy1;ssc_core_aTYoAWr1REqCeqF3MxzWA1->
mc_0TyJOxmrCFOwXODumYaSw2=mc_6peHhhgu8wo0Kp3HDh_aI0;return
ssc_core_aTYoAWr1REqCeqF3MxzWA1;}
